const webpack = require("webpack");
const path = require("path");
const CopyPlugin = require("copy-webpack-plugin");
const srcDir = "../src/";
module.exports = {
  entry: {
    settings: path.join(__dirname, srcDir + "setting.js"),
    bootstraptagsinput: path.join(__dirname, srcDir + "bootstraptagsinput.js"),
    helper: path.join(__dirname, srcDir + "helper.js"),
    common: path.join(__dirname, srcDir + "common.js"),
    message: path.join(__dirname, srcDir + "message.js"),
    messageGroups: path.join(__dirname, srcDir + "messageGroups.js"),
    segmentGroups: path.join(__dirname, srcDir + "segmentGroups.js"),
    config: path.join(__dirname, srcDir + "config.json"),
    login: path.join(__dirname, srcDir + "login.js"),
    funnels: path.join(__dirname, srcDir + "funnels.js"),
    background: path.join(__dirname, srcDir + "background.js"),
    assembleAllScript: path.join(__dirname, srcDir + "assembleAllScript.js"),
    storage: path.join(__dirname, srcDir + "storage.js"),
    changepassword: path.join(__dirname, srcDir + "changepassword.js"),
    forgotpass: path.join(__dirname, srcDir + "forgot-pass.js"),
    socialLink: path.join(__dirname,srcDir+'socialLink.js'),
    generalPP: path.join(__dirname, srcDir + "generalPP.js"),
    content: [
      path.join(__dirname, srcDir + "content_script.js"),
      path.join(__dirname, srcDir + "content.js"),
    ],
  },
  output: {
    path: path.join(__dirname, "../dist/js"),
    filename: "[name].js",
  },
  optimization: {
    splitChunks: {
      name: "vendor",
      chunks: "initial",
    },
  },
  module: {
    rules: [
      {
        test: /\.tsx?$/,
        use: "ts-loader",
        exclude: /node_modules/,
      },
      {
        test: /\.exec\.js$/,
        use: ["script-loader"],
        exclude: /node_modules/,
      },
    ],
  },
  resolve: {
    extensions: [".ts", ".tsx", ".js", ".json"],
  },
  plugins: [
    // exclude locale files in moment
    new webpack.IgnorePlugin(/^\.\/locale$/, /moment$/),
    new CopyPlugin([{ from: ".", to: "../" }], { context: "public" }),
  ],
};
