// console.log("Hi I am background.js");

// const helper = require("./helper.js");
var port = chrome.runtime.connect({
  name: "background-Background",
});
let generalPayload;
// const configStore = require("../public/kyubiSettings.json");
// console.log("config :: ", configStore.publicVapidKey);

// document.addEventListener("DOMContentLoaded", function () {
//   // console.log("DOM CONTENT LOADED");
//   if ("serviceWorker" in navigator) {
//     // console.log("requesting permission");
//     Notification.requestPermission(function (result) {
//       // console.log("result : ", result);
//       if (result === "granted") {
//         sendFn().catch((e) => console.error("EERR : ", e));
//       }
//     });
//   }
// });

// function urlBase64ToUint8Array(base64String) {
//   const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
//   const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");

//   const rawData = window.atob(base64);
//   const outputArray = new Uint8Array(rawData.length);

//   for (let i = 0; i < rawData.length; ++i) {
//     outputArray[i] = rawData.charCodeAt(i);
//   }
//   return outputArray;
// }

// Register the service worker
// Register Push
// Send the push
// const sendFn = async () => {
//   // Register SErvice Worker
//   // console.log("Registering service worker");
//   const register = await navigator.serviceWorker.register("./worker.js", {
//     scope: "/",
//   });

//   // console.log("waiting for ready : ", register);
//   await navigator.serviceWorker.ready;

//   // console.log("register service worker : ", register);

//   const subscription = await register.pushManager.subscribe({
//     userVisibleOnly: true,
//     applicationServerKey: urlBase64ToUint8Array(configStore.publicVapidKey),
//   });
//   // console.log("Push registered..", subscription);

//   chrome.storage.local.set(
//     {
//       subscription: JSON.parse(JSON.stringify(subscription)),
//     },
//     function () {
//       // chrome.storage.local.get(['subscription'], function(sub) {
//       // console.log("sub : ", subscription);

//       //   // ycePorts.loginResponsePort.postMessage({"subscription": sub.subscription})
//       // })
//     }
//   );
// };

chrome.tabs.onActivated.addListener(function (activeInfo) {
  setPopup();
});

chrome.tabs.onUpdated.addListener(function (activeInfo) {
  setPopup();
});

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  if (changeInfo.status == "complete") {
    // console.log(JSON.stringify(tabId, null, 4));
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ["./js/vendor.js"],
      // function: () => {}, // files or function, both do not work.
    });
    // chrome.scripting.executeScript({
    //   target: { tabId: tabId },
    //   files: ["./js/helper.js"],
    //   // function: () => {}, // files or function, both do not work.
    // });
    // chrome.scripting.executeScript({
    //   target: { tabId: tabId },
    //   files: ["./js/content.js"],
    //   // function: () => {}, // files or function, both do not work.
    // });
  }
});

chrome.storage.local.get(["positions"], (st) => {
  let positions = st.positions;
  // console.log("positions ::: ", positions);
  var indexArr = [];
  if (
    positions == undefined ||
    positions == null ||
    positions == "undefined" ||
    positions == ""
  ) {
    // positions.position = 0
    var newPayload = {
      position: -1,
      counter: 0,
      indexArr: indexArr,
    };
    // console.log("newPayload : ", newPayload);
    chrome.storage.local.set({ positions: newPayload }, function () {
      // console.log("Position payload has been stored for undefined.");
    });
  }
  // else {
  //   positions.position = general;
  //   // console.log("positions.position ::: ", positions.position);
  //   chrome.storage.local.set({positions: positions})
  // }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.local.get(["settings"], async (res) => {
    let settingsCopy = JSON.parse(JSON.stringify(res));
    let settingsArray = res.settings;
    const tabsArray = await getAllTabs();
    // console.log("tabsArray ::: ", tabsArray);
    if (res.settings != undefined && res.settings != null) {
      settingsArray.forEach(function (value, settingsIndex) {
        const settingsUrlToCheck = value.post_url;
        // console.log("settingsUrlToCheck : ", settingsUrlToCheck);
        let flag = false;

        for (let i = 0; i < tabsArray.length; i++) {
          const tabUrlToCheck = tabsArray[i].url;
          if (tabUrlToCheck !== undefined) {
            // console.log("tabUrlToCheck : ", tabUrlToCheck);
            let param = getURLParams(tabsArray[i].url);
            let postUrl = settingsUrlToCheck.split("/").reverse();
            // console.log("param.id : ", param.id, "param.story_fbid : ",param.story_fbid," postUrl[0] : ", postUrl[0])
            if (postUrl[0] == param.id || postUrl[0] == param.story_fbid) {
              flag = true;
              break;
            }
          }
        }
        if (flag == false) {
          settingsCopy.settings[settingsIndex].active = "";
        }
      });
    }
    // console.log("finalSettings copy saving : ", settingsCopy.settings)
    chrome.storage.local.set(
      { settings: settingsCopy.settings },
      function (updatedValue) {
        // console.log("Settings array updated : ", updatedValue);
      }
    );
  });
});

function getAllTabs() {
  return new Promise((resolve, reject) => {
    chrome.tabs.query({ active: false }, function (tabs) {
      // console.log("tabs  on close ::: ", tabs);
      let tabb = [];
      tabb.push(tabs);
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        tabb[0].push(tabs[0]);
        resolve(tabb[0]);
      });
    });
  });
}

chrome.runtime.onConnect.addListener(function (port) {
  // console.log("Connected .....");
  port.onMessage.addListener(function (msg) {
    // console.log("::::::: msg :::::::: 186 ::::::: ", msg);
    switch (msg.action) {
      case "startReplying":
        // console.log(msg);
        openSendMessage(msg);
        break;
      case "openPerson":
        openSendMessageto(msg);
        break;
      case "stopReplying":
        // console.log("stop reply from background", msg.tabId)
        chrome.tabs.remove(msg.tabId);
        // sendpayload(msg.tabId);
        break;
      case "openSettings":
        openSettingsPage(msg);
        break;
      case "ClosingTab":
        chrome.tabs.remove(msg.tabId);
        // ClosingTab(msg);
        break;
      case "startGeneralPP":
        console.log("sate in back js")
        startgeneralPP(msg);
        break;

      case "stopGeneralPP":
        stopGeneralPP();
        break;
      case "closeSettings":
        // var settingTab = msg.tabId;
        chrome.tabs.remove(msg.tabId);
        break;
      case "ClosingSettings" : 
        ClosingTab(msg);
        break;
      default:
        // console.log("Default case");
        break;
    }
  });
});

const afterSendMessage = (msg) => {
  postUrls = msg.postUrls;
  chrome.storage.local.get(["positions"], (st) => {
    // console.log("in resave payload postUrls : ", postUrls);
    let positions = st.positions;
    // console.log("positions ::: ", positions);
    if (
      positions == undefined ||
      positions == null ||
      positions == "undefined" ||
      positions == ""
    ) {
    } else {
      chrome.storage.local.get("general_post_urls", function (url) {
        datas = url.general_post_urls;
        var counts = positions.counter;
        //   // console.log("Counts :: ", counts)
        positions.position = msg.general;
        if (counts == 0) positions.counter = 1;
        else positions.counter = 0;
        positions.post_url = postUrls;
        if (!positions.indexArr) {
          indexArr = [];
        } else {
          indexArr = positions.indexArr;
        }
        // console.log("indexArr :: ", indexArr);
        indexArr.push(msg.general);
        if (indexArr.length == datas.length) {
          indexArr = [];
        }
        // console.log("indexArr  after push general :: ", indexArr);
        positions.indexArr = indexArr;
        chrome.storage.local.set({ positions: positions }, function () {
          // console.log("Position i saved in storage ");
        });
      });
    }
  });
};

function ClosingTab(msg) {
  // console.log("msg ::: ", msg)
  // chrome.tabs.remove(msg.tabId);
  const queryOptions = { active: true, currentWindow : true };
  chrome.tabs.query(queryOptions, function(tab){
    // console.log("tab ::: ", tab[0], tab[0].id);
    chrome.tabs.remove(tab[0].id);
  });
  // return tab;
}

/**
 * OPEN A TAB & SEND MESSAGE TO CONTENT SCRIPT USING CHROME API
 * @param {Object} msgpayload Payload to send with message
 */
function sendpayload(tabID) {
  // console.log("tabID : ", tabID, typeof  tabID);
  chrome.tabs.remove(tabID);
}

const getURLParams = function (taburl) {
  var vars = {};
  taburl.replace(/[?&]+([^=&]+)=([^&]*)/gi, function (m, key, value) {
    vars[key] = value;
  });
  return vars;
};

/**
 * OPEN A TAB & SEND MESSAGE TO CONTENT SCRIPT USING CHROME API
 * @param {Object} newpayload Payload to send with message
 */
function openSendMessageto(newpayload) {
  // console.log(newpayload);
  openUrl(newpayload.userData.mobileUrl)
    .then((tab) => checkTabStatus(tab))
    .then((tab) => {
      console.warn("Send Message Tab", tab.id);
      // chrome.storage.local.set({tabId : tab.id})
      // console.warn("Payload", payload);
      setTimeout(() => {
        chrome.tabs.sendMessage(
          tab.id,
          {
            action: "messagePerson",
            tab: tab,
            userData: newpayload.userData,
            fromTab: newpayload.tabID,
          },
          function (res) {
            // console.log(res);
          }
        );
      }, 1000);
    })
    .catch((e) => {
      // console.log("ERROR", e);
    });
}

/**
 * OPEN A TAB & SEND MESSAGE TO CONTENT SCRIPT USING CHROME API
 * @param {Object} mFBdata Payload to send with message
 */
function openSettingsPage(mFBdata) {
  // console.log(mFBdata);
  openUrl(mFBdata.mAccountUrl)
    .then((tab) => checkTabStatus(tab))
    .then((tab) => {
      // console.warn("Send Message Tab", tab);
      // console.warn("Payload", payload);
      setTimeout(() => {
        chrome.tabs.sendMessage(
          tab.id,
          { action: "openSettings", postData: mFBdata.postData, tabId: tab.id },
          function (res) {
            // console.log(res);
          }
        );
      }, 1000);
    })
    .catch((e) => {
      // console.log("ERROR", e);
    });
}

/**
 * OPEN A TAB & SEND MESSAGE TO CONTENT SCRIPT USING CHROME API
 * @param {Object} payload Payload to send with message
 */
function startgeneralPP(payload) {
  // console.log("payload in startGeneralPP :: ", payload);
  openUrl(payload.payload.post_url)
    .then((tab) => checkTabStatus(tab))
    .then((tab) => {
      // console.warn("Send Message Tab", tab);
      // console.warn("Payload", payload);
      payload.tabID = tab.id;
      setTimeout(() => {
        chrome.tabs.sendMessage(tab.id, payload, function (res) {
          // console.log(res);
        });
      }, 1000);
    })
    .catch((e) => {
      // console.log("ERROR", e);
    });
}

/**
 * OPEN A TAB & SEND MESSAGE TO CONTENT SCRIPT USING CHROME API
 * @param {Object} payload Payload to send with message
 */
function openSendMessage(payload) {
  // console.log("payload :: ", payload);
  openUrl(payload.payload.post_url)
    .then((tab) => checkTabStatus(tab))
    .then((tab) => {
      // console.warn("Send Message Tab", tab);
      payload.payload = {...payload.payload , tabId : tab.id}
      // console.warn("Payload", payload.payload);
      setTimeout(() => {
        chrome.tabs.sendMessage(tab.id, payload, function (res) {
          // console.log(res);
        });
      }, 1000);
    })
    .catch((e) => {
      // console.log("ERROR", e);
      // console.log("::::::: openSendMessage error :::::::: 427 ::::::: ", e);
    });
}

/**
 * CREATING A NEW TAB WITH THE URL
 * @param {String} url The url to which will open
 */
const openUrl = (url) => {
  return new Promise((resolve, reject) => {
    try {
      chrome.tabs.create({ url: url, pinned : true, active : false }, function (tab) {
        resolve(tab);
      });
    } catch (e) {
      reject(e.message);
    }
  });
};

/**
 * CHECKING THE STATUS OF THE FOCUSED TAB WHETHER LOADED OR STILL LOADING
 * @param {Object} tab Gives the state of the tab
 */
const checkTabStatus = (tab) => {
  return new Promise((resolve, reject) => {
    try {
      chrome.tabs.onUpdated.addListener(function delPendinglistener(
        tabId,
        info
      ) {
        if (info.status === "complete" && tabId === tab.id) {
          // console.log("Tab Info", info);
          // console.log(
          //   ">>> checkTabStatus >>>>> 457 no line >>>>>",
          //   tabId,
          //   ">>>>>>>>>>>>>",
          //   info
          // );
          chrome.tabs.onUpdated.removeListener(delPendinglistener);
          tab.status = info.status;
          resolve(tab);
        }
      });
    } catch (e) {
      // console.log("I am in error block >>>>>>>> 465 no line >>>>>", e);
      reject(e.message);
    }
  });
};

const getAccessToken = function (res) {
  return res !== null &&
    res !== undefined &&
    res.store !== null &&
    res.store !== undefined &&
    res.store.user !== null &&
    res.store.user !== undefined
    ? res.store.user.token
    : null;
};

const checkAccessToken = function (res) {
  const token = getAccessToken(res);

  if (token !== null && token !== undefined && token.length > 0) {
    return true;
  }
  return false;
};

function setPopup() {
  chrome.storage.local.get(["store"], function (res) {
    // console.log("res ::: ", res);
    // console.log("Checkig logged in already or not", helper.checkAccessToken(res));
    if (checkAccessToken(res)) {
      chrome.storage.local.get(["settings"], function (res) {
        // console.log("items", res.settings);
        if (isEmptyObj(res) || res.settings.length) {
          // console.log("Empty");
          chrome.action.setPopup({ popup: "../funnels.html" });
        } else {
          // console.log("Not Empty");
          chrome.action.setPopup({ popup: "../dashboard.html" });
        }
      });
    } else {
      chrome.action.setPopup({ popup: "../login.html" });
    }
  });
}

const isEmptyObj = function (obj) {
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) return false;
  }
  return true;
};

chrome.storage.onChanged.addListener(function (changes, namespace) {
  // console.log(
  //   "chrome.storage.onChanged.addListener : ",
  //   changes,
  //   "namespace: ",
  //   namespace
  // );
  let variableName = "position";
  // console.log("changes != null  && changes.positions != null && changes.positions.newValue[variableName] != changes.positions.oldValue[variableName]",
  // changes != null
  // && changes.positions != null
  // && changes.positions.newValue != null
  // && changes.positions.oldValue != null
  // && changes.positions.newValue[variableName] != null
  // && changes.positions.oldValue[variableName]  != null)
  if (
    changes != null &&
    changes.positions != null &&
    changes.positions.newValue != null &&
    changes.positions.oldValue != null &&
    changes.positions.newValue[variableName] != null &&
    changes.positions.oldValue[variableName] != null
  ) {
    // && changes.positions.newValue[variableName] != changes.positions.oldValue[variableName]
    // if(index !== changes.positions.newValue[variableName]){
    // TODO : CALL YOUR FUNCTION
    if (changes.positions.newValue[variableName] >= 0) {
      // console.log(
      //   "changes.positions.newValue.post_url :: ",
      //   changes.positions.newValue.post_url
      // );

      chrome.storage.local.get("general_post_urls", function (url) {
        chrome.storage.local.get(["generalSettings"], function (res) {
          if (url.general_post_urls) {
            let data = url.general_post_urls;
            var tabsId = changes.positions.newValue.post_url;
            chrome.tabs.remove(tabsId);
            console.log("timeeeer///////");
            setTimeout(
            
              startGeneralPPRun(
                data,
                res.generalSettings,
                changes.positions.newValue[variableName],
                changes.positions.newValue.indexArr
              ),
              1000
            );
            // console.log("CHANGE DETECTED");
          }
        });
      });
    }
  }
});

function startGeneralPPRun(data, generalSettings, indx, indexArray) {
 console.log("adatta arrayayyaa:::::::::://///// : ", indexArray);
  // console.log("generalSettings : ", generalSettings);
  let index = Math.floor(Math.random() * data.length);
  // console.log(index + " : " + data[index]);
  // console.log("index != indx", index != indx);
  var isIndex = indexArray.indexOf(index);
  // console.log("isIndex : ", isIndex, isIndex < 0);
  if (index != indx && isIndex < 0) {
    generalPayload = generalSettings[0];
    // console.log("generalPayload : ", generalPayload);
    if (generalPayload) {
      // console.log(generalPayload.active);
      // console.log(generalPayload.post_url);
      generalPayload.post_url = data[index];
      // generalPayload.active="active";
      // console.log(generalPayload.active);
      var genPayload = [];
      genPayload.push(generalPayload);
      if(data.length==1){
        generalPayload.single_Link=true;
      }
      // console.log(genPayload);
      const payload = {
      action: "startGeneralPP",
        position: index,
        payload: generalPayload,
      }; 
      setTimeout(startgeneralPP(payload), 3000);
    }
  } else {
    startGeneralPPRun(data, generalSettings, indx, indexArray);
  }
}

function stopGeneralPP() {
  chrome.storage.local.get(["tabId"], function (res) {
    // console.log("res.tabId ::: ", typeof res.tabId, parseInt(res.tabId));
    var tID = res.tabId;
    chrome.tabs.remove(tID);
  });
}
