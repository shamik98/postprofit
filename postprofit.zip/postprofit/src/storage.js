// const configStore = require("../public/kyubiSettings.json");

const loginStorage = async (email, password, resp, url) => {
  // console.log(email, password, resp, url);
  let response = await fetch(url, {
    method: "POST", // *GET, POST, PUT, DELETE, etc.
    mode: "cors", // no-cors, cors, *same-origin
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      email: email,
      password: password,
      token: resp.token,
    }), // body data type must match "Content-Type" header
  });
  response = await response.json();
  // console.log(JSON.stringify(response));

  await retieveSegmentAndGroup(response);
  // await retieveGroup(response);
  localStorage.setItem("token", resp.token);
  return response;
};

const generalPPStorage = async (urls, configStore) => {
  // console.log(urls);
  let response = await fetch(
    configStore.appBaseBackendUrl.replace(/\/$/, "") + "/general/create",
    {
      method: "POST", // *GET, POST, PUT, DELETE, etc.
      mode: "cors", // no-cors, cors, *same-origin
      headers: {
        "Content-Type": "application/json",
        Authorization: localStorage.getItem("token"),
      },
      body: JSON.stringify({
        urls: urls,
      }), // body data type must match "Content-Type" header
    }
  );
  response = await response.json();
  return response;
};

const generalSettingsStorage = async (settings, configStore) => {
  // console.log(settings);
  let response = await fetch(
    configStore.appBaseBackendUrl.replace(/\/$/, "") +
      "/general-settings/create",
    {
      method: "POST", // *GET, POST, PUT, DELETE, etc.
      mode: "cors", // no-cors, cors, *same-origin
      headers: {
        "Content-Type": "application/json",
        Authorization: localStorage.getItem("token"),
      },
      body: JSON.stringify({
        settings: settings,
      }), // body data type must match "Content-Type" header
    }
  );
  response = await response.json();
  return response;
};

const settingsStorage = async (settings, configStore) => {
  // console.log(settings);
  let response = await fetch(
    configStore.appBaseBackendUrl.replace(/\/$/, "") + "/user/update",
    {
      method: "PUT", // *GET, POST, PUT, DELETE, etc.
      mode: "cors", // no-cors, cors, *same-origin
      headers: {
        "Content-Type": "application/json",
        Authorization: localStorage.getItem("token"),
      },
      body: JSON.stringify({
        settings: settings,
      }), // body data type must match "Content-Type" header
    }
  );
  response = await response.json();
  return response;
};

const segmentStorage = async (title, keyword, url, configStore) => {
  // console.log(title, keyword, url);
  let response = await fetch(
    configStore.appBaseBackendUrl.replace(/\/$/, "") + "/segments/create",
    {
      method: "POST", // *GET, POST, PUT, DELETE, etc.
      mode: "cors", // no-cors, cors, *same-origin
      headers: {
        "Content-Type": "application/json",
        Authorization: localStorage.getItem("token"),
      },
      body: JSON.stringify({
        title: title,
        keywords: keyword,
      }), // body data type must match "Content-Type" header
    }
  );
  response = await response.json();
  return response;
};

const segmentEditStorage = async (id, title, keyword, url, configStore) => {
  // console.log(id, title, keyword, url);
  let response = await fetch(
    configStore.appBaseBackendUrl.replace(/\/$/, "") + "segments/update",
    {
      method: "PUT", // *GET, POST, PUT, DELETE, etc.
      mode: "cors", // no-cors, cors, *same-origin
      headers: {
        "Content-Type": "application/json",
        Authorization: localStorage.getItem("token"),
      },
      body: JSON.stringify({
        id: id,
        title: title,
        keywords: keyword,
      }), // body data type must match "Content-Type" header
    }
  );
  response = await response.json();
  return response;
};

const deleteSegmentStorage = async (segmentId, url, configStore) => {
  // console.log(segmentId, url);
  let response = await fetch(
    configStore.appBaseBackendUrl.replace(/\/$/, "") +
      "segments/delete/" +
      segmentId,
    {
      method: "DELETE", // *GET, POST, PUT, DELETE, etc.
      mode: "cors", // no-cors, cors, *same-origin
      headers: {
        "Content-Type": "application/json",
        Authorization: localStorage.getItem("token"),
      },
    }
  );
  response = await response.json();
  return response;
};

const groupStorage = async (title, keyword, url, configStore) => {
  // console.log(title, keyword, url);
  let response = await fetch(
    configStore.appBaseBackendUrl.replace(/\/$/, "") + "groups/create",
    {
      method: "POST", // *GET, POST, PUT, DELETE, etc.
      mode: "cors", // no-cors, cors, *same-origin
      headers: {
        "Content-Type": "application/json",
        Authorization: localStorage.getItem("token"),
      },
      body: JSON.stringify({
        title: title,
        keywords: keyword,
      }), // body data type must match "Content-Type" header
    }
  );
  response = await response.json();
  return response;
};

const groupEditStorage = async (id, title, keyword, url, configStore) => {
  // console.log(id, title, keyword, url);
  let response = await fetch(
    configStore.appBaseBackendUrl.replace(/\/$/, "") + "groups/update",
    {
      method: "PUT", // *GET, POST, PUT, DELETE, etc.
      mode: "cors", // no-cors, cors, *same-origin
      headers: {
        "Content-Type": "application/json",
        Authorization: localStorage.getItem("token"),
      },
      body: JSON.stringify({
        id: id,
        title: title,
        keywords: keyword,
      }), // body data type must match "Content-Type" header
    }
  );
  response = await response.json();
  return response;
};

const deleteGroupStorage = async (groupId, url, configStore) => {
  // console.log(groupId, url);
  let response = await fetch(
    configStore.appBaseBackendUrl.replace(/\/$/, "") +
      "groups/delete/" +
      groupId,
    {
      method: "DELETE", // *GET, POST, PUT, DELETE, etc.
      mode: "cors", // no-cors, cors, *same-origin
      headers: {
        "Content-Type": "application/json",
        Authorization: localStorage.getItem("token"),
      },
    }
  );
  response = await response.json();
  return response;
};

const retieveSegmentAndGroup = async (response) => {
  // console.log("segmentsList : ", response.data.segmentsList);
  // console.log("groupsList : ", response.data.groupsList);
  // console.log("generalPP : ", response.data.generalPP);
  var messages = { fcmessages: { segments: [], groups: [] } };
  let messageObj = response.data.segmentsList;
  var data = [];
  messageObj.forEach((element, i) => {
    data.push({
      blocks: element.keywords,
      id: element._id,
      title: element.title,
    });
  });
  let groupObj = response.data.groupsList;
  var groupData = [];
  groupObj.forEach((element, i) => {
    groupData.push({
      blocksPos: element.keywords,
      id: element._id,
      title: element.title,
    });
  });
  messages.fcmessages.groups = groupData;
  messages.fcmessages.segments = data;
  chrome.storage.local.set(messages);
  chrome.storage.local.set({
    general_post_urls: response.data.generalPP.length
      ? response.data.generalPP[0].urls
      : [],
  });
  chrome.storage.local.set({
    generalSettings: response.data.generalSettings.length
      ? response.data.generalSettings[0].settings
      : [],
  });
//  console.log("settt saveed at storege ::::",response.data.settings)
  chrome.storage.local.set({ settings: response.data.settings });
  // console.log(JSON.stringify(messages));
};

module.exports = {
  loginStorage: loginStorage,
  segmentStorage: segmentStorage,
  deleteSegmentStorage: deleteSegmentStorage,
  segmentEditStorage: segmentEditStorage,
  groupStorage: groupStorage,
  groupEditStorage: groupEditStorage,
  deleteGroupStorage: deleteGroupStorage,
  generalPPStorage: generalPPStorage,
  generalSettingsStorage: generalSettingsStorage,
  settingsStorage: settingsStorage,
};
