var $ = (jQuery = require("jquery"));
const helper = require("./helper.js");
const RegURL = /^(http|https):\/\/(www.)*(facebook)(\.com)/;
const configStore = require("../public/kyubiSettings.json");
// const RegURL=/1(?:(?:http|https):\/\/)?(?:www.)?facebook.com\/(?:(?:\w)*#!\/)?(?:pages\/)?([\w\-]*)?/g;
$(document).ready(function () {



  // $(document).ready(function () {
  //   $.getJSON("kyubiSettings.json", async function (result) {

  //     if (result.extId == "5e944f24568e944b9d22418f") {
  //       console.log("----------------------------",);
  //       $('.morePower').css('display', 'block');

  //       chrome.storage.sync.get(["store"], async function (res) {
  //         let email = res.store.user.email;
  //         let ext_id = result.extId;

  //         let response = await fetch(kyubiSettings.dynamicLinkURL, {
  //           method: "POST", // *GET, POST, PUT, DELETE, etc.
  //           mode: "cors", // no-cors, cors, *same-origin
  //           headers: {
  //             "Content-Type": "application/json"
  //           },
  //           body: JSON.stringify({
  //             email: email,
  //             ext_id: ext_id
  //           }) // body data type must match "Content-Type" header
  //         })
  //           .then(response => response.json())
  //         console.log("response 9876->", response);
  //         $("#friender-link").attr("href", '#')
  //         if (response.data.links[0] !== undefined && response.data.links[0]) {
  //           let friender_link = response.data.links.find(friender_link => friender_link.uniqueId === 'friender-link')
  //           if (friender_link.link !== undefined && friender_link.link) {
  //             $("#friender-link").attr("href", friender_link.link)
  //             $("#friender-link").text(friender_link.title).css("text-transform", "uppercase");
  //           }
  //         }

  //         $("#click-link").attr("href", '#')
  //         if (response.data.links[1] !== undefined && response.data.links[1]) {
  //           let click_link = response.data.links.find(click_link => click_link.uniqueId === 'click-link')
  //           if (click_link.link !== undefined && click_link.link) {
  //             $("#click-link").attr("href", click_link.link)
  //             $("#click-link").text(click_link.title).css("text-transform", "uppercase");
  //           }
  //         }
  //       })


  //     } else {
  //       $('.morePower').css('display', 'none');
  //     }


  //   });
  // })



  // console.log("Document Ready");
let dynamicExtName = `<a href="./generalPP.html">General ${configStore.appName} </a>`;
$("#generalPPP").html(dynamicExtName);
let editPP = `<h3>Edit General ${configStore.appName} Settings</h3>`;
$(".generalPostSettingHeading").html(editPP)
// above changes made now
  $.getJSON("kyubiSettings.json", async function (result) {
    if (result.extId == "5e944f24568e944b9d22418f") {
      // console.log("Only for whitelabel of tier5 ", result.extId);
      $(".morePower").css("display", "block");
    } else {
      $(".morePower").css("display", "none");
    }
  });

  helper.checkAuthStatus();

  dynamicHTMLContent();

  $("#logout").on("click", function (e) {
    e.preventDefault();
    // console.log("Logout Clicked");
    // console.log("Logout Clicked");
    chrome.storage.local.get(["store"], function (res) {
      // console.log("res :::: from logout :::: ", res.store.user);
      if (helper.checkAccessToken(res)) {
        logoutPP(
          res.store.user.token,
          configStore.clearSubscriptionObjectURL,
          res.store.user.email,
          configStore.extId,
          res.store.user.deviceID
        );
      } else {
      }
    });
  });

  function logoutPP(token, logoutURL, email, extensionId, deviceID) {
    // console.log("infos in logout function ::: ", token, "\n", email, "\n", extensionId, "\n", deviceID);
    fetch(logoutURL, {
      method: "POST", // *GET, POST, PUT, DELETE, etc.
      mode: "cors", // no-cors, cors, *same-origin
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        // "Authorization": "KYUBI_"+ token
        // 'Access-Control-Allow-Origin': "*"
      },
      body: JSON.stringify({ email: email, extId: extensionId }), // body data type must match "Content-Type" header
    })
      .then((response) => response.json())
      .then((res) => {
        // console.log("api call from kyubi : ", res);
        if (res.status) {
          if (
            configStore.appBaseBackendUrl != null &&
            configStore.appBaseBackendUrl != ""
          ) {
            chrome.storage.local.remove("fcmessages");
            chrome.storage.local.remove("settings");
            chrome.storage.local.remove("generalSettings");
            chrome.storage.local.remove("general_post_urls");
          }
          chrome.storage.local.remove("store", function () {
            //console.log("Or Its clicking here");
            window.location.replace("../login.html");
          });
        }
      })
      .catch((err) => {
        if (
          configStore.appBaseBackendUrl != null &&
          configStore.appBaseBackendUrl != ""
        ) {
          chrome.storage.local.remove("fcmessages");
          chrome.storage.local.remove("settings");
          chrome.storage.local.remove("generalSettings");
          chrome.storage.local.remove("general_post_urls");
        }
        chrome.storage.local.remove("store", function () {
          //console.log("Or Its clicking here");
          window.location.replace("../login.html");
        });
      })
      .catch((err) => {});
  }

  chrome.storage.local.get(["store"], function (res) {
    if (helper.checkAccessToken(res)) {
      // console.log("res : ", res.store.user.email, configStore.extId)
      getPlan(res.store.user.email, configStore.extId);
    }
  });

  function getPlan(email, extId) {
    // console.log("in get plan the params are ::: ", email, extId)
    fetch("https://app.kyubi.io/api/end-user/get-plan", {
      method: "POST", // *GET, POST, PUT, DELETE, etc.
      mode: "cors", // no-cors, cors, *same-origin
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        email: email,
        extnsion_id: extId,
      }), // body data type must match "Content-Type" header
      redirect: "follow",
    })
      .then((response) => response.json())
      .then((res) => {
        // console.log("res ::: ", res.payload);
        if (res.payload.length != 0) {
          // console.log("payload ::: ", res.payload.plan_details.id);
          const plan = res.payload.plan_details.id;
          // console.log("plan ::: ", typeOf(plan));
          if (parseInt(plan) >= 2) {
            $("#generalPPP").show();
          } else $("#generalPPP").hide();
        } else {
          // console.log("$('#generalPPP') ::: ", $("#generalPPP")[0]);
          $("#generalPPP").hide();
        }
      })
      .catch((err) => {});
  }

  $("#clr_acnt").html("Cancel My Account");

  $("#clr_acnt").click(function (e) {
    e.preventDefault();
    $.getJSON("kyubiSettings.json", function (result) {
      $(".popup_overlay").remove();
      $("body").append(
        '<div class="popup_overlay close_button"><button id= "close"><img src="./assets/clear-white-18dp.svg" alt="" ></button><span>To cancel your account please email us at <a href="mailto:' +
          result.mailTo +
          '" style=" text-decoration: underline;">' +
          result.mailTo +
          "</a></span></div>"
      );
      $(".popup_overlay").css("display", "block");
    });
  });

  if (configStore.mailTo == null || configStore.mailTo == "") {
    $("#clr_acnt").hide();
  } else {
    $("#clr_acnt").show();
  }

  $(document).on("click", "#close", function (e) {
    e.preventDefault();
    // console.log("close............")
    $(".popup_overlay").fadeOut();
    setTimeout(function () {
      $(".popup_overlay").remove();
    }, 400);
    // $(document).remove('.popup_overlay');
  });

  // After providing the email address and pressing submit button
  // $("#forgotPass").click(function(){
  //     window.location.href = "confirmation.html";
  // });
  // Group Listing
  $("#groupList").click(function () {
    window.location.href = "group-listing.html";
  });
  // Group Create
  $("#groupCreate").click(function () {
    window.location.href = "group-create.html";
  });

  $("#createFunnel").click(function () {
    //console.log("clicking")
    chrome.tabs.query(
      { active: true, lastFocusedWindow: true },
      function (tab) {
        var tablink = tab.url;
        if (!RegURL.test(tablink)) {
          chrome.tabs.create(
            { url: "https://www.facebook.com/profile.php" },
            function (tab) {
              //console.log("tab ::: ",tab);
            }
          );
        }
      }
    );
  });

  // Menu
  $(".triggerMenu").click(function () {
    // console.log("menu : ", $(this));
    $(this).parent().toggleClass("open");
  });
  $(document).click(function (event) {
    if ($(event.target).closest(".triggerMenu, .menuHeader").length === 0) {
      $(".menuNav ").removeClass("open");
    }
  });
  // Menu --- END
});

const dynamicHTMLContent = () => {
  $.getJSON("kyubiSettings.json", function (result) {
    /* Placing header logo */
    $("#dynamicLogo").html(
      '<img src="' +
        result.logo.large_icon +
        '" alt="Logo" style="max-height:50px; max-width:50px"><span id="appTitle"></span>'
    );
    $("#appTitle").text(result.appName);
    if (result.loader.preLoader)
      $("#overlay").html(
        '<img src="' +
          result.loader.preLoader +
          '" alt = "" height="34" width="34">'
      );
    else
      $("#overlay").html(
        '<img src="./images/loader.gif" alt = "" height="34" width="34">'
      );
    /* Change appname*/
    $("#built").text("Haven't built a " + result.appName + " yet?");
    $("#note").html(
      `<strong style="color: red;">Note:</strong>` +
        result.appName +
        ` require to collect some non sensitive data
      which may redirect you to the homepage while you try to "Use ` +
        result.appName +
        `" for the first time.
      This is one time process.`
    );
    $("#createFunnel").text("Create my " + result.appName);
    $("#createFunnel").attr("title", "Create my " + result.appName);
    if (result.youtubeLink) {
      $("#video").attr("src", result.youtubeLink);
    } else {
      $("#video").attr("src", "");
    }
    $("#myCards").text("My " + result.appName + " Cards");
    
    $("#save_in_card").text("Save ");
    /* Placing footer */
    if (result.footer.showFooter) {
      // console.log("result.footer.showFooter true : ", result.footer.showFooter);
      if (result.footer.poweredBy.willBeDisplayed) {
        if (result.footer.poweredBy.url) {
          $("#poweredby").attr("href", result.footer.poweredBy.url);
          if (result.footer.poweredBy.url == "#")
            $("#poweredby").removeAttr("target");
        } else {
          $("#poweredby").attr("href", "");
          $("#poweredby").removeAttr("target");
        }
        if (result.footer.poweredBy.label)
          $("#poweredby").html(result.footer.poweredBy.label);
        else {
          $("#poweredby").html("");
          $("#and").hide();
        }
      } else {
        $("#poweredby").attr("href", "");
        $("#poweredby").html("");
        $("#and").hide();
      }

      if (result.footer.partnership.willBeDisplayed) {
        if (result.footer.partnership.url) {
          $("#partnership").attr("href", result.footer.partnership.url);
          if (result.footer.partnership.url == "#")
            $("#partnership").removeAttr("target");
        } else {
          $("#partnership").attr("href", "");
          $("#partnership").removeAttr("target");
        }
        if (result.footer.partnership.label)
          $("#partnership").html(result.footer.partnership.label);
        else {
          $("#partnership").html("");
          $("#and").hide();
        }
      } else {
        $("#partnership").attr("href", "");
        $("#partnership").html("");
        $("#and").hide();
      }

      if (result.footer.officialGroup.willBeDisplayed) {
        if (result.footer.officialGroup.url) {
          $("#group").attr("href", result.footer.officialGroup.url);
        } else {
          $("#group").attr("href", "");
          $("#group").html("");
        }
      } else {
        $("#group").attr("href", "");
        $("#group").html("");
      }

      if (result.footer.chatSupport.willBeDisplayed) {
        if (result.footer.chatSupport.url) {
          $("#chat").attr("href", result.footer.chatSupport.url);
        } else {
          $("#chat").attr("href", "");
          $("#chat").html("");
        }
      } else {
        $("#chat").attr("href", "");
        $("#chat").html("");
      }
    } else {
      // console.log("result.footer.showFooter false : ", result.footer.showFooter);
      $(".cf_footer").html("");
    }
  });
};
