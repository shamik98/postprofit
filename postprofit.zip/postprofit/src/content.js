/**
 * CONTENT SCRIPT
 * @author Tier5 <work@tier5.us>
 * @copyright All Legal authorities to Tier5 Technologies Pvt. Ltd.
 * Developer: Susmita
 * Moderator: Jit
 * @version 1
 */

const $ = (jQuery = require("jquery"));
const helper = require("./helper.js");
const configStore = require("../public/kyubiSettings.json");
// console.log("configStore : ", configStore.appName);
let userData = {};
let payload = {};
let notifID = "";
let payloadIndex = null;
let currPayloadtabId = null;
const ppWorkingDiv =
  '<div class="pf_replying"><div class="loadDots"><span style=" top: -5px; "></span><span></span><span></span></div>' +
  configStore.appName +
  " is working</div>";
// const comments_container = '._333v._45kb';
const comment_select = "._2a_i";
const page_selct = document.getElementsByClassName(
  "_54k8 _52jg _56bs _26vk _56bu"
);
const postUrl = new URL(window.location);
let count_replied;
let filteredGroup;
let PPTimeOut;
let commentCounts = {};
let replyCount =
  (isCommentReplyCalled =
  initiatedDomNodeInserted =
  totalCommentsCount =
  repliedComments =
  allCommentLength =
    0);
//let port = chrome.runtime.connect({ name: "contentScriptConnect" });
let count = 0;
// port = chrome.runtime.connect({
//   name: "port",
// });
let port = null;
const connectPort = () => {
  // eslint-disable-next-line no-undef
  port = chrome.runtime.connect({
    name: "port",
  });

  port.onDisconnect.addListener(() => {
    // console.log("Disconnected");
    connectPort();
  });
};

connectPort();

let messages, groupID, datas;
let indexArr = [];

$(document).ready(function () {
  // console.log("content.js is running");
  allCommentLength = $(".async_composer").find("._2a_i").length; // Total no of comments
  $("body").append('<div class="settings_overlay"><span></span></div>'); // Putting overlay view previous comments
  chrome.runtime.onMessage.addListener(cbListener);
  chrome.storage.local.get(["userFBData"], function (data) {
    userData = data.userFBData;
  });
});

/**
 * @function callback Handle all requests from background or popup
 * @param {Object} param Payload from background or popup
 * @returns true always for asynchronous nature
 */
function cbListener(param, sender, sendResponse) {
  // console.log("param in cb listener ::: ", param)
  switch (param.action) {
    case "startReplying": // startreply
      // console.log("Payload in cb listener ::: ", param.payload);
      currPayloadtabId = param.payload.tabId;
      payload = param.payload;
      // console.log("Payload : ",payload);
      notifID = param.payload.card_title;
      findPayload(payload);

      //  if (param.payload.latest_post == "Y") {
      // console.log("Latest post enabled");
      //      latestPostEnagement();
      //  }
      initializeReplyingToComments(payload);
      // commentReply();
      break;
    case "messagePerson": // send a message from message group
      sendMessageToFriend(param);
      break;
    case "startGeneralPP":
      // console.log("param : ", param);
      // console.log("param.tabID : ", param.tabID);
      chrome.storage.local.set({ tabId: param.tabID }, function () {
        // console.log("tabId has set.")
      });
      payload = param.payload;
      console.log("params:::::::::::::::::::::",param);   
      // notifID = param.payload.card_title;
      // findPayload(payload);
      if (param.payload.latest_post == "Y") {
        // console.log("Latest post enabled");
        latestPostEnagement(param.position, param.tabID);
      }
      if(payload){
           console.log("/////payload::::::",payload)
      }
      if(payload.single_Link){
        initializeReplyingToComments(param.position, param.tabID);
      }else{
        initializeReplyingToComments(payload, param.position, param.tabID);
      }
      
      // commentReply();
      break;
  }

  return true;
}

/**
 * Finding required payload from array of payload in local storage
 * @param {array} pl saved settings objects in local storage
 * @returns {object} settings data for particular post
 */
function findPayload(pyld) {
  helper.getSettings().then((settings) => {
    payloadIndex = settings.findIndex((el) => {
      return pyld.post_url == el.post_url;
    });
  });
  // console.log("the payoad indx????????????>>>>>>>>>>>>", payloadIndex);
}

/**
 * waiting time as per requirement
 * @param {number} ms the time need to pause
 */
function wait(ms) {
  // console.log("msmsmsmsmmsmsmmsmmsmms :::::: ", ms)
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Take time for reply to comments when postprofits has started
 */
async function initializeReplyingToComments(
  payload,
  general = null,
  postUrls = null
) {
   console.log("Initializing Comments has payload?  ", payload);
  // console.log("Initializing Comments has payload tab id?  ", payload.tabId);
 
  var settings = await helper.getSettings();
  // console.log("save setting befre initiaze comment", settings);
  // console.log("settings : ", settings);
  newSettings = settings.filter((el) => el.post_url === payload.post_url);
  settings = settings.filter((el) => el.post_url !== payload.post_url);
  if (newSettings.length > 0) {
    newSettings[0].tabId = payload.tabId;
    // console.log("newSettings : ", newSettings);
    // console.log("[...settings, newSettings : ", [...settings, newSettings[0]]);
    await helper.saveSettings([...settings, newSettings[0]]);
  }
  const elem = $("footer");
  scrollToPos(elem[0]);
  $(".settings_overlay").css("display", "block");
  $(".settings_overlay > span").html(
    "We are almost there. Initializing " +
      configStore.appName +
      "... <br>Please don't close the page"
  );
  const pageSelect = $("._2g0e");
  if (pageSelect) await chooseCommentor(pageSelect);
  // console.log("Commentor Choosen");
  const waiting = await wait(3000);
  clearTimeout(waiting);
  // $(".settings_overlay > span").html("Post Profits Initialization...<br>Loading All Comments");
  await viewPreviousComments(async function () {
    // console.log("viewPreviousComments has general?  ", general);
    // notifyProgress(0, 0, true);
    window.clearInterval();
    // console.log("COMMENT REPLY INITIATE");
    const isLatestP = payload.latest_post == "Y" ? true : false;
    // console.log("payload.latest_post == 'Y' : ", isLatestP);
    // if (isLatestP) {
    // console.log("Latest post enabled");
    //     latestPostEnagement(isLatestP, general, postUrls);
    // }
    await commentReply(isLatestP, general, postUrls);
  });
}

/**
 * Getting Comments which are not replied then start reply
 */
async function commentReply(
  isLatest,
  general = null,
  postUrls = null,
  onDomNodeInserted = false
) {
  // console.log("commentReply has general or not :::::::::::::::::::: on dom insertesd ", );
  // console.log("onDomNodeInserte in comment reply : ", onDomNodeInserted)
  onDomNodeInserted ? await wait(10000) : await wait(100);
  await addingClassToRepliedComments();
  await wait(2000);
  const elemArray = $(".async_composer")
    .find("[data-sigil='comment']")
    .not(".postprofits_replied");
  // console.log("elemArray in comment Reply  :::: ", elemArray)
  await countTotalRelevantComments(general, postUrls);
  $(".settings_overlay").css("display", "none");
  if (isLatest) {
    await startLatestPostEngagement(
      elemArray,
      general,
      postUrls,
      elemArray.length - 1
    );
  } else {
    // console.log("start reply why ????????????????????????")
    await startReply(elemArray, general, postUrls);
  }
  isCommentReplyCalled = 0;
}

/**
 * Choose if there is any 'reply as' then who will reply
 * @param {object} pageSelect div of dropdown for select reply as or comment as
 */
async function chooseCommentor(pageSelect) {
  // console.log("in choose commenor. ");
  let replies_from;
  if (payload.reply_from_where == "User") {
    replies_from = decodeURI(payload.user);
  } else {
    replies_from = payload.reply_from_where;
  }
  await pageSelect.click();
  // console.log("pageSelect : ",pageSelect);
  // console.log("replies_from : ",replies_from);
  const sleepID = await wait(4000);
  clearTimeout(sleepID);
  // console.log("_ru0 : ",$("._ru0"));
  return await $("._ru0").each(function (i, el) {
    // console.log("el out if", i, " : ", el);
    if (i) {
      if ($(el).text() == replies_from) {
        $(el).click();
        // console.log("el in if",i," : ", el,);
      }
    }
  });
}

/**
 * load more comments if there any.
 *  @param {callback} cb callback function for load more comments
 */
function clickLoadMoreComments(cb) {
  const pageNext = $(document).find('[id^="see_next"]');
  let oldElemLength = $(".async_composer").find(
    "[data-sigil='comment']"
  ).length;
  let seekVPC = $(".async_elem").find("a");
  let viewMoreLength = seekVPC.length;
  // Code for pages
  if (pageNext.length) {
    // console.log("In page next");
    const newElemLength = $(".async_composer").find(
      "[data-sigil='comment']"
    ).length;
    seekVPC = $(document).find('[id^="see_next"]').find("a");
    viewMoreLength = seekVPC.length;
    // console.log("Next length", newElemLength);
    // console.log("Old length", oldElemLength);
    if (oldElemLength === newElemLength) {
      count++;
      if (count > 3) {
        viewMoreLength = 0;
      }
    } else {
      oldElemLength = newElemLength;
    }
  }
  if (viewMoreLength) {
    for (var i = 0; i < seekVPC.length; i++) {
      seekVPC[i].click();
    }
  } else {
    cb(true);
  }
}

/**
 * clicking on view previos comments till it is present there.
 * @param {callback} callback callback function for clicking view previous comments
 */
async function viewPreviousComments(callback) {
  // console.log("In View More");
  const elem = $(".async_elem").find("a");
  // console.log("elem ::: ", elem);
  if (elem.length) {
    var intrvl = setInterval(async function () {
      await addingClassToRepliedComments();
      clickLoadMoreComments(function (bool) {
        if (bool) {
          clearInterval(intrvl);
          callback();
        }
      });
    }, 2500);
  } else {
    await callback();
  }
}

/**
 * start replying
 * @param {object} elemArray cooment div in facebook
 * @param {number} startFrom position of the comment
 */
async function startReply(
  elemArray,
  general = null,
  postUrls = null,
  startFrom = 0
) {
  // console.log("Start reply has general ? : ", elemArray, startFrom);
  const hasFallback = payload.fbreplyInput ? true : false; //checking if there fallback is present or not
  const hasKeywords = payload.keywordsInput ? true : false; //checking if there keyword is present or not
  if (elemArray.length !== startFrom) {
    const isKeywordMatched = await isCommentRelevant(elemArray[startFrom]); // checking keyword is matched or not with the text of comments
    let repliedComment = false;
    if (hasFallback && hasKeywords) {
      // if fall back and keyword both are there
      // Reply from replylist if matched or fallback if not matched
      // console.log("Has keyword & has fallback");
      if (isKeywordMatched) {
        // console.log("Keyword Matched", isKeywordMatched);
        repliedComment = await initiateReply(
          elemArray[startFrom],
          payload.replyInput,
          1,
          general,
          postUrls
        );
      } else {
        // console.log("Fallback Matched", !isKeywordMatched);
        repliedComment = await initiateReply(
          elemArray[startFrom],
          payload.fbreplyInput,
          0,
          general,
          postUrls
        );
      }
    } else if (hasKeywords && !hasFallback) {
      // if there is keywords and no fall back
      // Reply only if keyword matched
      // console.log("Has keyword & but no fallback");
      if (isKeywordMatched) {
        // console.log("On Keyword matched", isKeywordMatched);
        repliedComment = await initiateReply(
          elemArray[startFrom],
          payload.replyInput,
          1,
          general,
          postUrls
        );
      } else {
        repliedComment = true;
        // console.log("Skipping");
      }
    } else if (!hasKeywords && hasFallback) {
      // if there is no keywords and fall back is there
      // Reply to all comments from reply list
      // console.log("Has no keyword & but has fallback");
      repliedComment = await initiateReply(
        elemArray[startFrom],
        payload.fbreplyInput,
        0,
        general,
        postUrls
      );
    } else if (!hasKeywords && !hasFallback) {
      //if both fall back and keyword is not there
      // Reply to all comments from reply list
      // console.log("Has no keyword & has no fallback");
      repliedComment = await initiateReply(
        elemArray[startFrom],
        payload.replyInput,
        1,
        general,
        postUrls
      );
    }
    // console.log("RECURSIVE CALL");
    // console.log("------------------------");
    if (repliedComment) {
      await startReply(elemArray, general, postUrls, startFrom + 1); // calling start reply recursively for next comment
    }
  } else {
    // console.log("All reply done");
    // console.log("general : ", general, "tabId ::: ", postUrls);
    if (general != null && postUrls != null) {
      // console.log("general ! = null or ??? ", general);
      // setInterval(() => {
      chrome.storage.local.get(["positions"], (st) => {
        let positions = st.positions;
        // console.log("positions ::: ", positions);
        if (
          positions == undefined ||
          positions == null ||
          positions == "undefined" ||
          positions == ""
        ) {
        } else {
          chrome.storage.local.get("general_post_urls", function (url) {
            datas = url.general_post_urls;
            var counts = positions.counter;
            // console.log("Counts :: ", counts)
            positions.position = general;
            if (counts == 0) positions.counter = 1;
            else positions.counter = 0;
            positions.post_url = postUrls;
            if (!positions.indexArr) {
              indexArr = [];
            } else {
              indexArr = positions.indexArr;
              // console.log("indexArr in else:", indexArr);
              // console.log(
              //   "indexArr.length == datas.length : ",
              //   indexArr.length == datas.length
              // );
            }
            // console.log("indexArr :: ", indexArr);
            indexArr.push(general);
            if (indexArr.length == datas.length) {
              indexArr = [];
            }
            // console.log("indexArr  after push general :: ", indexArr);
            positions.indexArr = indexArr;
            // console.log(
            //   "positions.position ::: ",
            //   positions.position,
            //   "positions.counter ::: ",
            //   positions.counter,
            //   "positions.post_url ::: ",
            //   positions.post_url,
            //   "positions.indexArr :: ",
            //   positions.indexArr
            // );
            chrome.storage.local.set({ positions: positions }, function () {
              // console.log("Position i saved in storage ");
            });
          });
        }
      });
      //   }, 3000);
    } else onDomNodeInserted(general, postUrls); // If all comments are done then try to get upcomming comments
  }
}

async function startLatestPostEngagement(
  elemArray,
  general = null,
  postUrls = null,
  latestComment,
  startFrom = 0
) {
  // console.log(" start Latest Post Engagement has general::: ", startFrom, latestComment, elemArray[latestComment]);
  const hasFallback = payload.fbreplyInput ? true : false; //checking if there fallback is present or not
  const hasKeywords = payload.keywordsInput ? true : false; //checking if there keyword is present or not
  if (elemArray.length !== startFrom) {
    const isKeywordMatched = await isCommentRelevant(elemArray[latestComment]); // checking keyword is matched or not with the text of comments
    let repliedComment = false;
    if (hasFallback && hasKeywords) {
      // if fall back and keyword both are there
      // Reply from replylist if matched or fallback if not matched
      // console.log("Has keyword & has fallback");
      if (isKeywordMatched) {
        // console.log("Keyword Matched", isKeywordMatched);
        repliedComment = await initiateReply(
          elemArray[latestComment],
          payload.replyInput,
          1,
          general,
          postUrls
        );
      } else {
        // console.log("Fallback Matched", !isKeywordMatched);
        repliedComment = await initiateReply(
          elemArray[latestComment],
          payload.fbreplyInput,
          0,
          general,
          postUrls
        );
      }
    } else if (hasKeywords && !hasFallback) {
      // if there is keywords and no fall back
      // Reply only if keyword matched
      // console.log("Has keyword & but no fallback");
      if (isKeywordMatched) {
        // console.log("On Keyword matched", isKeywordMatched);
        repliedComment = await initiateReply(
          elemArray[latestComment],
          payload.replyInput,
          1,
          general,
          postUrls
        );
      } else {
        repliedComment = true;
        // console.log("Skipping");
      }
    } else if (!hasKeywords && hasFallback) {
      // if there is no keywords and fall back is there
      // Reply to all comments from reply list
      // console.log("Has no keyword & but has fallback");
      repliedComment = await initiateReply(
        elemArray[latestComment],
        payload.fbreplyInput,
        0,
        general,
        postUrls
      );
    } else if (!hasKeywords && !hasFallback) {
      //if both fall back and keyword is not there
      // Reply to all comments from reply list
      // console.log("Has no keyword & has no fallback");
      repliedComment = await initiateReply(
        elemArray[latestComment],
        payload.replyInput,
        1,
        general,
        postUrls
      );
    }
    // console.log("RECURSIVE CALL repliedComment :::::::::: ", repliedComment);
    // console.log("------------------------");
    if (repliedComment) {
      await startLatestPostEngagement(
        elemArray,
        general,
        (postUrls = null),
        latestComment - 1,
        startFrom + 1
      ); // calling start reply recursively for next comment
    }
  } else {
    // console.log("All reply done");
    // console.log("general : ", general, "tabId ::: ", postUrls);
    if (general != null && postUrls != null) {
      // console.log("general ! = null or ??? ", general);
      // setInterval(() => {
      chrome.storage.local.get(["positions"], (st) => {
        let positions = st.positions;
        // console.log("positions ::: ", positions);
        if (
          positions == undefined ||
          positions == null ||
          positions == "undefined" ||
          positions == ""
        ) {
          // positions.position = 0
          // var newPayload = {
          //     position : general
          // };
          // console.log("positions is undefined : ", )
          // chrome.storage.local.set({positions: newPayload})
        } else {
          chrome.storage.local.get("general_post_urls", function (url) {
            datas = url.general_post_urls;
            var counts = positions.counter;
            // console.log("Counts :: ", counts);
            positions.position = general;
            if (counts == 0) positions.counter = 1;
            else positions.counter = 0;
            positions.post_url = postUrls;
            if (!positions.indexArr) {
              indexArr = [];
            } else {
              indexArr = positions.indexArr;
              // console.log("indexArr in else :", indexArr);
              // console.log(
              //   "indexArr.length == datas.length : ",
              //   indexArr.length == datas.length
              // );
              // if(indexArr.length == datas.length){
              //     indexArr = [];
              // }
            }
            // console.log("indexArr :: ", indexArr);
            indexArr.push(general);
            if (indexArr.length == datas.length) {
              indexArr = [];
            }
            // console.log("indexArr  after push general :: ", indexArr);
            positions.indexArr = indexArr;
            // console.log(
            //   "positions.position ::: ",
            //   positions.position,
            //   "positions.counter ::: ",
            //   positions.counter,
            //   "positions.post_url ::: ",
            //   positions.post_url,
            //   "positions.indexArr :: ",
            //   positions.indexArr
            // );
            chrome.storage.local.set({ positions: positions }, function () {
              // console.log("Position i saved in storage ");
            });
          });
        }
      });
      //   }, 3000);
    } else {
      // console.log("All reply done");
      onDomNodeInserted(general, postUrls); // If all comments are done then try to get upcomming comments
    }
  }
}

/**
 * When a coment inserts to dom then tke action
 */
function onDomNodeInserted(general = null, postUrls = null) {
  // console.log("on Dom inserted has general ? : ");
  // if (!initiatedDomNodeInserted) {
  var parentDiv = $(".async_composer");
  initiatedDomNodeInserted = 1;
  parentDiv[0].addEventListener(
    "DOMNodeInserted",
    function () {
      if (!isCommentReplyCalled) {
        isCommentReplyCalled = 1;
        clearTimeout(PPTimeOut);
        const isLatest = payload.latest_post == "Y" ? true : false;
        // console.log("Latest post engaged ::::::::::::::::::::::::::::::::: ", isLatest);
        replyCount = 0;
        commentReply(isLatest, general, postUrls, true);
      }
    },
    false
  );
  // }
}

/**
 * If latest post engagement is 'yes' : It will again start to wait for final minimum time
 */
function latestPostEnagement(general = null, postUrls = null) {
  var parentDiv = $(".async_composer");
  initiatedDomNodeInserted = 1;
  parentDiv[0].addEventListener(
    "DOMNodeInserted",
    function () {
      const newCommentLength = $(".async_composer").find("._2a_i").length;
      if (newCommentLength > allCommentLength) {
        // console.log("Comment restarting");
        if (!isCommentReplyCalled) {
          isCommentReplyCalled = 1;
          clearTimeout(PPTimeOut);
          commentReply(true, general, postUrls);
        }
      }
    },
    false
  );
}

/**
 * after required interval of time click reply button
 * @param {object} elem comment div in facebook
 * @param {string} replyList List of reply messages
 */
async function initiateReply(
  elem,
  replyList,
  isSendMessage,
  general = null,
  postUrls = null
) {
  // console.log("Reply list", replyList);
  // console.log("Initiate Reply has general ? : ", general);
  scrollToPos(elem);
  if (!$(elem).find(".pf_replying").length) {
    $(elem)
      .find('[data-sigil="ufi-inline-comment-actions"]:first')
      .after(ppWorkingDiv);
  }
  //wait to reply after mimimum time
  const randomDelayUser = payload.random_delay
    ? parseInt(payload.random_delay) * 1000
    : 0;
  var minTime =
    parseInt(payload.min_time) * 1000 +
    generateRandomNumber(-30, 180) +
    randomDelayUser;
  let pauseWaitTimeXreplies;
  if (minTime > 60 * 1000) {
    pauseWaitTimeXreplies = minTime;
  } else {
    pauseWaitTimeXreplies = 60 * 1000;
  }
  const replyListArr = replyList.split(",");
  const replyBtn = $(elem)
    .find('[data-sigil="ufi-inline-comment-actions"]')
    .find("a:contains(Reply)");
  let reply_content = payload.tag_user == "Y" ? getTagString(elem) + " " : "";
  const randomNumber = Math.floor(Math.random() * replyListArr.length);
  console.log("print for block???????????????????????????????????????????",replyBtn[0] )
  if( replyBtn[0]){
    replyBtn[0].click();
  }
  else{
    console.log("i am skkipinng::::");
    $(elem).find(".pf_replying").remove();
    return  true;
  }
  

  // Wait to reply after x replies for y minutes
  if (payload.x_replies && replyCount == parseInt(payload.x_replies)) {
    const randomDelay = payload.random_minute
      ? parseInt(payload.random_minute) * 1000
      : 0;
    pauseWaitTimeXreplies =
      parseInt(payload.x_minutes) * 60 * 1000 +
      (generateRandomNumber(-30, 180) + randomDelay);
    // console.log("Pause after " + replyCount + " replies enabled - New waiting approx", Math.round(((pauseWaitTimeXreplies / 1000) / 60)) + "  Minutes");
  }
  PPTimeOut = await wait(2000);
  const randReply = await replyListArr[randomNumber];
  reply_content +=
    typeof randReply === "undefined" ? await replyListArr[0] : randReply;
  // Checking replies
  const replyStatus = await isReplied(elem);
  if (replyStatus) {
    // console.log("Skip");
    $(elem).addClass("postprofits_replied");
    // console.log(
    //   "ELSE not replied :::::::: 866 ::: ",
    //   general,
    //   postUrls,
    //   replyCount++,
    //   isSendMessage
    // );
    // await reSavePayload(general, postUrls, replyCount++, isSendMessage);
  } else {
    // console.log("Again wait and reply");
    await postComment(
      elem,
      pauseWaitTimeXreplies,
      reply_content,
      isSendMessage,
      general,
      postUrls
    );
  }
  $(elem).find(".pf_replying").remove();
  console.log("coming after returnnnnn???----")
  return true;
}

/**
 * Getting comments which are already replied and add that class to them
 * @param {object} elem comment div in facebook
 */
async function isReplied(elem) {
  let isReplied_to_comment;
  // console.log("In is replied method", elem);
  const subEl = $(elem).find("._2a_i");
  // console.log("subel :: ", subEl);
  // console.log("decodeURI(payload.pages) ::: ", decodeURI(payload.pages));
  if (subEl.length != 0) {
    $(subEl).each(function (i, el) {
      // console.log("this ::: ", $(this));
      let rpliers_of_Comment = $(this).find("._4kk6");
      if (rpliers_of_Comment.length == 0) {
        rpliers_of_Comment =
          $(this).find("._2b05")[0] &&
          $(this).find("._2b05")[0].textContent &&
          $(this).find("._2b05")[0].textContent.replace("Author", "");
      } else {
        rpliers_of_Comment = rpliers_of_Comment[1].textContent;
      }
      if (rpliers_of_Comment.toLocaleLowerCase().trim().includes("author")) {
        // console.log("author is there baby");
        rpliers_of_Comment = rpliers_of_Comment
          .toLocaleLowerCase()
          .trim()
          .replace("author", "");
        // console.log("rpliers_of_Comment :::: 1 :::: ", rpliers_of_Comment)
      }
      isReplied_to_comment =
        (decodeURI(payload.user) &&
          rpliers_of_Comment.toLocaleLowerCase().trim() ==
            decodeURI(payload.user).toLocaleLowerCase().trim()) ||
        (decodeURI(payload.pages) &&
          rpliers_of_Comment.toLocaleLowerCase().trim() ==
            decodeURI(payload.pages).toLocaleLowerCase().trim());
      // console.log("isReplied_to_comment ::: ", isReplied_to_comment);
      if (isReplied_to_comment) count_replied = 1;
    });
    // console.log("count_replied ::: ", count_replied);
    if (count_replied) {
      count_replied = 0;
      $(elem).addClass("postprofits_replied");
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
}

/***
 * Getting commentor name, id, groupid and send them as payload via background
 * @param {object} paramObj Commentor name, Commentor ID, Group id
 */
async function initiateMessaging(paramObj) {
  const nameArr = paramObj.name.split(" ");
  const messagingPayload = {
    action: "openPerson",
    userData: {
      name: paramObj.name,
      fname: nameArr[0],
      lname: nameArr[1],
      mobileUrl: "https://m.facebook.com/messages/thread/" + paramObj.userID,
      groupID: paramObj.groupID,
      postUrls: paramObj.postUrls,
      general: paramObj.general,
    },
  };
  // connectPort();
  await port.postMessage(messagingPayload);
}

/**
 * Post the reply
 * @param {object} elem post prifit will comment in this div
 * @param {number} timeout waiting time betwwn two replies
 * @param {string} replyMsg Text of reply message
 */
async function postComment(
  elem,
  timeout,
  replyMsg,
  isSendMessage,
  general = null,
  postUrls = null
) {
  PPTimeOut = await wait(timeout);
  //  PPTimeOut = await wait(30000);
  clearTimeout(PPTimeOut);
  const replyStatusRepeat = await isReplied(elem);
  if (!replyStatusRepeat) {
    $(elem).addClass("postprofits_replied").addClass("replyCounted");
    const input = $(elem).find('input[name="comment_text"]');
    const submit_btn = $(elem).find('button[type="submit"]');
    input.val(replyMsg);
    submit_btn.removeAttr("disabled");
    submit_btn.click();
    replyCount++;
    if (!isEmptyObj(payload.groupid)) {
      if (isSendMessage == 1) {
        await initiateMessaging({
          name: getCommenterName(elem),
          userID: getCommenterId(elem),
          groupID: payload.groupid,
          postUrls: postUrls,
          general: general,
        });
        var waitTime = await wait(6000);
        clearTimeout(waitTime);
        await reSavePayload(general, postUrls, replyCount, isSendMessage);
      } else {
        await reSavePayload(general, postUrls, replyCount, isSendMessage);
      }
    } else {
      await reSavePayload(general, postUrls, replyCount, isSendMessage);
    }
  } else {
    $(elem).addClass("postprofits_replied");
    // console.log("ELSE not replied :::::::: 861 ::: ", general, postUrls, replyCount++, isSendMessage)
    await reSavePayload(general, postUrls, replyCount++, isSendMessage);
  }
}

/**
 * resave the total count of comment and total replie comments of payload
 * @param {number} replyCount Number of replied comments
 */
async function reSavePayload(
  general = null,
  postUrls = null,
  replyCount = 0,
  isSendMessage = 0
) {
  if (general != null) {
    // console.log("replyCount :: ", replyCount);
    // console.log("replyCount==1? :: ", (replyCount==1));
    if (replyCount == 1) {
      // console.log("replyCount in if condition :: ", replyCount);
      const generalSetting = await helper.getGeneralSettings();
      // console.log("generalSetting : ", generalSetting);
      generalSetting[0].totalComments = commentCounts.totalCount;
      generalSetting[0].replyCount = commentCounts.repliedCount + replyCount;
      await helper.saveGeneralSettings(generalSetting);
      //  if(isSendMessage != 1){
      chrome.storage.local.get(["positions"], (st) => {
        // console.log("in resave payload postUrls : ", postUrls);
        let positions = st.positions;
        // console.log("positions ::: ", positions);
        if (
          positions == undefined ||
          positions == null ||
          positions == "undefined" ||
          positions == ""
        ) {
        } else {
          chrome.storage.local.get("general_post_urls", function (url) {
            datas = url.general_post_urls;
            var counts = positions.counter;
            // console.log("Counts :: ", counts)
            positions.position = general;
            if (counts == 0) positions.counter = 1;
            else positions.counter = 0;
            positions.post_url = postUrls;
            if (!positions.indexArr) {
              indexArr = [];
            } else {
              indexArr = positions.indexArr;
              // console.log("indexArr in else:", indexArr);
              // console.log(
              //   "indexArr.length == datas.length : ",
              //   indexArr.length == datas.length
              // );

              // if(indexArr.length == datas.length){
              //     indexArr = [];
              // }
            }
            // console.log("indexArr :: ", indexArr);
            indexArr.push(general);
            if (indexArr.length == datas.length) {
              indexArr = [];
            }
            // console.log("indexArr  after push general :: ", indexArr);
            positions.indexArr = indexArr;
            // console.log(
            //   "positions.position ::: ",
            //   positions.position,
            //   "positions.counter ::: ",
            //   positions.counter,
            //   "positions.post_url ::: ",
            //   positions.post_url,
            //   "positions.indexArr :: ",
            //   positions.indexArr
            // );
            chrome.storage.local.set({ positions: positions }, function () {
              // console.log("Position i saved in storage ");
            });
          });
        }
      });
      // }
    }
  } else {
    const settings = await helper.getSettings();
    // console.log("settings ::: at content js::::::: ", settings);
    if (currPayloadtabId !== null) {
      // console.log("payload tbID inside conditin", currPayloadtabId);
      for (let idx in settings) {
        if(settings[idx].tabId ){
          // console.log("curr item tab id...",settings[idx].tabId)
          if (settings[idx].tabId === currPayloadtabId) {
            settings[idx].totalComments = commentCounts.totalCount;
      settings[idx].replyCount = commentCounts.repliedCount + replyCount;
        }
        }
       
      }
    }

    // newSett= settings.map((item)=>{
    //   if(item?.tabId&&item.tabId===currPayloadtabId){
    //     item.totalComment=commentCounts.totalCount
    //     item.replyCount= commentCounts.repliedCount + replyCount;
    //   }
    //   return item
    // })
    // console.log("new setttttttt........>>>>",newSett)

    await helper.saveSettings(settings);
  }
}

const isUserRepliedComment = (el) => {
  const reply_see_text = $(el)
    .find('[data-sigil="replies-see-more"]')
    .find("a");
  // console.log("reply_see_text of replied part ::: ", reply_see_text)

  const toBeRepliedAs = payload.reply_from_where;
  const pages =
    decodeURI(payload.pages) + ",You" + "," + decodeURI(payload.user);
  const repliers = pages.split(",").map((el) => el.toLowerCase() + " replied");
  // console.log("repliers of replied part ::: ", repliers)
  const isUserReplied = repliers.some(
    (e) => reply_see_text.text().trim().toLowerCase().indexOf(e) === 0
  );
  // console.log("isUserReplied of replied part ::: ", isUserReplied)
  if (reply_see_text.length && isUserReplied) {
    // $(this).addClass("postprofits_replied").addClass("replyCounted");
    return true;
  } else {
    return false;
  }
};

/**
 * adding class to the replied comments
 */
async function addingClassToRepliedComments() {
  /* Uncomment the below code if you want the bot to skip replying 
     the comments even any of your tagged page or you replied to the comment */

  replyCount = 0;
  $(".async_composer")
    .find("[data-sigil='comment']")
    .each(async function (i, el) {
      //  console.log("el ::: ", el)
      const isUserReplied = isUserRepliedComment(el);
      // console.log("isUserReplied :::::::::::: ", isUserReplied)

      const hasFallback = payload.fbreplyInput ? true : false;
      const hasKeywords = payload.keywordsInput ? true : false;
      const reply_see_text = $(el)
        .find('[data-sigil="replies-see-more"]')
        .find("a");
      const reply_see_text_length = reply_see_text.length;
      const nested_comment_length = $(el).find(
        '[data-sigil="comment inline-reply"]'
      ).length;
      const hasNested =
        reply_see_text_length || nested_comment_length ? true : false;
      const flagOwnComment = await isOwnComment(el);
      const replyStatus = await isReplied(el);
      if (!flagOwnComment && replyStatus) {
        $(this)
          .addClass("postprofits_replied")
          .addClass("replyCounted")
          .addClass("totalCounted");
      } else if (flagOwnComment) {
        $(this).addClass("postprofits_replied");
      }
      if (hasKeywords && hasFallback && !flagOwnComment) {
        $(this).addClass("totalCounted");
        if (isUserReplied) {
          $(this).addClass("postprofits_replied").addClass("replyCounted");
          // .css("background-color","red");
        }
      } else if (hasKeywords && !hasFallback && !flagOwnComment) {
        const elem = $(this);
        // totalCommentsCount = totalCommentsCount + 1;
        const bool = await isCommentRelevant(elem[0]);
        // console.log("bool : ", bool);
        if (isUserReplied && !bool) {
          //
          $(this).addClass("postprofits_replied");
          // .css("background-color","red");
        } else if (isUserReplied && bool) {
          //hasNested &&
          $(this)
            .addClass("totalCounted")
            .addClass("replyCounted")
            .addClass("postprofits_replied");
          // .css("background-color","yellow");
        } else if (!isUserReplied && bool) {
          //!hasNested &&
          $(this).addClass("totalCounted");
          // .css("background-color","green");
        } else {
          $(this).addClass("postprofits_replied");
          // .css("background-color","red");
        }
      } else if (!hasKeywords && !hasFallback && !flagOwnComment) {
        $(this).addClass("totalCounted");
        if (isUserReplied) {
          $(this)
            .addClass("totalCounted")
            .addClass("replyCounted")
            .addClass("postprofits_replied");
          // .css("background-color","yellow");
        } else if (!isUserReplied) {
          $(this).addClass("totalCounted");
          // .css("background-color","green");
        }
      } else {
        // console.log("*************************************** XXXXXXXXX *****************************************", $(this))
        $(this).addClass("postprofits_replied");
        // .css("background-color","red");
      }
    });
}

/**
 * count total relevant comments
 */
async function countTotalRelevantComments(general = null, postUrls = null) {
  // console.log("Count total relevant comments has general ? : ", general);
  const totalCount = $(".totalCounted").length;
  const repliedCount = $(".replyCounted").length;
  commentCounts = {
    totalCount: totalCount,
    repliedCount: repliedCount,
  };
  // console.log("commentCounts :::: ", commentCounts);
  await reSavePayload(general, postUrls);
}

/**
 * checking the comment is relevant or not as per the requirements
 * @param {object} CommentEl comment div in facebook
 * @returns {boolean}
 */
async function isCommentRelevant(commentEl) {
  // console.log($(commentEl).not(".postprofits_replied"));
  //  const userComment = $(commentEl).find('[data-sigil="comment-body"]').text().trim().toLowerCase();
  // console.log("Comment", userComment);
  const keywords = payload.keywordsInput.split(",");
  // console.log("keywords : ",keywords );
  // console.log("payload : ",payload );
  return await keywords.some((arrEl) => {
    const userComment = $(commentEl)
      .find('[data-sigil="comment-body"]')
      .first()
      .text()
      .trim()
      .toLowerCase();
    var filter_text = arrEl.trim().toLowerCase();
    // console.log("Comment", userComment);
    // console.log("filter_text ::: ", filter_text);
    return userComment.indexOf(filter_text) > -1;
    //  if (userComment.indexOf(filter_text) > -1) {
    //      return true;
    //  } else {
    //      return false;
    //  }
  });
}

/**
 * checking is the commentor is himself or not
 * @param {object} commentEL comment div in facebook
 */
async function isOwnComment(commentEL) {
  const commentor = getCommenterName(commentEL).toLowerCase().trim();
  // console.log("In is own comment ::::::::::::: ", commentor);
  let repliers = [userData.username];
  if (payload.reply_from_where !== "User") {
    repliers = payload.pages.split(",");
  }
  const isOwnComment = repliers.some((e) => {
    // console.log("repliers ::: ", e.toLowerCase().trim());

    // console.log(commentor.indexOf(e.toLowerCase().trim()));
    return commentor.indexOf(e.toLowerCase().trim()) == 0;
  });
  // console.log("isOwnComment        :::::::::::::::::::             ", isOwnComment)
  return await isOwnComment;
}

function getRandomNumberForCreateReplies(max) {
  return Math.floor(Math.random() * max) + 1;
}

/**
 *
 * @param {number} min minimum number of a range
 * @param {number} max maximum number of a range
 */
function generateRandomNumber(min, max) {
  // min and max
  return (Math.random() * (max - min + 1) + min) * 1000;
}

/**
 * get commentor name and id
 * @param {object} comment comment div in facebook
 * @returns {string} commentor Id + name
 */
function getTagString(comment) {
  return (
    "@[" +
    getCommenterId(comment).trim() +
    ":" +
    getCommenterName(comment).trim() +
    "]"
  );
}

/**
 * get commentor name
 * @param {object} comment comment div in facebook
 * @returns {string} commentor name
 */
function getCommenterName(comment) {
  return $(comment).find("._2b05 > a").first().text();
}

/**
 * get commentor id
 * @param {object} comment comment div in facebook
 * @returns {string} commentor ID
 */
function getCommenterId(comment) {
  let elm = $(comment).find('div[data-sigil^="feed_story_ring"]');
  let c_id = elm.attr("data-sigil").replace("feed_story_ring", "");
  // console.log("commenterid::: ", c_id)
  return c_id;
}

/**
 * Scroll to the position where post profits start take action
 * @param {object} el comment div
 */
function scrollToPos(el) {
  $("html,body").animate(
    {
      scrollTop: $(el).offset().top - 15,
    },
    "slow"
  );
}

/**
 *
 * @param {string} obj groupid
 * @returns {boolean}
 */
function isEmptyObj(obj) {
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) return false;
  }
  return true;
}

/* ---------------- START SENDING MESSAGES ------------------- */

/**
 * FUNCTIONS FOR SENDING FRIEND REQUEST TO SUGGESTED PEOPLE
 * @param {Object} param payload from background js
 */
async function sendMessageToFriend(param) {
  // console.log("Send message param", param);
  chrome.storage.local.get("fcmessages", async function (items) {
    // console.log("items.fcmessages : ", items.fcmessages);
    // Assigning to a variable
    if (typeof items.fcmessages !== "undefined") {
      // console.log("Initiate to send message");
      messages = items.fcmessages;
      groupID = param.userData.groupID;
      // console.log("Group ID : ", groupID);
      // console.log("Group : ", messages.groups);
      for (i = 0; i < messages.groups.length; ++i) {
        if (messages.groups[i].id === groupID) {
          filteredGroup = messages.groups[i];
        }
      }
      // console.log("filteredGroup : ", filteredGroup);
      const groupSet = filteredGroup.blocksPos;
      // console.log("groupSet : ", groupSet);
      const randGroupSet = await chooseRandomArray(groupSet);
      // console.log("randGroupSet : ", randGroupSet);
      const constructedMsg = await createMessage(randGroupSet, param.userData);
      // console.log("Constructed Message", constructedMsg);
      await $("textarea").text(
        replaceAll(constructedMsg, "{Last_Name}", param.userData.lname)
      );
      // Will simulate send.
      setTimeout(async function () {
        await simulateSend(param.postUrls, param.general);
      }, 1000);
    } else {
      // console.log("Will close the window");
      // connectPort();
      port.postMessage({
        action: "ClosingTab",
        tabId: param.tab.id,
        postUrls: param.postUrls,
        general: param.general,
      });
    }
  });
  // await wait(10000);
  setTimeout(function () {
    // console.log("Will close the window.......");postUrls: param.postUrls
    port.postMessage({
      action: "ClosingTab",
      tabId: param.tab.id,
      postUrls: param.postUrls,
      general: param.general,
    });
  }, 5000);
}
/**
 * FUNCTION FOR CONSTRUCTING THE MESSAGE
 * @param {Array} groupArr Array of Group set in local storage
 * @param {Object} data User first name or last name to replace with actual name
 */
async function createMessage(groupArr, data) {
  // console.log(groupArr);
  let constructMsg = "";
  for (var i = 0; i < groupArr.length; i++) {
    // console.log(groupArr[i]);
    if (i) {
      constructMsg += " " + (await returnSegmentBySegmentID(groupArr[i]));
    } else {
      constructMsg += await returnSegmentBySegmentID(groupArr[i]);
    }
    // console.log(constructMsg);
  }
  return await replaceAll(constructMsg, "{First_Name}", data.fname);
}
/**
 * Function for replacing all occurance
 * @param {*} str The input string from where the item to be replaced
 * @param {*} find The word that is going to be replaced with
 * @param {*} replace The replacement word that is going to be replaced.
 */
function replaceAll(str, find, replace) {
  // console.log("*******************fire ***********************", str, find, replace);
  return str.replace(new RegExp(find, "g"), replace);
}
/**
 * FUNCTION FOR FETCHING THE SEGMENT BY POSITION
 * @param {*} pos Array Element of segment or static text for fetching either segment or return the text
 */
async function returnSegmentBySegmentID(pos) {
  if (!isNaN(parseInt(pos))) {
    // console.log("Find the segment which has id", pos);
    // console.log("Segments", messages.segments);
    /* Filter out segment with the id */
    const segment = await messages.segments.find((item) => {
      return parseInt(item.id) === pos;
    });
    /* Create a random number to choose one, max length would be the length of that perticular segment blocks */
    const randomNumber = Math.floor(Math.random() * segment.blocks.length);
    /* Randomize the blocks array of that filtered segment and return one array element and return */
    return await segment.blocks[randomNumber];
  } else {
    /* Return if not a segment */
    return await pos;
  }
}

/*function notifyProgress(totalCommentsCount, replyCount, isInitiated = false) {
     const param = {
         action: "notifyProgress",
         payload: {
             id: payload.card_title,
             cardTitle: payload.card_title,
             totalComments: totalCommentsCount,
             commented: replyCount,
             initiated: isInitiated
         }
     };
     port.postMessage(param)
 }*/

/** FUNCTION FOR SIMULATING SEND BUTTON
 */
async function simulateSend(postUrls, general) {
  // console.log("In send Simulation");
  var txtbox = document.querySelector(".input");
  // console.log("txtbox ::: ", txtbox);
  txtbox.onkeydown = function (e) {
    if (e.key == "Enter") {
      // console.log("Enter Pressed");
    }
    e.preventDefault();
  };

  var ev = await new KeyboardEvent("keydown", {
    altKey: false,
    bubbles: true,
    cancelBubble: false,
    cancelable: true,
    charCode: 0,
    code: "Enter",
    composed: true,
    ctrlKey: false,
    currentTarget: null,
    defaultPrevented: true,
    detail: 0,
    eventPhase: 0,
    isComposing: false,
    isTrusted: true,
    key: "Enter",
    keyCode: 13,
    location: 0,
    metaKey: false,
    repeat: false,
    returnValue: false,
    shiftKey: false,
    type: "keydown",
    which: 13,
  });

  await txtbox.dispatchEvent(ev);
  // setTimeout(function() {
  var buttonSend = await document.getElementsByClassName("btnC");
  await buttonSend[0].click();
  await setTimeout(function () {
    port.postMessage({
      action: "ClosingTab",
      tabId: param.tab.id,
      postUrls: postUrls,
      general: general,
    });
  }, 1000);
}

async function chooseRandomArray(items) {
  return await items[Math.floor(Math.random() * items.length)];
}
/* ---------------- END SENDING MESSAGES ------------------- */
