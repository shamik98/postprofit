//5e944f24568e944b9d22418f
// console.log("content_script.js is running");
const $ = (jQuery = require("jquery"));
const helper = require("./helper.js");
const { param } = require("jquery");
const { isReturnStatement } = require("typescript");
const configStore = require("../public/kyubiSettings.json");
const { generalPPStorage } = require("./storage.js");

let processed_posts_count = 0;
let processed_posts_count_in_mfb = 0;
let popUpmenuBox = "";
let PopupMenuBox_children = "";
let PPInterval = 0;
let PPPInterval = 0;
let PopupOpened = false;
let menueButton = "";
let menueButton_in_mfb = ";";
let mFBdata = {};
let dataStore;
let messageId;
let elem;
let settingsUrl, plan;
let post_id = [];
let saveName;
// console.log("Post id : ", post_id);
const comments_container_selector = "._333v._45kb";
const comment_selector = "._2a_i";
const page_selctor = document.getElementsByClassName(
  "_54k8 _52jg _56bs _26vk _56bu"
);
const post_url = new URL(window.location);
var port = chrome.runtime.connect({
  name: "Popup-Background",
});
// let latest_post;
let regexPages = {
  facebook: /^(http|https):\/\/(www.)*(facebook)(\.com)/,
  groups: /^(http|https):\/\/(www.)*(facebook)(\.com)\/groups/,
};
console.log("regexPages ::", regexPages);
let fbUserData = {};
const isEmptyObj = function (obj) {
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) return false;
  }
  return true;
};

$(document).ready(function () {
  // console.log("Doc is ready post profits")
  chrome.storage.local.get(["store"], function (res) {
    // console.log("res ::: ", res);
    // console.log("Checkig logged in already or not", helper.checkAccessToken(res));
    if (helper.checkAccessToken(res)) {
      chrome.runtime.onMessage.addListener(PPcbListener);
      getPlan(res.store.user.email, configStore.extId);
      /* JIT -- Setting up a cookie for facebook user's name */
      // For initial setup user has to be in facebook homepage
      if (regexPages.facebook.test(window.location.href)) {
        // Create cookie and save user's name from header
        // const option = $("a[data-testid^='left_nav_item']");
        // console.log("62 ---------------- > ",res.store.user.email, configStore.extId)
        setTimeout(function () {
          const option = $(
            'h1[class="x1heor9g x1qlqyl8 x1pd3egz x1a2a7pz"]'
          ).last();
          // console.log("option ::::::::------------------------------- ", option);
          if (option.length) {
            chrome.storage.local.get(["userFBData"], function (obj) {
              const profile = option[0].textContent;
              const username = profile.split("(")[0];
              // console.log("username : ", username);
              // console.log("userFBData : ", obj.userFBData);
              const profileLink = window.location.href;
              const userid = profileLink.split("?").pop();
              if (obj.userFBData == undefined) {
                // console.log("saveName : ",obj.userFBData.saveName);
                fbUserData = {
                  username: username,
                  profile: profileLink,
                  userID: userid,
                  saveName: "yes",
                };
                // console.log("fbUserData :::::::::::::::::::::: ", fbUserData)
                chrome.storage.local.set({ userFBData: fbUserData });
              } else if (obj.userFBData.saveName == "yes") {
                fbUserData = {
                  username: username,
                  profile: profileLink,
                  userID: userid,
                  saveName: "yes",
                };
                // console.log("fbUserData 92 :::::::::::::::::::::: ", fbUserData)
                chrome.storage.local.set({ userFBData: fbUserData });
              }
            });
          }
        }, 6000);
      }
      // Save user's basic data into localstorage

      /* JIT -- END*/
      const loaderHtm = `<div class="ext_loader" style="display:none"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
    <circle cx="50" cy="50" r="32" stroke-width="8" stroke="#4267b2" stroke-dasharray="50.26548245743669 50.26548245743669" fill="none" stroke-linecap="round" transform="rotate(63.8978 50 50)">
    <animateTransform attributeName="transform" type="rotate" dur="1s" repeatCount="indefinite" keyTimes="0;1" values="0 50 50;360 50 50"></animateTransform>
    </circle>
    <circle cx="50" cy="50" r="23" stroke-width="8" stroke="rgba(66, 103, 178, 0.13725806451612899)" stroke-dasharray="36.12831551628262 36.12831551628262" stroke-dashoffset="36.12831551628262" fill="none" stroke-linecap="round" transform="rotate(-63.8978 50 50)">
    <animateTransform attributeName="transform" type="rotate" dur="1s" repeatCount="indefinite" keyTimes="0;1" values="0 50 50;-360 50 50"></animateTransform>
    </circle>
    </svg></div>`;
      $("body").prepend(loaderHtm);

      // chrome.runtime.onMessage.addListener(cbListener);

      doInit();
      onElementHeightChange(document.body, function () {
        // console.log("Body height changes");
        doInit();
      });
    }
  });
});

function getPlan(email, extId) {
  // console.log("in get plan the params are ::: ", email, extId)
  fetch("https://app.kyubi.io/api/end-user/get-plan", {
    method: "POST", // *GET, POST, PUT, DELETE, etc.
    mode: "cors", // no-cors, cors, *same-origin
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({
      email: email,
      extnsion_id: extId,
    }), // body data type must match "Content-Type" header
    redirect: "follow",
  })
    .then((response) => response.json())
    .then((res) => {
      // console.log("res ::: ", res.payload);
      if (res.payload.length != 0) {
        // console.log("payload ::: ", res.payload.plan_details.id);
        plan = res.payload.plan_details.id;
      }
    })
    .catch((err) => {});
}

function PPcbListener(param) {
  // console.log("Payload", param);
  switch (param.action) {
    case "openSettings": // open Settings page
      // console.log("Payload", param);
      openSettingsPage(param);
      break;
  }

  return true;
}

function doInit() {
  //To Intial the post added checking and our menu button as well.
  post_count = $('div[aria-label="Actions for this post"]').parent().length;
  // console.log("post count ::: ", post_count);
  if (!post_count) {
    processed_posts_count = 0;
    // console.log("Intitial has been paused because post are " + post_count);
    setTimeout(doInit, 500);
    return;
  }
  if (post_count > processed_posts_count) {
    // console.log("Now posts are = " + post_count);
    MenuItemInterval = setInterval(function () {
      // menueButton = $(
      //   ".nqmvxvec.j83agx80.jnigpg78.cxgpxx05.dflh9lhu.sj5x9vvc.scb9dxdr.odw8uiq3"
      // );
      // if(menueButton.length === 0){
      menueButton = $('div[aria-label="Actions for this post"]').parent();
      // }
      // console.log("menueButtonChild :: ", menueButton);
      var dataPostposition = 0;
      $.each(menueButton, function () {
        // console.log($(this)[0]);
        // var dotsButton = $(this)[0];
        $(this).attr("data-postposition", dataPostposition);
        dataPostposition++;
      });
      if (menueButton.children().eq(0).length) {
        clearInterval(MenuItemInterval);
        // console.log("Calling a function", menueButton);
        attachClickEvent(menueButton);
      }
    }, 500);
    processed_posts_count = post_count;
  }
}

function attachClickEvent(menueButton) {
  menueButton.click(function () {
    // console.log("Listnening to this click event. :: ", $(this));
    // console.log("PopupOpened ::: ",PopupOpened)

    // const postObjElArr = $(this).closest('div[aria-labelledby^="jsc_c_"]');//(".x1ja2u2z.x1n2onr6"); // immeiate post of the clicked three dots

    const postObjElArr = $(this)
      .parent()
      .parent()
      .parent()
      .parent()
      .parent()
      .parent()
      .parent()
      .parent()
      .parent();

    // console.log("postObjElArr : ", postObjElArr);
    if (PPInterval) {
      clearInterval(PPInterval);
    }

    PPInterval = setInterval(function () {
      // popUpmenuBox = $('div[role="menu"][class="x1n2onr6 x1fayt1i xcxhlts"]');
      popUpmenuBox = $('div[role="menu"][class="x1n2onr6 xcxhlts x1fayt1i"]');

      console.log("popUpmenuBox :: ", popUpmenuBox);
      if (popUpmenuBox.length === 0)
        popUpmenuBox = $('div[role="menu"][class="x1n2onr6 xcxhlts"]');
      // console.log('popUpmenuBox :: ', popUpmenuBox);
      PopupMenuBox_children = $(
        popUpmenuBox
          .children()
          .children()
          .children()
          .children()
          .children()
          .children()
          .eq(0)
      );
      // console.log('PopupMenuBox_children :: ', PopupMenuBox_children);
      if (PopupMenuBox_children.children().eq(0).length) {
        clearInterval(PPInterval);
        // console.log("I'm inside this : ",$(this));

        const postBodyEl = postObjElArr[0];
        //console.log("postBodyEl : ", postBodyEl, PopupMenuBox_children.children());
        console.log("postBodyEl : ", postBodyEl);

        addCFmenuLink(postBodyEl, PopupMenuBox_children.children());
      }
    }, 500);
  });
}

function addCFmenuLink(postBodyEl, menueItems) {
  var already_exists;
  // console.log("menueItems ::: ", menueItems);
  Array.prototype.forEach.call(menueItems, (child, i) => {
    // console.log("child ::: ", child);
    if ($(child).hasClass("postProfits")) {
      already_exists = true;
    }
  });
  let canDelete;
  var isThisAds = false;

  Array.prototype.forEach.call(menueItems, (child) => {
    if (
      $(child)[0].textContent.toLowerCase().trim() ===
      "why am i seeing this ad?".toLowerCase().trim()
    ) {
      isThisAds = true;
    }
  });

  if (!menueItems.length) {
    //if the popup opened but the content inside has not fully loaded
    return;
  }

  if (already_exists && isThisAds) {
    clearInterval(PPInterval);
    return;
  }

  //To get the Message id of the selected post
  if (popUpmenuBox && !already_exists && !isThisAds) {
    // console.log("canDelete in on popUpmenuBox : ",  canDelete);
    chrome.storage.local.get(["userFBData"], function (obj) {
      // console.log("obj : ", obj);
      if (isEmptyObj(obj)) {
        window.location.href = "https://www.facebook.com/profile.php";
      }
    });

    //If the seleted post has open the feed post menu popup and the Comment funnel menu is not exist

    // console.log("CHILDREN POPUP MENUBOX", PopupMenuBox_children[0]);
    var parser = new DOMParser();
    const htmlMenu1 = `<div class="postProfits x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou xe8uvvx x1hl2dhg xggy1nq x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x87ps6o x1lku1pv x1a2a7pz xjyslct x9f619 x1ypdohk x78zum5 x1q0g3np x2lah0s x1w4qvff x13mpval xdj266r xat24cr x1n2onr6 x16tdsg8 x1ja2u2z x6s0dn4 x1y1aw1k x1sxyh0 xwib8y2 xurb0ha" role="menuitem" tabindex="-1">
                        <div class="x6s0dn4 xoi2r2e x78zum5 xl56j7k xq8finb">
                          <img  src="${chrome.runtime.getURL(
                            configStore.logo.large_icon
                          )}" alt="" height="20" width="20">
                        </div>
                        <div class="x6s0dn4 x78zum5 x1q0g3np x1iyjqo2 x1qughib xeuugli">
                            <div class="x78zum5 xdt5ytf xz62fqu x16ldp7u">
                                <div class="xu06os2 x1ok221b">
                                    <span class="x193iq5w xeuugli x13faqbe x1vvkbs x10flsy6 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x4zkp8e x41vudc x6prxxf xvq8zen xk50ysn xzsf02u x1yc453h" dir="auto">
                                        ${configStore.appName}
                                    </span>
                                </div>
                                <div class="xu06os2 x1ok221b">
                                    <span class="x193iq5w xeuugli x13faqbe x1vvkbs x10flsy6 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x1tu3fi x3x7a5m x1pg5gke xvq8zen xo1l8bm xi81zsa x1yc453h" dir="auto">
                                    Save this post and reply comments for the same. 
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x1ey2m1c xds687c xg01cxk x47corl x10l6tqk x17qophe x13vifvy x1ebt8du x19991ni x1dhq9h" data-visualcompletion="ignore">
                        </div>
                      </div>`;
    var doc = parser.parseFromString(htmlMenu1, "text/html");
    PopupMenuBox_children[0].prepend(doc.body.firstChild);

    // addedMenue.find
    $(".postProfits").click(function () {
      console.log("use pp is clicked.", postBodyEl);
      const allUrlsOfPsts = $($(postBodyEl).find(".xu06os2.x1ok221b")[1]).find(
        'a[role="link"]'
      );
      console.log("allUrlsOfPsts ::::::::::::::: ", allUrlsOfPsts);
      allUrlsOfPsts[0].dispatchEvent(
        new FocusEvent("focusin", {
          view: window,
          bubbles: true,
          cancelable: true,
        })
      );
      setTimeout(function () {
        var messageId;
        // console.log("$(allUrlsOfPsts[i]).attr " , $(allUrlsOfPsts[0]).attr("href"));
        if (window.location.href.includes("profile")) {
          // console.log("profile");
          // for (var i = 0; i < allUrlsOfPsts.length; ++i) {
          if ($(allUrlsOfPsts[0]).attr("href").includes("story_fbid")) {
            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .split("story_fbid=")[1]
              .split("&")[0];
            // break;
          } else if ($(allUrlsOfPsts[0]).attr("href").includes("posts")) {
            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .split("posts/")[1]
              .split("?")[0];
          } else if ($(allUrlsOfPsts[0]).attr("href").includes("videos")) {
            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .split("videos/")[1]
              .split("?")[0];
          } else if ($(allUrlsOfPsts[0]).attr("href").includes("watch/?v=")) {
            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .split("watch/?v=")[1]
              .split("&")[0];
          }
          // }
        } else if (window.location.href.includes("groups")) {
          // for (var i = 0; i < allUrlsOfPsts.length; ++i) {
          if ($(allUrlsOfPsts[0]).attr("href").includes("multi_permalinks")) {
            if (
              $(allUrlsOfPsts[0])
                .attr("href")
                .split("multi_permalinks=")[1]
                .split("&")[0] !== undefined
            )
              messageId = $(allUrlsOfPsts[0])
                .attr("href")
                .split("multi_permalinks=")[1]
                .split("&")[0];
            // break;
          } else if ($(allUrlsOfPsts[0]).attr("href").includes("videos")) {
            if (
              $(allUrlsOfPsts[0])
                .attr("href")
                .split("videos/")[1]
                .split("?")[0] !== undefined
            )
              messageId = $(allUrlsOfPsts[0])
                .attr("href")
                .split("videos/")[1]
                .split("?")[0];
          } else if ($(allUrlsOfPsts[0]).attr("href").includes("groups")) {
            // console.log("allUrlsOfPsts["+i+"] ::: ", $(allUrlsOfPsts[0]).attr("href").split("groups/")[1].split("?")[0].split("posts/")[1])
            if (
              $(allUrlsOfPsts[0])
                .attr("href")
                .split("groups/")[1]
                .split("?")[0]
                .split("posts/")[1] !== undefined
            )
              messageId = $(allUrlsOfPsts[0])
                .attr("href")
                .split("groups/")[1]
                .split("?")[0]
                .split("posts/")[1];
          } else if ($(allUrlsOfPsts[0]).attr("href").includes("watch/?v=")) {
            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .split("watch/?v=")[1]
              .split("&")[0];
          }
          // }
        } else if (
          window.location.href === "https://www.facebook.com/" ||
          window.location.href === "https://www.facebook.com"
        ) {
          console.log("home");
          // for (var i = 0; i < allUrlsOfPsts.length; ++i) {
          if ($(allUrlsOfPsts[0]).attr("href").includes("story_fbid")) {
            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .split("story_fbid=")[1]
              .split("&")[0];
            // break;
          } else if ($(allUrlsOfPsts[0]).attr("href").includes("videos")) {
            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .split("videos/")[1]
              .split("?")[0];
          } else if ($(allUrlsOfPsts[0]).attr("href").includes("photo")) {
            console.log(
              "Yessss",
              $(allUrlsOfPsts[0]).attr("href").includes("photo")
            );
            console.log("111111111", allUrlsOfPsts[0]);
            console.log("2222222", $(allUrlsOfPsts[0]).attr("href"));

            // var url = $(allUrlsOfPsts[0]).attr("href")
            // var replacedUrl = url.replace("www.facebook", "m.facebook");
            // console.log('replacedUrl', replacedUrl)

            // console.log('333333', $(allUrlsOfPsts[0]).attr("href").split("photo/")[1]);
            // console.log('4444444', $(allUrlsOfPsts[0]).attr("href").split("photo/")[1].split("?")[1]);
            // console.log('5555555', $(allUrlsOfPsts[0]).attr("href").split("photo/")[1].split("?")[1].split("&__cft__")[0]);

            console.log(
              "333333",
              $(allUrlsOfPsts[0])
                .attr("href")
                .split("com/")[1]
                .split("&__cft__")[0]
            );

            // messageId = $(allUrlsOfPsts[0])
            //   .attr("href")
            //   .split("photo/")[1]
            //   .split("?")[1].split("&__cft__")[0];

            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .split("com/")[1]
              .split("&__cft__")[0];
            // messageId=replacedUrl

            console.log("messageId", messageId);
          } else if ($(allUrlsOfPsts[0]).attr("href").includes("groups")) {
            console.log(
              "Yessss",
              $(allUrlsOfPsts[0]).attr("href").includes("groups")
            );
            console.log("111111111", allUrlsOfPsts[0]);
            console.log("2222222", $(allUrlsOfPsts[0]).attr("href"));
            // console.log('333333', $(allUrlsOfPsts[0]).attr("href").split("&__cft__")[0]);

            console.log(
              "333333",
              $(allUrlsOfPsts[0])
                .attr("href")
                .replace("https://www.facebook.com", "")
                .split("/?")[0]
            );
            // console.log('333333', $(allUrlsOfPsts[0]).attr("href").split("groups/")[1].split("?")[0]);

            // messageId = $(allUrlsOfPsts[0])
            //   .attr("href")
            //   .split("groups/")[1]
            //   .split("?")[0];

            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .replace("https://www.facebook.com", "")
              .split("/?")[0];
          } else if ($(allUrlsOfPsts[0]).attr("href").includes("watch/?v=")) {
            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .split("watch/?v=")[1]
              .split("&")[0];
          } else if ($(allUrlsOfPsts[0]).attr("href").includes("posts")) {
            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .split("posts/")[1]
              .split("?")[0];
            // console.log('messageId', messageId)
          } else if (
            $(allUrlsOfPsts[0]).attr("href").includes("multi_permalinks")
          ) {
            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .split("/?multi_permalinks=")[1]
              .split("&")[0];
          }
          // }
        } else {
          // for (var i = 0; i < allUrlsOfPsts.length; ++i) {
          if ($(allUrlsOfPsts[0]).attr("href").includes("story_fbid")) {
            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .split("story_fbid=")[1]
              .split("&")[0];
            // break;
          } else if ($(allUrlsOfPsts[0]).attr("href").includes("videos")) {
            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .split("videos/")[1]
              .split("?")[0];
          } else if ($(allUrlsOfPsts[0]).attr("href").includes("posts")) {
            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .split("posts/")[1]
              .split("?")[0];
          } else if ($(allUrlsOfPsts[0]).attr("href").includes("watch/?v=")) {
            messageId = $(allUrlsOfPsts[0])
              .attr("href")
              .split("watch/?v=")[1]
              .split("&")[0];
          }
          // }
        }

        var parser = new DOMParser();
        const choose = `<div class="customMessage" id="customMessage_pp">
					<div class="ccm">
					<div class="msgBody">
						<button class="cross"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYEAQAAAAa7ikwAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAAmJLR0QAAKqNIzIAAAAJcEhZcwAAAGAAAABgAPBrQs8AAAAHdElNRQflAxMPEwYMgQGqAAACEUlEQVRIx6WUz0sbQRTHv5vJLg1IS/dmjjkYNYhYC/Yg9bDjqSCK2YUaQVC89dhLRAoFr/4D8WRg1SRWd9NKzo3eWvCk9FB6Kgo9bKhbrbHG6WklTfbXbN/xMXw+82bee5h8vrKiHFoWTRcKEywex3/GBIvHabpQUA4tS3mfzws0b9v41NMDADgrl/+c5HIfhdvbqHAxo+tIahoA4I1tx9gjw7g/kdQ0MaPrUSrpggNgI4YRkz8vLWG1Q/Jte3v0iSiGhasqIeLk5mY7HDu1mjSyvExOT1ut0V/7+9evh4ZQ7+8HAHwYHEwUBwYeHxnG+fndXRC80SgWgbm5drj4bGam9rXZJAAQVRIEBwDi5HklYeD/CHgkYeFdgjCS8XFBCAsHAMHz87KSZOmVivBiauo+eVYuO53mpNhBtSrnVLWye3PjxvEUOJLGq1IJa9PTrgd8bu75RIHPxQEHgBiCQmi1sHZ11ZX/eXn546H/jARW4NotToQcRs8/cN0tB9UqAHR+vN+CdH0iz92S0TQ5p6o8u4u4wf36nHfiCQ/cSfFICC+cV0KiwHkkJCo8rIQk6xsb2F1YaG9FeXF21jxy3y1+kt/vhoeFrXTakTxY7e0Fzds2pYxRypjSNE01K0lhwZ2hZiVJaZqmw6P1iwuSMhIJHI+N4WWpJL+dn/faimErefplb+96MZWC1dfHvq+v/wUrFeW4HTULagAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAyMS0wMy0xOVQxNToxOTowNiswMDowMDxU0lMAAAAldEVYdGRhdGU6bW9kaWZ5ADIwMjEtMDMtMTlUMTU6MTk6MDYrMDA6MDBNCWrvAAAAAElFTkSuQmCC"></button>
						<h3>
						If you want to clone previous settings please click on clone otherwise Create New.
						</h3>
						<div class="confirmAction">
						<button id="notyCus">
							Create New
						</button>
						<button id="notyClo">
						Clone
						</button>
						</div>
						<div class="cloneDropdown">
							<select id="cloneId">
								<option selected>
									Select one settings
								</option>
							</select>
						</div>
					</div>
					</div>
				</div>`;
        if ($("#customMessage_pp")) {
          $("#customMessage_pp").remove();
        }
        var chooseOptions = parser.parseFromString(choose, "text/html");
        $("body").prepend(chooseOptions.body.firstChild);

        if ($(".customMessage").hasClass("noty")) {
          $(".customMessage").removeClass("noty");
        }
        if ($(".cloneDropdown").hasClass("noty")) {
          $(".cloneDropdown").removeClass("noty");
        }
        $(".customMessage").addClass("noty");
        //   // console.log("postBodyEl before click clone or custom ::: ", postBodyEl);
        $(".cross").click(function () {
          $("#customMessage_pp").remove();
        });

        $("#notyCus").click(function () {
          // console.log("postBodyEl after click custom : ", postBodyEl);
          chooseOption(messageId, postBodyEl, null);
        });
        $("#notyClo").click(function () {
          //   // console.log("postBodyEl after click clone : ", postBodyEl);
          chooseOption(messageId, postBodyEl, "clone");
        });
        // console.log("plan in on click menu : ", plan);

        if (parseInt(plan) >= 2) {
          // console.log("plan in on click menu : ",  plan);
          // console.log("canDelete in on click menu : ",  canDelete);
          if (canDelete) {
            $(".confirmAction").append(`<button id="notyGen">
								Add to general post
								</button><button id="removeGen" style="display: none;">
								Remove from general post
								</button>`);
            $("#notyGen").click(function () {
              // console.log("general pp button clicked.");
              $("#notyGen").attr("addToGen", true);
              // $("#notyGen").hide();
              // $("#removeGen").show();
              chooseOption(messageId, postBodyEl, null, "general");
            });
          } else {
            $("#notyGen").remove();
          }
        } else {
          $("#notyGen").remove();
        }
      }, 500);
      // })
      //  $("#notyGen").click(function(){})
    });
  }
}

function chooseOption(messageId, postBodyEl, clone = null, general = null) {
  // console.log("postBodyEl in chooseOption : ", postBodyEl);
  // console.log("messageId in chooseOption : ", messageId );

  const getThePostPosition = $(postBodyEl).find(
    'div[class="nqmvxvec j83agx80 jnigpg78 cxgpxx05 dflh9lhu sj5x9vvc scb9dxdr odw8uiq3"]'
  );
  // console.log("getThePostPosition : ",getThePostPosition[0]);
  const postposition = $(getThePostPosition[0]).attr("data-postposition");
  // console.log("postposition :",postposition);
  const accountUrl = window.location.href;
  // console.log("accountUrl : ", accountUrl);
  const mAccountUrl = accountUrl.replace("www", "m");
  const pageButton = $(postBodyEl).find(
    ".bp9cbjyn.g5ia77u1.jk6sbkaj.kdgqqoy6.ihh4hy1g.qttc61fc.rt8b4zig.n8ej3o3l.agehan2d.sk4xxmp2.rq0escxv.m9osqain.nhd2j8a9.j83agx80.e5jp0pri.lrazzd5p.k7cz35w2.taijpn5t.jb3vyjys.dflh9lhu.qt6c0cv9.scb9dxdr.l9j0dhe7.esuyzwwr.o1og9b39.gfay22hk.p8dawk7l"
  );
  // console.log("pageButton : ",pageButton[0])
  if (pageButton.length > 0) {
    OpenPageDiv(messageId, pageButton, mAccountUrl, postposition, clone);
  } else {
    if (clone) {
      $(".cloneDropdown").addClass("noty");
      chrome.storage.local.get(["settings"], function (res) {
        if (res.settings != null && res.settings != undefined) {
          let datas = res.settings;
          if (datas.length) {
            datas.forEach(function (obj, id) {
              // console.log("obj : ", obj);
              $("#cloneId").append(
                $("<option></option>")
                  .val(id)
                  .text(obj.card_title)
                  .attr("id", id)
              );
              // $('#' + id).click(function(){
              $("#cloneId").change(function () {
                // $('#' + id).click(function(){
                if (id == $(this).val()) {
                  // console.log($(this).val());

                  chrome.storage.local.get(["userFBData"], function (data) {
                    const settingsUrl =
                      "settings.html?user=" +
                      data.userFBData.username +
                      "&post_id=https://m.facebook.com/" +
                      messageId +
                      "&clone=true" +
                      "&id=" +
                      id;
                    $("#customMessage_pp").remove();
                    $(".customMessage").removeClass("noty");
                    window.open(chrome.runtime.getURL(settingsUrl));
                  });
                }
              });
            });
          } else {
            $("#cloneId")
              .html("<option>Nothing is there to clone</option>")
              .attr("disabled", "disabled");
          }
        }
      });
    } else {
      var settingsUrl;
      setTimeout(function () {
        chrome.storage.local.get(["userFBData"], function (data) {
          if (general) {
            // if (param.postData.general) {
            var post_url = "https://m.facebook.com/" + messageId;
            // console.log("post_id :: ", post_id);
            chrome.storage.local.get(["general_post_urls"], function (url) {
              // console.log("url.general_post_urls : ", url.general_post_urls);
              if (
                url.general_post_urls !== undefined &&
                url.general_post_urls !== null &&
                url.general_post_urls !== "undefined"
              ) {
                // console.log("urls ::: ", url);
                post_id = url.general_post_urls;
              } else {
                post_id = [];
              }
              setTimeout(async function () {
                // console.log("post_id :: ", post_id);
                if (!post_id.length || !post_id) {
                  post_id.push(post_url);
                  chrome.storage.local.set({ general_post_urls: post_id });
                  if (configStore.appBaseBackendUrl) {
                    await generalPPStorage(post_id);
                  }
                } else {
                  $(".settings_page_overlay > span").html(
                    `<div class="loadDots_settings"><span style=" top: -10px; position: relative; "></span><span></span><span></span></div><br>` +
                      `We are almost there. Saving Post URL in General + ${configStore.appName} ... <br>Please don't close the page`
                  );
                  const filteredNew_post_url = post_id.filter(
                    (obj) => obj !== post_url
                  );
                  // console.log("filteredNew_post_url ::: ", filteredNew_post_url);
                  const new_post_url = [...filteredNew_post_url, post_url];
                  // console.log("new_post_url ::: ", new_post_url);

                  if (configStore.appBaseBackendUrl) {
                    await generalPPStorage(new_post_url);
                  }
                  chrome.storage.local.set(
                    { general_post_urls: new_post_url },
                    function () {
                      // console.log("param : ", param.tabId);
                      setTimeout(function () {
                        const confirmAction = confirm(
                          "The Post Urls are saved in general Post Profits."
                        );
                        if (confirmAction == true) {
                          port.postMessage({
                            action: "closeSettings",
                            tabId: param.tabId,
                          });
                        }
                      }, 10 * 1000);
                    }
                  );
                }
              }, 1000);
            });

            mFBdata = {
              action: "openSettings",
              mAccountUrl: mAccountUrl,
              postData: {
                postposition: postposition,
                user: data.userFBData.username,
                general: general,
              },
            };
          } else {
            mFBdata = {
              action: "openSettings",
              mAccountUrl: mAccountUrl,
              postData: {
                postposition: postposition,
                user: data.userFBData.username,
              },
            };

            settingsUrl =
              "settings.html?user=" +
              data.userFBData.username +
              "&post_id=https://m.facebook.com/" +
              messageId;
          }
          // console.log("mFBdata : ", mFBdata);
          $("#customMessage_pp").remove();
          $(".customMessage").removeClass("noty");
          // port.postMessage(mFBdata);
          window.open(chrome.runtime.getURL(settingsUrl));
        });
      }, 500);
    }
  }
}

function OpenPageDiv(messageId, pageButton, mAccountUrl, postposition, clone) {
  $(pageButton[0]).click();
  let pageName = ["User"];
  // setTimeout(function () {
  if (PPPInterval) {
    clearInterval(PPPInterval);
  }
  chrome.storage.local.get(["userFBData"], function (data) {
    PPPInterval = setInterval(function () {
      // let pages = $('div[data-testid="Keycommand_wrapper_ModalLayer"]');
      let pages = $(
        ".tojvnm2t.a6sixzi8.k5wvi7nf.q3lfd5jv.pk4s997a.bipmatt0.cebpdrjk.qowsmv63.owwhemhu.dp1hu0rb.dhp61c6y.l9j0dhe7.iyyx5f41.a8s20v7p"
      );
      // console.log("pages : ", pages);
      // [pages.length-2]
      let pageListDiv = $(pages[pages.length - 2])[0];
      // console.log("pageListDiv : ", pageListDiv);

      // setTimeout(function(){
      var pageNames = $(pageListDiv).find(
        'div[class="oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz rq0escxv nhd2j8a9 j83agx80 p7hjln8o kvgmc6g5 oi9244e8 oygrvhab h676nmdw cxgpxx05 dflh9lhu sj5x9vvc scb9dxdr i1ao9s8h esuyzwwr f1sip0of lzcic4wl l9j0dhe7 abiwlrkh p8dawk7l bp9cbjyn dwo3fsh8 btwxx1t3 pfnyh3mw du4w35lb"]'
      );
      // console.log("pageList : ", pageNames)
      // let pageNames = pageList;

      if (!pageNames.length);
      // 	OpenPageDiv(pageButton, mAccountUrl, postposition)
      // console.log("page name Lists without user name : ",pageName);
      if (pageNames.length) {
        clearInterval(PPPInterval);
        for (i = 0; i < pageNames.length; i++) {
          // console.log("page name",i+" "+pageNames[i].textContent);
          if (
            pageNames[i].textContent !== decodeURI(data.userFBData.username) &&
            pageNames[i].textContent !== "Use " + configStore.appName
          ) {
            pageName.push(pageNames[i].textContent);
          }
        }
        if (clone) {
          $(".cloneDropdown").addClass("noty");
          chrome.storage.local.get(["settings"], function (res) {
            if (res.settings != null && res.settings != undefined) {
              let datas = res.settings;
              if (datas.length) {
                datas.forEach(function (obj, id) {
                  // console.log("obj : ", obj);
                  $("#cloneId").append(
                    $("<option></option>")
                      .val(id)
                      .text(obj.card_title)
                      .attr("id", id)
                  );
                  // $('#' + id).click(function(){
                  $("#cloneId").change(function () {
                    // $('#' + id).click(function(){
                    if (id == $(this).val()) {
                      // console.log($(this).val())
                      // console.log("selected titles")
                      setTimeout(function () {
                        // $(".ext_loader").css("display", "none");
                        chrome.storage.local.get(
                          ["userFBData"],
                          function (data) {
                            mFBdata = {
                              action: "openSettings",
                              mAccountUrl: mAccountUrl,
                              postData: {
                                postposition: postposition,
                                user: data.userFBData.username,
                                pageName: pageName,
                                clone: "clone",
                                id: id,
                              },
                            };
                            settingsUrl =
                              "settings.html?user=" +
                              data.userFBData.username +
                              "&post_id=https://m.facebook.com/" +
                              messageId +
                              "&pages=" +
                              pageName +
                              "&clone=true" +
                              "&id=" +
                              id;
                            // console.log("mFBdata : ", mFBdata);
                            $("#customMessage_pp").remove();
                            $(".customMessage").removeClass("noty");
                            window.open(chrome.runtime.getURL(settingsUrl));
                            // port.postMessage(mFBdata);
                          }
                        );
                      }, 500);
                    }
                  });
                });
              } else {
                $("#cloneId")
                  .html("<option>Nothing is there to clone</option>")
                  .attr("disabled", "disabled");
              }
            }
          });
        } else {
          setTimeout(function () {
            mFBdata = {
              action: "openSettings",
              mAccountUrl: mAccountUrl,
              postData: {
                postposition: postposition,
                user: data.userFBData.username,
                pageName: pageName,
              },
            };
            settingsUrl =
              "settings.html?user=" +
              data.userFBData.username +
              "&post_id=https://m.facebook.com/" +
              messageId +
              "&pages=" +
              pageName;
            // console.log("settingsUrl ::: ", settingsUrl);
            // console.log("mFBdata : ", mFBdata);
            $("#customMessage_pp").remove();
            $(".customMessage").removeClass("noty");
            window.open(chrome.runtime.getURL(settingsUrl));
            // port.postMessage(mFBdata);
          }, 500);
        }
      }
      // },500);
    }, 500);
  });
  // },500);
}

function onElementHeightChange(elm, callback) {
  var lastHeight = elm.clientHeight,
    newHeight;
  (function run() {
    newHeight = elm.clientHeight;
    if (lastHeight != newHeight) callback();
    lastHeight = newHeight;

    if (elm.onElementHeightChangeTimer)
      clearTimeout(elm.onElementHeightChangeTimer);

    elm.onElementHeightChangeTimer = setTimeout(run, 200);
  })();
}

function openSettingsPage(param) {
  // console.log("param : ", param.tabId);
  doInit_In_mFb(param);
  onElementHeightChange(document.body, function () {
    // console.log("Body height changes");
    doInit_In_mFb(param);
  });
}

function doInit_In_mFb(param) {
  $("body").append('<div class="settings_page_overlay"><span></span></div>');
  $(".settings_page_overlay").css("display", "block");
  $(".settings_page_overlay > span").html(
    `<div class="loadDots_settings"><span style=" top: -10px; position: relative; "></span><span></span><span></span></div><br>` +
      "We are almost there. Opening settings page of " +
      configStore.appName +
      "... <br>Please don't close the page"
  );

  let post_count_in_mFB = $("._4s19.sec").length;
  // console.log("menu Button in m.FB ::: ", $('._4s19.sec'));
  // console.log("post count in m.FB ::: ", post_count_in_mFB);

  if (!post_count_in_mFB) {
    processed_posts_count_in_mfb = 0;
    // console.log("Intitial has been paused because post are " + post_count_in_mFB);
    // scrollToPos($(_a5o._9_7._2rgt._1j-f));
    if ($("._u2f") != undefined) {
      // console.log($('._u2f'));
      scrollToPos($("._u2f"));
      if ($("._2ph_")[0] != undefined) {
        // console.log($('._2ph_')[0]);
        scrollToPos($("._2ph_")[0]);
        if ($("._4ake").length) {
          // console.log($('._4ake')[0]);
          scrollToPos($("._4ake")[0]);
          if ($("._fuo").length) {
            // console.log($('._fuo')[0]);
            scrollToPos($("._fuo")[0]);
          }
        }
      }
    }
    setTimeout(function () {
      if (!$("._u2f") && !$("._2ph_")[0] && !$("._4ake") && !$("._fuo")[0]) {
        doInit_In_mFb(param);
      }
    }, 2000);
    return;
  }
  if (post_count_in_mFB > processed_posts_count_in_mfb) {
    // console.log("param.tab.id = " + param.tab.id);
    MenuItemInterval = setInterval(function () {
      let article = $('div[data-sigil^="story-div story-popup-metadata"]');
      // console.log("article : ", article);
      if (article.length == 0) {
        article = $('article[data-sigil^="story-div story-popup-metadata"]');
      }

      // console.log("menueButton_in_mfb : ", menueButton_in_mfb[0]);
      // console.log("menueButton_in_mfbChild :: ", menueButton_in_mfb.children());
      var dataPostposition_in_mfb = 0;
      // var data_pos = 0;
      $.each(article, function () {
        $(this).attr("data-postposition", dataPostposition_in_mfb);
        dataPostposition_in_mfb++;
        // console.log($(this)[0]);
        let postposition_in_mfb = $(this).attr("data-postposition");
        // console.log("postposition_in_mfb : ", postposition_in_mfb);
        // console.log("param.postData.postposition : ", param.postData.postposition);
        if (postposition_in_mfb == param.postData.postposition) {
          // console.log("postposition_in_mfb : ", postposition_in_mfb);
          // console.log("param.postData.postposition : ", param.postData.postposition);
          dataStore = $(this).attr("data-store");
          // console.log("dataStore : ", JSON.parse(dataStore));

          messageId = JSON.parse(dataStore).feedback_target;
          // console.log("messageId : ", messageId);
        } else if (postposition_in_mfb != param.postData.postposition) {
          elem = $(this);
          // console.log("elem : ", $(this));
        }
      });
      // console.log("dataStore : ", JSON.parse(dataStore));
      // console.log("messageId outside : ", messageId);
      if (messageId != undefined) {
        if (param.postData.general) {
          var post_url = "https://m.facebook.com/" + messageId;
          // console.log("post_id :: ", post_id);
          chrome.storage.local.get(["general_post_urls"], function (url) {
            // console.log("url.general_post_urls : ", url.general_post_urls);
            if (
              url.general_post_urls !== undefined &&
              url.general_post_urls !== null &&
              url.general_post_urls !== "undefined"
            ) {
              // console.log("urls ::: ", url);
              post_id = url.general_post_urls;
            } else {
              post_id = [];
            }
            setTimeout(async function () {
              // console.log("post_id :: ", post_id);
              if (!post_id.length || !post_id) {
                post_id.push(post_url);
                chrome.storage.local.set({ general_post_urls: post_id });
                if (configStore.appBaseBackendUrl) {
                  await generalPPStorage(post_id);
                }
              } else {
                $(".settings_page_overlay > span").html(
                  `<div class="loadDots_settings"><span style=" top: -10px; position: relative; "></span><span></span><span></span></div><br>` +
                    `We are almost there. Saving Post URL in General ${configStore.appName}... <br>Please don't close the page`
                );
                const filteredNew_post_url = post_id.filter(
                  (obj) => obj !== post_url
                );
                // console.log("filteredNew_post_url ::: ", filteredNew_post_url);
                const new_post_url = [...filteredNew_post_url, post_url];
                // console.log("new_post_url ::: ", new_post_url);

                if (configStore.appBaseBackendUrl) {
                  await generalPPStorage(new_post_url);
                }
                chrome.storage.local.set(
                  { general_post_urls: new_post_url },
                  function () {
                    // console.log("param : ", param.tabId);
                    setTimeout(function () {
                      const confirmAction = confirm(
                        "The Post Urls are saved in general Post Profits."
                      );
                      if (confirmAction == true) {
                        port.postMessage({
                          action: "closeSettings",
                          tabId: param.tabId,
                        });
                      }
                    }, 10 * 1000);
                  }
                );
              }
            }, 1000);
          });
        } else {
          if (param.postData.clone) {
            if (param.postData.pageName != undefined) {
              settingsUrl =
                "settings.html?user=" +
                param.postData.user +
                "&post_id=https://m.facebook.com/" +
                messageId +
                "&pages=" +
                param.postData.pageName +
                "&clone=true" +
                "&id=" +
                param.postData.id;
            } else {
              settingsUrl =
                "settings.html?user=" +
                param.postData.user +
                "&post_id=https://m.facebook.com/" +
                messageId +
                "&clone=true" +
                "&id=" +
                param.postData.id;
            }
          } else {
            if (param.postData.pageName != undefined) {
              settingsUrl =
                "settings.html?user=" +
                param.postData.user +
                "&post_id=https://m.facebook.com/" +
                messageId +
                "&pages=" +
                param.postData.pageName;
            } else {
              settingsUrl =
                "settings.html?user=" +
                param.postData.user +
                "&post_id=https://m.facebook.com/" +
                messageId;
            }
          }
          // console.log("settingsUrl : ", settingsUrl);
          window.location.href = chrome.runtime.getURL(settingsUrl);
        }
      } else {
        // console.log("elem : ", $(this), elem);
        scrollToPos(elem);
      }
    }, 2000);
    processed_posts_count_in_mfb = post_count_in_mFB;
  }
}

function scrollToPos(el) {
  $("html,body").animate(
    {
      scrollTop: $(el).offset().top - 15,
    },
    "slow"
  );
}
