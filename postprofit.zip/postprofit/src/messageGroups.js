
var $ = jQuery = require('jquery');
var config = require('./config');
const configStore = require("../public/kyubiSettings.json");
var helper = require('./helper');
const { groupStorage, deleteGroupStorage, groupEditStorage } = require("./storage.js");
var groupMemberUrl = /^(http|https):\/\/(www.)*(facebook)(\.com)\/groups\/[a-z0-9.A-Z]{2,}\/members/;
var urls = config.regexUrls;
var editIndex = null;
var slideLoopTimeout;
var slideIndx = 0;
var messages = {fcmessages: {segments: [], groups: []}};

$(document).ready(async function(){
    // Setting up
    editIndex = window.localStorage.getItem("tempEditIndexGroup");
    /* Fetching and showing saved email id */
    $(".loggedInAs").text(await helper.getLoggedInUser());

    /* Redirect user to default popup for the relevant page if clicks on home icon */
    $(".home").click(function(){
        getCheckCurrentUrl();
    });
    // chrome.storage.local.set({fcmessages: {segments: [], groups: []}});
    messages.fcmessages = await helper.retriveSegmentGroups();
    //console.log(messages.fcmessages);
    if(editIndex !== null) {
        window.localStorage.removeItem("tempEditIndexGroup");
        $("#groupID").val(editIndex);
        await populateGroup(editIndex);
    }

    /* Populating list of created groups */
    await populateGroupLists(messages.fcmessages);
    /* Populating segment list in create/edit group page */
    await populateSegmentList(messages.fcmessages.segments);
    /* Clicking on Save group either create or update group */
    $("#addGroup").click(function() {
        if(validateGroup()) {
            if($("#groupID").val().length) {
                updateGroup($("#groupID").val());
            } else {
                saveGroup();
            }
        }
    });

    $("#createSegment").on('submit', (e) => {
        e.preventDefault()
    })
    /* Adding triggers on clicking edit/delete/view for each iterated group */
    await putContentsForDOM();
});

const validateGroup = function() {
    //console.log("Validation called");
    let isValid = false;
    const title = $(".groupTitle").val();
    const alphaRegex = /^[A-Za-z0-9 ]+$/;
    // //console.log("Title match",title.match(alphaRegex));
    // //console.log("Regex test",alphaRegex.test(title));

    if(!title.length || !alphaRegex.test(title)) {
        //console.log("Title Error");
        $("#titleError").fadeIn().text("Please input the title with alpha numeric characters only").delay(1000).fadeOut();
        isValid = false;
    } else {
        isValid = true;
    }
    if(!$(".groupList li").length) {
        //console.log("Group List Error", $(".groupList li").length)
        $("#groupError").fadeIn().text("Please add atleast one group set").delay(1000).fadeOut();
        isValid = false;
    } else {
        isValid = true;
    }

    return isValid;
}

const populateGroupLists = async function (data) {
    var injectHtml = '';
    data.groups.forEach((el, index) => {
        // //console.log("Index",index, "Element",el);
        injectHtml += `<li class="listItem">
            <p>`+el.title+`</p>
            <div class="optSegment">`
                // <button type="button" class="view" data-blocks="`+el.blocksPos.join('|')+`">
                //     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="10.286" viewBox="0 0 16 10.286"><g transform="translate(-1467 -182)"><path d="M14.857,389.143a8.777,8.777,0,0,0-3.4-3.152A3.9,3.9,0,0,1,12,388a3.852,3.852,0,0,1-1.174,2.826A3.852,3.852,0,0,1,8,392a3.852,3.852,0,0,1-2.826-1.174A3.852,3.852,0,0,1,4,388a3.9,3.9,0,0,1,.545-2.009,8.777,8.777,0,0,0-3.4,3.152,9.216,9.216,0,0,0,2.978,2.915,7.479,7.479,0,0,0,7.759,0A9.216,9.216,0,0,0,14.857,389.143Zm-6.429-3.429A.427.427,0,0,0,8,385.286,2.728,2.728,0,0,0,5.286,388a.429.429,0,1,0,.857,0A1.86,1.86,0,0,1,8,386.143a.427.427,0,0,0,.429-.429ZM16,389.143a1.236,1.236,0,0,1-.179.616,9.472,9.472,0,0,1-3.362,3.29,8.647,8.647,0,0,1-8.92,0,9.534,9.534,0,0,1-3.362-3.286,1.152,1.152,0,0,1,0-1.232,9.534,9.534,0,0,1,3.362-3.286,8.634,8.634,0,0,1,8.92,0,9.534,9.534,0,0,1,3.362,3.286A1.236,1.236,0,0,1,16,389.143Z" transform="translate(1467 -202)" fill="#8e8b9c"/></g></svg>
                // </button>
                +
                `<button type="button" class="btn-well editGroup" data-position="`+index+`" data-id="`+el.id+`">
                    <svg xmlns="http://www.w3.org/2000/svg" width="13.391" height="13.391" viewBox="0 0 13.391 13.391"><defs><style>.a{fill:#a8a5b3;}</style></defs><g transform="translate(0.276 2)"><path class="a" d="M13.56,4.266a7.022,7.022,0,0,0-2.445-2.424L11.956,1a3.005,3.005,0,0,1,1.826.609,3.005,3.005,0,0,1,.609,1.826ZM6.478,11.347H4.043V8.913l.292-.292A5.1,5.1,0,0,1,6.77,11.055Zm6.379-6.379L7.473,10.352A7.067,7.067,0,0,0,6.409,9,7.031,7.031,0,0,0,5.028,7.928l5.395-5.394a5.09,5.09,0,0,1,2.435,2.435ZM2.826,2.826v9.739h9.739V8.3l1.826-1.849v6.719a1.217,1.217,0,0,1-1.217,1.217H2.217A1.217,1.217,0,0,1,1,13.174V2.217A1.218,1.218,0,0,1,2.217,1h6.7L7.092,2.826Z" transform="translate(-1.276 -3)"/></g></svg>
                    Edit
                </button>
                <button type="button" class="btn-delete delGroup" data-position="`+index+`" data-id="`+el.id+`">
                    <svg xmlns="http://www.w3.org/2000/svg" width="13.936" height="16.654" viewBox="0 0 13.936 16.654"><defs><style>.a{fill:#a8a5b3;}</style></defs><g transform="translate(-2)"><g transform="translate(2)"><path class="a" d="M14.409,8H4.793a.677.677,0,0,0-.7.766l1.115,9.128A1.366,1.366,0,0,0,6.6,19.079h5.923a1.366,1.366,0,0,0,1.394-1.185l1.115-9.128A.629.629,0,0,0,14.409,8Z" transform="translate(-2.633 -2.426)"/><path class="a" d="M14.542,1.394H11.058A1.4,1.4,0,0,0,9.665,0H8.271A1.4,1.4,0,0,0,6.878,1.394H3.394A1.4,1.4,0,0,0,2,2.787v.7a.658.658,0,0,0,.7.7H15.239a.658.658,0,0,0,.7-.7v-.7A1.4,1.4,0,0,0,14.542,1.394Z" transform="translate(-2)"/></g></g></svg>
                </button>
            </div>
        </li>`;
    });
    await $("#groupListList").html(injectHtml);
};

/**
 * Get and check the current url and show the popup based on that.
 */
const getCheckCurrentUrl = function() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const redirectTo = urls.filter((el) => {
            return el.regex.test(tabs[0].url) == true;
        });
        window.location.href = "./" + redirectTo[0].popup;
    });
};

/**
 * Initializing the click for edit, view and delete button after initializing the list of segments
 */
const putContentsForDOM = async function() {
//     await $(".view").click(async function() {
//         await viewGroup($(".view").data('blocks'));
//         await $(".popupOuter").css("display","block");
//         await slideLightBoxItems($(".view"));
//     });

    await $(".editGroup").click(function() {
        editIndex = $(this).data('id');
        window.localStorage.setItem("tempEditIndexGroup", editIndex);
        window.location.href = "group-create.html";
    });

    await $(".delGroup").click(async function() {
        if(confirm("If you delete this group it will be unassigned from everywhere you assigned. Are you sure?")) {
            await delGroup($(this).data('id'));
        }

    });
};
/**
 * Delete Group function
 * @param {String} groupID
 */
const delGroup = async function(groupID) {
    var groupList = messages.fcmessages.groups;
    var filteredGroup = await groupList.filter((el, i) => {
        return el.id != groupID;
    });
    messages.fcmessages.groups = filteredGroup;
    chrome.storage.local.set(messages, async function() {
        if(configStore.appBaseBackendUrl)
            await deleteGroupStorage(groupID, configStore);
        await populateGroupLists(messages.fcmessages);
        await putContentsForDOM();
    });
};
/**
 * Initiate the view group html for showing into the lightbox
 * @param {Array} blocks
 */
// const viewGroup = async function(blocks) {
//     const blocksArr = await blocks.split("|");
//     // //console.log(blocksArr);
//     let innertHtml = '';
//     blocksArr.forEach((el, index) => {
//         const segmentArr = el.split(",");
//         // //console.log(segmentArr);
//         segmentArr.forEach((e) => {
//             // //console.log(await e);
//             innertHtml += getSegmentByPos(e);
//             // //console.log(getSegmentByPos(e));
//         });
//     });
    // //console.log("Inner HTML", innertHtml);
//     await $(".previewList").html(innertHtml);
// };
/**
 * Fetching the segment using the id
 * @param {*} arrayEl The Array element can be the segment id or can be other choosen element
 */
const getSegmentByPos = function(arrayEl) {
    if(!isNaN(parseInt(arrayEl))) {
        /* Filter out segment with the id */
        const segments = messages.fcmessages.segments.filter(obj => obj.id == arrayEl);
        /* Create a random number to choose one, max length would be the length of that perticular segment blocks */
        const randomNumber = Math.floor(Math.random() * segments[0].blocks.length);
        /* Randomize the blocks array of that filtered segment and return one array element and return */
        return `<div class="prevw-i">` + segments[0].blocks[randomNumber] + `</div>`;
    } else {
        /* Return if not a segment */
        return `<div class="prevw-i">` + arrayEl + `</div>`;
    }
};
/**
 * Initiating and looping through div's inside the lightbox
 * @param {*} element The html element
 */
// const slideLightBoxItems = function (element) {
//     clearTimeout(slideLoopTimeout);
//     var i;
//     // get the array of divs' with classname image-sliderfade
//     var slides = element.parents('.create-segment').find('.prevw-i');
//     for (i = 0; i < slides.length; i++) {
//         // initially set the display to
//         // none for every image.
//         slides[i].style.display = "none";
//     }

//     // increase by 1, Global variable
//     slideIndx++;

//     // check for boundary
//     if (slideIndx > slides.length){
//         slideIndx = 1;
//     }
//     slides[slideIndx - 1].style.display = "block";

//     slideLoopTimeout = setTimeout(() => {
//         slideLightBoxItems(slides);
//         //console.log(slideIndx)
//     }, 1000);
// };

/**
 * Populate the segment list in create/update group
 * @param {Array} segments Array of objects for the saved segments
 */
const populateSegmentList = async function (segments) {
    // //console.log("Populate Segment List", data);
    var injectHtml = '';
    segments.forEach((el, index) => {
        // //console.log("Index",index, "Element",el);
        injectHtml += ` <button type="button" data-value="[`+el.title+`]" data-id="`+el.id+`">
        [`+el.title+`]
      </button>`;
    });
    await $("#setMsgSeg").html(injectHtml);
};

/**
 * Triggers when user click on the save group to save the group
 */
const saveGroup = async function() {
    let newItems = (typeof messages.fcmessages.groups === 'undefined')? new Array():messages.fcmessages.groups;
    var location = "group-listing.html";
    let groupObj = await getMessageGroup();
    // //console.log("Save Group", groupObj);
    if(newItems.length) {
        // //console.log("Saved Segments", newItems);
        messages.fcmessages.groups =  [...newItems, groupObj];
        // console.log("messages : ", JSON.stringify(messages));
        await chrome.storage.local.set(messages, function() {
            // //console.log("Saved from not there");
            window.location.href = location;
        });
    } else {
        messages.fcmessages.groups =  [groupObj];
        // console.log("messages : ", messages);
        await chrome.storage.local.set(messages, function() {
            // //console.log("Saved from empty");
            window.location.href = location;
        });
    }

   await chrome.storage.local.get("fcmessages", function(items) {
        //console.log("With Newly added groups",items.fcmessages);
    });
};

/**
 * Generating the message segment object from user input
 * @param {String} groupID Optional
 * @returns Object
 */
const getMessageGroup = async function (groupID = null) {
    let id = (groupID)? groupID: (Math.round((new Date()).getTime() / 1000)).toString();
    const title = $(".groupTitle").val();
    const groupLists = $(".listCreatedGroups").find("li");
    let messageSegments = [];
    await $.each(groupLists, function(index, el) {
        let span = $(el).find("span");
        messageSegments[index] = [];
        $.each(span, function(i, element) {
            if($(element).hasClass("segItem")) {
                messageSegments[index].push($(element).data("id"));
            } else {
                //console.log();
                messageSegments[index].push(element.innerText);
            }
        });
    });
    if(configStore.appBaseBackendUrl)
    {
        if (groupID) {
        response = await groupEditStorage(groupID, title, messageSegments, configStore);
        } else {
        response = await groupStorage(title, messageSegments, configStore);
        id = response.data._id;
        }
    }
    return await {id: id, title: title, blocksPos: messageSegments};
}

/**
 * Populate edit group for editing the group
 * @param {*} groupID
 */
const populateGroup = async function(groupID) {
    let html = '';
    const getGroup = async function(groupID) {
        var group = messages.fcmessages.groups;
        var filteredGroup = group.filter((el, i) => {
            return el.id == groupID;
        });
        return await filteredGroup[0];
    };

    const createMessageBlock = async (blocksPos, pos = 0) => {
        let j = pos;
        let spanEl = '';
        const createBlockElement = async (elArr, currentPos = 0) => {
            let i = currentPos;
            const arr = await elArr;
            // //console.log("Current Pos", currentPos);
            // //console.log("Array length", arr.length);
            if(!isNaN(parseInt(arr[i]))) {
                const filteredSeg = await messages.fcmessages.segments.filter(elem => elem.id == arr[i]);
                // //console.log(filteredSeg);
                const span = `<span class="setItem segItem" contenteditable="false" data-id="`+filteredSeg[0].id+`"> [`+ filteredSeg[0].title +`]
                <button type="button" class="removeMsg"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><defs><style>.b{fill:#fff}</style></defs><g class="a" transform="translate(-2 -2)"><path class="b" d="M10,2a8,8,0,1,0,8,8A8.024,8.024,0,0,0,10,2Zm3.92,10.8L12.8,13.92,10,11.12l-2.8,2.8L6.08,12.8,8.88,10,6.08,7.2,7.2,6.08,10,8.88l2.8-2.8L13.92,7.2,11.12,10Z"></path></g></svg> </button>
                </span>`;
                spanEl += span;
                // //console.log("-------------------------------------------");
                // //console.log(span);
            } else {
                const span = await `<span class="setItem" contenteditable="false"> `+ arr[i] +`
                <button type="button" class="removeMsg"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><defs><style>.b{fill:#fff}</style></defs><g class="a" transform="translate(-2 -2)"><path class="b" d="M10,2a8,8,0,1,0,8,8A8.024,8.024,0,0,0,10,2Zm3.92,10.8L12.8,13.92,10,11.12l-2.8,2.8L6.08,12.8,8.88,10,6.08,7.2,7.2,6.08,10,8.88l2.8-2.8L13.92,7.2,11.12,10Z"></path></g></svg> </button>
                </span>`;
                spanEl += span;
                // //console.log("-------------------------------------------");
                // //console.log(span);
            }
            if((elArr.length - 1) !== i) {
                i++;
                await createBlockElement(arr, i);
            }
        };
        let liHtml = await '<li><div class="groupI">';
        // //console.log(blocksPos[0]);
        await createBlockElement(blocksPos[j]);
        liHtml += await spanEl;
        // liHtml += "Span html";
        liHtml += await `<button type="button" class="removeGroupListing"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><defs><style>.b{fill:#fff}</style></defs><g class="a" transform="translate(-2 -2)"><path class="b" d="M10,2a8,8,0,1,0,8,8A8.024,8.024,0,0,0,10,2Zm3.92,10.8L12.8,13.92,10,11.12l-2.8,2.8L6.08,12.8,8.88,10,6.08,7.2,7.2,6.08,10,8.88l2.8-2.8L13.92,7.2,11.12,10Z"></path></g></svg></button>
        </div></li>`;
        html += liHtml;
        //console.log(liHtml);
        //console.log("-------------------------------------------------");
        if((blocksPos.length - 1) !== j) {
            j++;
            await createMessageBlock(blocksPos, j);
        }
    };

    const editGroupData = await getGroup(groupID);
    // //console.log(editGroupData);
    await createMessageBlock(editGroupData.blocksPos);
    // //console.log(await html);
    await $(".groupTitle").val(editGroupData.title);
    await $(".listCreatedGroups").css("display","block");
    await $(".listCreatedGroups ul").html(html);

};



/**
 * Update the group when clicked on save group button while updating the group
 * @param {String} groupID Group id that need to be updated
 */
const updateGroup = async function(groupID) {
    // //console.log("update triggered",groupID);
    const oldGroups = [...messages.fcmessages.groups];
    const groupIndex = oldGroups.findIndex(grp => grp.id == groupID);
    //console.log("Group Index", groupIndex);
    oldGroups[groupIndex] = await getMessageGroup(groupID);
    // //console.log(await getMessageGroup(groupID));
    messages.fcmessages.groups = oldGroups;
    // //console.log(messages.fcmessages.groups);
    chrome.storage.local.set({fcmessages: {segments: [...messages.fcmessages.segments], groups: oldGroups}}, function() {
        // //console.log("Saved from empty");
        window.location.href = "group-listing.html";
    });
};