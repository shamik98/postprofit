const $ = (jQuery = require("jquery"));
require("./bootstraptagsinput.js");
var users = require("./helper.js");
var editPages = null;
var editUser = null;
var Reply_Button = 0;
var Remember_Button = 0;
var port = chrome.runtime.connect({
  name: "settings-Background",
});
let settingsArr = [];
let generalSettings = [];
$(document).ready(async function () {
  // user.saveSettings(settingsArr);
  settingsArr = await users.getSettings();
  // //console.log(settingsArr);
  generalSettings = await users.getGeneralSettings();
  // console.log("generalSettings : ", generalSettings);
  const params = getURLParams();
  // console.log("params : ", JSON.stringify(params, null, 4));
  $.getJSON("kyubiSettings.json", function (result) {
    if (params.general) {
      $(".replyAs").hide();
      $(".postTitle").hide();
      $(".card_description").hide();
      $(".headerOpt").hide();
      $("#card_title").attr("data-validate", false);
      $("#card_description").attr("data-validate", false);


      $("#postSettings").text("General " + result.appName + " Settings");
      $("#set").text("Set your General " + result.appName + " settings");
    } else {
      
      $("#postSettings").text(result.appName + " Settings");
      $("#set").text("Set your " + result.appName + " settings");
    }
  });

  
  
  var keywordsInput = $("#keywordsInput").val();
  //console.log("keyword : ",keywordsInput);
  if (!keywordsInput) {
    //console.log("nokeyword : ",keywordsInput);
    $(".enablefb").css("display", "none");
  }
  $("#keywordsInput").change(function () {
    if ($(this).val()) {
      //console.log("keyword : ",$(this).val());
      $(".enablefb").css("display", "block");
    }
    if (!$(this).val()) {
      //console.log("keyword : ",$(this).val());
      if ($("#selectfbreply").is(":checked")) {
        // console.log("is is checked??");

        $("#selectfbreply").prop("checked", false);
        $("#selectfbreply").val("N");
        $(".fallbackdiv").css("display", "none");
      }
      $(".enablefb").css("display", "none");
    }
  });

  //If enable checkbox of fallback then the fallback div will show
  if (!$("#selectfbreply").is(":checked")) {
    $(".fallbackdiv").css("display", "none");
    // $('#selectfbreply').val("N");
  }
  $("#selectfbreply").click(function () {
    if ($("#selectfbreply").is(":checked")) {
      $(".fallbackdiv").css("display", "block");
      $("#selectfbreply").val("Y");
    } else {
      //console.log("Check box in nooot ticked");
      $(".fallbackdiv").css("display", "none");
      $("#selectfbreply").val("N");
    }
  });

  //If enable checkbox of random delay for X minute then the div of the same will show
  if (!$("#randomXminutes").is(":checked")) {
    $(".randomMinute").css("display", "none");
    // $('#randomXminutes').val("N");
  }
  $("#randomXminutes").click(function () {
    if ($("#randomXminutes").is(":checked")) {
      //console.log("Check box in Checked");
      $(".randomMinute").css("display", "block");
      $("#randomXminutes").val("Y");
    } else {
      //console.log("Check box in nooot ticked")
      $(".randomMinute").css("display", "none");
      $("#randomXminutes").val("N");
    }
  });

  /* Populate Post url */
  $("#post_id").text(params.post_id);
  $("#postURL").attr("href", params.post_id);

  /* Retrive Groups and populate in dropdown */
  const group = await users.retriveGroups();
  if (group.length) {
    group.forEach(async function (obj) {
      $("#groupid").append($("<option></option>").val(obj.id).text(obj.title));
    });
  } else {
    $("#groupid")
      .html(
        "<option>No group is created. Please create message group & start a fresh</option>"
      )
      .attr("disabled", "disabled");
  }
  /* Save settings but before validate user input */
  $("#save_in_card").click(async function () {
    // console.log("Form Submit");
    const formData = await formDatatoJson($("#settingsForm").serializeArray());
    // console.log("formdata : ", formData);
    const pages = params.pages ? params.pages : editPages;
    const user = params.user ? params.user : editUser;
    // console.log("user : ", user);
    const isValidFormData = await validateSettings(formData);
    // console.log("isValidFormData : ", isValidFormData);
    if (!isValidFormData) {
      return;
    }
    await saveFormData(formData, pages, user, params.general);
    $(".customMessage").addClass("noty");
    $("#notyid").click(function () {
      port.postMessage({ action: "ClosingSettings" });
    });
  });

  /* Populate Pages if any or hide the option */
  if (!params.edit && !params.clone) {
    if (params.pages) {
      const pages = decodeURI(params.pages).split(",");
      pages.forEach(async function (val) {
        $("#reply_from_where").append(
          $("<option></option>").val(val).text(val)
        );
      });
    } else {
      $(".replyAs").css("display", "none");
      $("#card_title").after(
        '<input type="hidden" class="replyAsWhere" name="reply_from_where" id="reply_from_where" value="User">'
      );
      $(".fTitle").removeClass("col-8").addClass("col-12");
    }
  } else if (params.edit)
    await populateEditSettings(params.post_id, null, null);
  else if (params.clone)
    await populateEditSettings(null, params.id, params.pages);
  if (!params.id) {
    // console.log("generalSettings ::: ", generalSettings);
    if (params.general) {
      if (generalSettings.length) {
        // console.log("params.general : ", params.general);
        await populateEditSettings(null, null, null, "general");
      }
    } else {
      await populateEditSettings(params.post_id, null, params.pages);
    }
  }

  /* Hide Group if pages are chosen */
  $("#reply_from_where").change(function () {
    //console.log($(this).val())
    if ($(this).val() == "User") {
      // $("#groupid").attr("data-validate", true);
      $("#groupid").removeAttr("disabled", "disabled");
    } else {
      // $("#groupid").removeAttr("data-validate");
      $("#groupid").attr("disabled", "disabled");
    }
  });

  /* Save settings but before validate user input */
  $("#save_in_card").click(async function () {
    // console.log("Form Submit");
    const formData = await formDatatoJson($("#settingsForm").serializeArray());
    // console.log("formdata : ", formData);
    const pages = params.pages ? params.pages : editPages;
    const user = params.user ? params.user : editUser;
    // console.log("user : ", user);
    const isValidFormData = await validateSettings(formData);
    if (!isValidFormData) {
      return;
    }
    await saveFormData(formData, pages, user, params.general);
    $(".customMessage").addClass("noty");
    $("#notyid").click(function () {
      chrome.tabs.query({currentWindow: true, active: true}, function(tabs){
        // console.log(tabs[0].id);
        // window.close();           shamik
        port.postMessage({ action : "ClosingTab", tabId :  tabs[0].id});
      });
    });
  });

  // $('#clone_card').click(async function () {
  //     // console.log("Form Submit");
  //     const formData = await formDatatoJson($("#settingsForm").serializeArray());
  //     // console.log("formdata : ", formData);
  //     const pages = (params.pages) ? params.pages : editPages;
  //     const user = (params.user) ? params.user : editUser;
  //     const isValidFormData = await validateSettings(formData);
  //     if (!isValidFormData) { return };
  //     await saveFormData(formData, pages, user, "clone");
  //     $(".customCloneMessage").addClass("noty");
  //     $("#notyClone").click(function(){
  //         $(".customCloneMessage").removeClass("noty");
  //         // port.postMessage({action : "ClosingTab"});
  //     })
  // });

  await wait(5000);
  await $(".settings_overlay").css("display", "none");
});

/**
 * Populate if user tried to update one card
 */
const populateEditSettings = async (
  paramPostID = null,
  id = null,
  pages,
  general = null
) => {
  // console.log("pages printed in populated Edit Settings.", pages);
  // console.log("general : ", general)
  let obj;
  if (paramPostID) {
    // console.log("settingsArr : ", settingsArr );
    obj = await settingsArr.find((obj) => {
      return obj.post_url == paramPostID;
    });
    // await populatrSettings(obj);
  } else if (id) {
    // console.log("clonning is happening", settingsArr[id] );
    obj = await settingsArr[id];
    // console.log("Editing Payload", obj);
  } else if (general) obj = await generalSettings[0];
  // console.log("obj : ", obj);
  await populatrSettings(obj, pages);
};

const populatrSettings = async (obj, pages) => {
  // console.log("pages in populatrSettings ::: ",pages);
  if (obj) {
    // console.log("obj ::: ",obj);
    // console.log("pages ::: ", pages);
    if (pages) {
      const pagess = decodeURI(pages).split(",");
      pagess.forEach(async function (val) {
        $("#reply_from_where").append(
          $("<option></option>").val(val).text(val)
        );
      });
    } else if (obj.pages) {
      // console.log("pages of objects ::: ", obj.pages);
      // console.log("pages of url ::: ", pages);
      if (!pages || pages == undefined) {
        $(".replyAs").css("display", "none");
        $("#card_title").after(
          '<input type="hidden" class="replyAsWhere" name="reply_from_where" id="reply_from_where" value="User">'
        );
        $(".fTitle").removeClass("col-8").addClass("col-12");
      } else {
        editPages = obj.pages;
        editUser = obj.user;
        const pages = decodeURI(obj.pages).split(",");
        pages.forEach(async function (val) {
          $("#reply_from_where").append(
            $("<option></option>").val(val).text(val)
          );
        });
      }
    } else {
      if (!pages || pages == undefined) {
        $(".replyAs").css("display", "none");
        $("#card_title").after(
          '<input type="hidden" class="replyAsWhere" name="reply_from_where" id="reply_from_where" value="User">'
        );
        $(".fTitle").removeClass("col-8").addClass("col-12");
      }
    }

    if ($("#reply_from_where").val() == "User") {
      // $("#groupid").attr("data-validate", true);
      $("#groupid").removeAttr("disabled");
    } else {
      // $("#groupid").removeAttr("data-validate");
      $("#groupid").attr("disabled", "disabled");
    }

    await Object.keys(obj).forEach(function (item) {
      // console.log("obj Items : ", item);
      if (
        item === "keywordsInput" ||
        item === "replyInput" ||
        item === "fbreplyInput"
      ) {
        const arr = obj[item].split(",");
        arr.forEach(function (value, index) {
          $("#" + item).tagsinput("add", value);
        });
      } else if (item === "latest_post") {
        if (obj[item] === "Y") {
          $("#latest_post").prop("checked", true);
        } else {
          $("#no_latest_post").prop("checked", true);
        }
      } else if (item === "tag_user") {
        if (obj[item] === "Y") {
          $("#tag_user").prop("checked", true);
        } else {
          $("#no_tag_user").prop("checked", true);
        }
      } else if (item === "selectfbreply") {
        if (obj[item] === "Y") {
          $("#selectfbreply").prop("checked", true);
          $("#selectfbreply").val("Y");
          $(".fallbackdiv").css("display", "block");
        } else {
          $("#selectfbreply").prop("checked", false);
          $("#selectfbreply").val("N");
          $(".fallbackdiv").css("display", "none");
        }
      } else if (item === "randomXminutes") {
        if (obj[item] === "Y") {
          $("#randomXminutes").prop("checked", true);
          $("#randomXminutes").val("Y");
          $(".randomMinute").css("display", "block");
        } else {
          $("#randomXminutes").prop("checked", false);
          $("#randomXminutes").val("N");
          $(".randomMinute").css("display", "none");
        }
      } else {
        $("#" + item).val(obj[item]);
      }
    });
  }
};

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

const getURLParams = function () {
  var vars = {};
  window.location.href.replace(
    /[?&]+([^=&]+)=([^&]*)/gi,
    function (m, key, value) {
      vars[key] = value;
    }
  );
  return vars;
};

/**
 * Form validation function
 * @param {Object} formData JSON object of the form elements
 */
const validateSettings = async function (formData) {
  let isValidData = true;
  // console.log(formData);
  Object.entries(formData).forEach((obj) => {
    // console.log("obj ::: ", obj[0]);
    const minimum = $("#" + obj[0]).data("min");
    if (
      $("#" + obj[0]).data("validate") === true &&
      obj[0] !== "fbreplyInput" &&
      (obj[1] === "" || obj[1].length === 0)
    ) {
      $("#" + obj[0] + "_error").text(
        $("#" + obj[0]).data("name") + " should not be left blank."
      );
      //   }
      if (!$("#" + obj[0] + "_error").hasClass("cf_errMsg")) {
        $("#" + obj[0] + "_error").addClass("cf_errMsg");
      } else {
        $("#" + obj[0] + "_error").removeClass("cf_errorShow");
      }
      isValidData = false;
      return false;
    } else if (
      $("#" + obj[0]).data("validate") === true &&
      obj[0] == "fbreplyInput"
    ) {
      if ($("#selectfbreply").is(":checked")) {
        if (obj[1] === "" || obj[1].length === 0) {
          $("#" + obj[0] + "_error").text(
            $("#" + obj[0]).data("name") + " should not be left blank."
          );
          if (!$("#" + obj[0] + "_error").hasClass("cf_errMsg")) {
            $("#" + obj[0] + "_error").addClass("cf_errMsg");
          } else {
            $("#" + obj[0] + "_error").removeClass("cf_errorShow");
          }
          // console.log("fb reply  :: ");
          isValidData = false;
          return false;
        }
      }
    } else if (typeof minimum !== "undefined" && obj[1] < minimum) {
      $("#" + obj[0] + "_error").text(
        $("#" + obj[0]).data("name") + " should not be less than " + minimum
      );
      isValidData = false;
      return false;
    } else {
      $("#" + obj[0] + "_error").text("");
    }
  });
  //   console.log("Is Valid?", isValidData);
  return await isValidData;
};

/**
 * This function make the serialized array to JSON object;
 * @param {*} serializedArray Array of objects of Serialized form Array
 */
const formDatatoJson = async function (serializedArray) {
  var result = {};
  $.each(serializedArray, function () {
    result[this.name] = this.value;
  });
  return await result;
};

/**
 * Save / Update form data
 * @param {Object} formData The data that user is providing
 */

const saveFormData = async function (
  formData,
  pages = null,
  user = null,
  general = null
) {
  const postUrl = $("#post_id").text();
  // console.log("Settings Arr", settingsArr);

  let payload;
  //console.log(formData);
  if (pages) {
    payload = {
      post_url: postUrl,
      user: user,
      pages: pages,
      active: "",
      reply_btn: Reply_Button,
      remember_button: Remember_Button,
      ...formData,
    };
    // payload = { post_url: postUrl, pages: pages, active:"", ...formData };
  } else {
    payload = {
      post_url: postUrl,
      user: user,
      active: "",
      reply_btn: Reply_Button,
      remember_button: Remember_Button,
      ...formData,
    };
    // payload = { post_url: postUrl, active:"", ...formData, };
  }
  //console.log("payloads are here", payload)

  if (general) {
    if (
      payload.reply_from_where !== "User" ||
      payload.groupid ===
        "No group is created. Please create message group & start a fresh"
    )
      delete payload.groupid;
    if (!$("#selectfbreply").is(":checked")) delete payload.fbreplyInput;

    if (!$("#randomXminutes").is(":checked")) delete payload.random_minute;
    // console.log("payload in general ::: ", general, " ::: ", payload);
    if (generalSettings.length == 0) {
      generalSettings.push(payload);
    } else {
      generalSettings[0] = payload;
    }
    return await users.saveGeneralSettings(generalSettings);
  } else {
    if (!settingsArr.length) {
      if (
        payload.reply_from_where !== "User" ||
        payload.groupid ===
          "No group is created. Please create message group & start a fresh"
      )
        delete payload.groupid;
      if (!$("#selectfbreply").is(":checked")) delete payload.fbreplyInput;
      if (!$("#randomXminutes").is(":checked")) delete payload.random_minute;
      settingsArr.push(payload);
      // console.log("user save setting>>>>>>",settingsArr);
      return await users.saveSettings(settingsArr);
    } else {
      const filteredNewSettings = settingsArr.filter(
        (obj) => obj.post_url !== postUrl
      );
      // //console.log(filteredNewSettings);
      if (
        payload.reply_from_where !== "User" ||
        payload.groupid ===
          "No group is created. Please create message group & start a fresh"
      )
        delete payload.groupid;
      if (!$("#selectfbreply").is(":checked")) delete payload.fbreplyInput;
      if (!$("#randomXminutes").is(":checked")) delete payload.random_minute;
      // //console.log(payload);
      const newSettings = [...filteredNewSettings, payload];
      return await users.saveSettings(newSettings);
    }
  }
};
