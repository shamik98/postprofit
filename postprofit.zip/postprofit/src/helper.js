// console.log("I am helper.js");

const authURL = require("./config.json");
const configStore = require("../public/kyubiSettings.json");
const { generalSettingsStorage, settingsStorage } = require("./storage");

const isEmptyObj = function (obj) {
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) return false;
  }
  return true;
};

const getAccessToken = function (res) {
  return res !== null &&
    res !== undefined &&
    res.store !== null &&
    res.store !== undefined &&
    res.store.user !== null &&
    res.store.user !== undefined
    ? res.store.user.token
    : null;
};

const checkAccessToken = function (res) {
  const token = getAccessToken(res);

  if (token !== null && token !== undefined && token.length > 0) {
    return true;
  }
  return false;
};

const doAuthCheck = function (accessToken) {
  if (
    accessToken !== undefined &&
    accessToken !== null &&
    accessToken.length > 0
  ) {
    return true;
  }
  return false;
};

const checkUserStatus = function (accessToken) {
  return new Promise(function (resolve, reject) {
    fetch(authURL.BASE_URL + "users/checkStatus", {
      method: "POST",
      mode: "cors",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ userToken: accessToken }),
    })
      .then((response) => response.json())
      .then((res) => {
        if (res.status == false) {
          reject(false);
        } else {
          resolve(true);
        }
      })
      .catch((err) => {
        reject(false);
      });
  });
};

const getLoggedInUser = () => {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get("emailID", function (items) {
      resolve(items.emailID);
    });
  });
};

const retriveGroups = () => {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.local.get("fcmessages", function (items) {
        if (typeof items.fcmessages === "undefined") {
          resolve(new Array());
        } else if (typeof items.fcmessages.groups.length === 0) {
          resolve(new Array());
        } else {
          resolve(items.fcmessages.groups);
        }
      });
    } catch (e) {
      resolve(new Array());
    }
  });
};

const getSettings = () => {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.local.get(["settings"], function (res) {
        if (!isEmptyObj(res)) {
          resolve(res.settings);
        } else {
          resolve(new Array());
        }
      });
    } catch (e) {
      resolve(new Array());
    }
  });
};

const getGeneralSettings = () => {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.local.get(["generalSettings"], function (res) {
        if (!isEmptyObj(res)) {
          resolve(res.generalSettings);
        } else {
          resolve(new Array());
        }
      });
    } catch (e) {
      resolve(new Array());
    }
  });
};

const retriveSegmentGroups = () => {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.local.get("fcmessages", function (items) {
        if (typeof items.fcmessages === "undefined") {
          chrome.storage.local.set(
            { fcmessages: { segments: [], groups: [] } },
            function () {
              resolve(new Array());
            }
          );
        } else if (typeof items.fcmessages.groups.length === 0) {
          chrome.storage.local.set(
            { fcmessages: { segments: [], groups: [] } },
            function () {
              resolve(new Array());
            }
          );
        } else {
          resolve(items.fcmessages);
        }
      });
    } catch (e) {
      resolve(new Array());
    }
  });
};

const saveSettings = async (arr) => {
  // console.log("arrayyyy inside save setting::::::",arr)
  if (configStore.appBaseBackendUrl) {
    await settingsStorage(arr, configStore);
  }
  return new Promise((resolve, reject) => {
    try {
      
      chrome.storage.local.set({ settings: arr }, function (res) {
        resolve(true);
      });
    } catch (e) {
      resolve(false);
    }
  });
};

const saveGeneralSettings = async (arr) => {
  // console.log("in general : ", arr);
  if (configStore.appBaseBackendUrl) {
    await generalSettingsStorage(arr, configStore);
  }
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.local.set({ generalSettings: arr }, function (res) {
        resolve(true);
      });
    } catch (e) {
      resolve(false);
    }
  });
};

const checkAuthStatus = () => {
  chrome.storage.local.get(["store"], function (res) {
    if (res && res.store) {
      if (
        res.store.user.email != null ||
        res.store.user.email != undefined ||
        res.store.user.email != ""
      ) {
        fetch(configStore.checkUserStatusURL, {
          method: "POST",
          mode: "cors",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email: res.store.user.email,
            extId: configStore.extId,
            deviceId: res.store.user.deviceID,
          }),
        })
          .then((response) => response.json())
          .then((res) => {
            const resp = res.data ? res.data : res;

            if (resp.status === false) {
              chrome.storage.local.remove("store", function () {
                window.location.href = "../login.html";
              });
            }
          })
          .catch((err) => {});
      } else {
        window.location.href = "../login.html";
      }
    }
  });
};

const getLoaderHtml = () => {
  return `<div class="ext_loader" style="display:none">
    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
      <circle cx="50" cy="50" r="32" stroke-width="8" stroke="#4267b2" stroke-dasharray="50.26548245743669 50.26548245743669" fill="none" stroke-linecap="round" transform="rotate(63.8978 50 50)">
        <animateTransform attributeName="transform" type="rotate" dur="1s" repeatCount="indefinite" keyTimes="0;1" values="0 50 50;360 50 50"></animateTransform>
      </circle>
      <circle cx="50" cy="50" r="23" stroke-width="8" stroke="rgba(66, 103, 178, 0.13725806451612899)" stroke-dasharray="36.12831551628262 36.12831551628262" stroke-dashoffset="36.12831551628262" fill="none" stroke-linecap="round" transform="rotate(-63.8978 50 50)">
        <animateTransform attributeName="transform" type="rotate" dur="1s" repeatCount="indefinite" keyTimes="0;1" values="0 50 50;-360 50 50"></animateTransform>
      </circle>
    </svg>
  </div>`;
};

module.exports = {
  retriveGroups: retriveGroups,
  checkAccessToken: checkAccessToken,
  getAccessToken: getAccessToken,
  doAuthCheck: doAuthCheck,
  getLoggedInUser: getLoggedInUser,
  retriveSegmentGroups: retriveSegmentGroups,
  checkUserStatus: checkUserStatus,
  getSettings: getSettings,
  saveSettings: saveSettings,
  checkAuthStatus: checkAuthStatus,
  isEmptyObj: isEmptyObj,
  saveGeneralSettings: saveGeneralSettings,
  getGeneralSettings: getGeneralSettings,
};
