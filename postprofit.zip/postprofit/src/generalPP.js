const $ = (jQuery = require("jquery"));
var users = require("./helper.js");
const configStore = require("../public/kyubiSettings.json");
const { generalPPStorage } = require("./storage.js");
let data = [];
let generalSettings = [];
let generalPayload, post_id, messageId;
let index = -1;
var port = chrome.runtime.connect({
  name: "Popup-Background",
});
// let portFromContentScript = null;
// const connectPort = () => {
//   // eslint-disable-next-line no-undef
//   portFromContentScript = chrome.runtime.connect({
//     name: "Popup-Background",
//   });

//   portFromContentScript.onDisconnect.addListener(() => {
//     console.log("Disconnected");
//     connectPort();
//   });
// };

// connectPort();

var gp_url, params, post_url;
$(document).ready(function () {
  $("#cf_edit").click(function () {
    chrome.storage.local.get(["userFBData"], function (data) {
      window.open(
        chrome.runtime.getURL(
          "settings.html?user=" + data.userFBData.username + "&general=true"
        )
      );
    });
  });
  chrome.storage.local.get("general_post_urls", function (url) {
    chrome.storage.local.get(["generalSettings"], function (res) {
      // console.log(
      //   "!url.general_post_urls && !res.generalSettings ::: ",
      //   !url.general_post_urls || !res.generalSettings
      // );
      // console.log("url.general_post_urls :: ", !url.general_post_urls);
      // console.log("res.generalSettings :: ", !res.generalSettings);

      $("#save_in_gp").click(async function () {
        gp_url = $("#save_url").val();
        // console.log("gp Url", gp_url)
        if (gp_url) {
          params = getURLParams(gp_url);
          // console.log("params : ", params);
          if (params.story_fbid) {
            messageId = params.story_fbid;
          } else if (params.fbid) {
            messageId = params.fbid;
          }
          // console.log("messageId : ", messageId);
          // if(!messageId){
          if (!messageId) {
            var id = gp_url.split("/");
            // console.log("id : ", id);
            messageId = id[id.length - 1];
            if (messageId == "") messageId = id[id.length - 2];
          }
          // console.log("messageId : ", messageId);
          post_url = "https://m.facebook.com/" + messageId;
          // console.log("post_url : ", post_url);
          if (
            url.general_post_urls !== undefined &&
            url.general_post_urls !== null &&
            url.general_post_urls !== "undefined"
          ) {
            // console.log("urls ::: ", url);
            post_id = url.general_post_urls;
          } else {
            post_id = [];
          }
          setTimeout(async function () {
            // console.log("post_id :: ", post_id);
            if (!post_id.length || !post_id) {
              post_id.push(post_url);
              chrome.storage.local.set({ general_post_urls: post_id });
              if (configStore.appBaseBackendUrl) {
                await generalPPStorage(post_id);
              }
            } else {
              // $(".settings_page_overlay > span").html(`<div class="loadDots_settings"><span style=" top: -10px; position: relative; "></span><span></span><span></span></div><br>`+"We are almost there. Saving Post URL in General Post Profits... <br>Please don't close the page");
              const filteredNew_post_url = post_id.filter(
                (obj) => obj !== post_url
              );
              // console.log("filteredNew_post_url ::: ", filteredNew_post_url);
              const new_post_url = [...filteredNew_post_url, post_url];
              // console.log("new_post_url ::: ", new_post_url);
              chrome.storage.local.set({ general_post_urls: new_post_url });
              if (configStore.appBaseBackendUrl) {
                await generalPPStorage(new_post_url);
              }
            }
            location.reload();
          }, 500);
        }
      });

      if (res.generalSettings) {
        if (res.generalSettings[0].active === "") {
          $("#stop").hide();
          $("#start").show();
        } else {
          $("#start").hide();
          $("#stop").show();
        }
      }
      if (!url.general_post_urls || !res.generalSettings) {
        $("#start").attr("disabled", "disabled");
      }
    });

    if (url.general_post_urls) {
      $("#start").removeAttr("disabled");
      data = url.general_post_urls;
      // console.log("data :: ", data);
      data.forEach(function (value, i) {
        // console.log("postUrl",i," ::: ",value);
        $("#content_list").append(
          `<div class="funnel_control post_url" id = "funnel_control">
          <p>` +
            value +
            `</p>
          <a href="javascript:void(0)" class="cf_delete" id="cf_delete` +
            i +
            `">
          <svg xmlns="http://www.w3.org/2000/svg" width="13" height="14" viewBox="0 0 13 14" class="shape_remove"><g transform="translate(-2)"><g transform="translate(2)"><path class="a" d="M13.964,8h-9.2a.6.6,0,0,0-.667.647l1.067,7.707a1.268,1.268,0,0,0,1.334,1h5.667a1.268,1.268,0,0,0,1.334-1l1.067-7.707A.554.554,0,0,0,13.964,8Z" transform="translate(-2.859 -3.354)"/><path class="a" d="M13.7,1.177H10.45A1.247,1.247,0,0,0,9.15,0H7.85a1.247,1.247,0,0,0-1.3,1.177H3.3A1.247,1.247,0,0,0,2,2.353v.588a.587.587,0,0,0,.65.588h11.7A.587.587,0,0,0,15,2.942V2.353A1.247,1.247,0,0,0,13.7,1.177Z" transform="translate(-2)"/></g></g></svg>
          </a>
          </div><br>`
        );
      });

      data.forEach(function (value, i) {
        // console.log("delete button", $("#cf_delete" + i));
        $("#cf_delete" + i).click(async function () {
          // console.log(
          //   i + 1,
          //   "th Delete button pressed.",
          //   $("#funnel_control")[0]
          // );
          let ConfirmMsg = confirm("Are you sure you want to Delete the Card?");
          if (ConfirmMsg == true) {
            let new_set_arr = url.general_post_urls.filter(function (res) {
              return res != value;
            });
            // console.log("without deleted item: ", new_set_arr);
            chrome.storage.local.set({ general_post_urls: new_set_arr });
            if (configStore.appBaseBackendUrl) {
              await generalPPStorage(new_set_arr);
            }
            //   });
            $("#funnel_control")[0].remove(function () {
              // console.log("Card removed.");
            });
            location.reload();
          }
        });
      });

      $("#start").click(function () {
        $(this).hide();
        $("#stop").show();
        startGeneralPP(data);
      });

      $("#stop").click(function () {
        $(this).hide();
        $("#start").show();
        stopGeneralPP();
      });

      function startGeneralPP(data) {
        // console.log("data : ", data);
        // generalSettings = users.getGeneralSettings();
        chrome.storage.local.get("generalSettings", function (res) {
          // console.log("res : ", res);
          index = Math.floor(Math.random() * data.length);
          generalPayload = res.generalSettings[0];
          if (generalPayload.active === "") {
            // console.log("generalSettings : ", generalPayload);
            // console.log(generalPayload.active);
            // console.log(generalPayload.post_url);
            // console.log(index + " : " + data[index]);
            generalPayload.post_url = data[index];
            generalPayload.active = "active";
            // console.log(generalPayload.post_url);
            // console.log(generalPayload.active);
            var genPayload = [];
            genPayload.push(generalPayload);
            chrome.storage.local.set(
              { generalSettings: genPayload },
              function () {
                // console.log("added active class");
              }
            );
          }
          if(data.length==1){
            generalPayload.single_Link=true;
          }
          const payload = {
            action: "startGeneralPP",
            position: index,
            payload: generalPayload,
          };
          port.postMessage(payload);
        });
      }

      function stopGeneralPP() {
        chrome.storage.local.get("generalSettings", function (res) {
          // console.log("res : ", res);
          var generalPayloads = res.generalSettings[0];
          // console.log(
          //   "generalPayloads : ",
          //   generalPayloads,
          //   "generalPayloads.active : ",
          //   generalPayloads.active
          // );
          if (generalPayloads.active === "active") {
            generalPayloads.active = "";
            var genPayloads = [];
            // console.log("genPayloads before push : ", genPayloads);
            genPayloads.push(generalPayloads);
            // console.log("generalPayloads.active : ", generalPayloads.active);
            // console.log("genPayloads : ", genPayloads);
            // console.log("");
            chrome.storage.local.set(
              { generalSettings: genPayloads },
              function () {
                // console.log("remove active class");
              }
            );
            // chrome.storage.local.get(tabId,function(res){
            port.postMessage({ action: "stopGeneralPP" });
            // });
          }
        });
      }
    }
  });
});

const getURLParams = function (gp_url) {
  var vars = {};
  gp_url.replace(/[?&]+([^=&]+)=([^&]*)/gi, function (m, key, value) {
    vars[key] = value;
  });
  return vars;
};
