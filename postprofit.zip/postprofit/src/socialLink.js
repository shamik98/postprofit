import * as $ from "jquery";



var user = require("./helper.js");
// var urls = config.regexUrls;
var emailID;
$(document).ready(function () {
    user.checkAuthStatus(); // Check Auth
    // Populating Hamburger Menu
    chrome.storage.local.get(["store"], function (res) {
        // console.log("STORE", store);
        //return;
        $(".loggedInAs").text(res.store.user.email);
        emailID = res.store.user.email;
    });

    // return;

    $.getJSON("kyubiSettings.json", async function (data) {
        if (data.extId == "5e944f24568e944b9d22418f") {
            // console.log("WINDOW", window.location.href)
            fetch("https://app.kyubi.io/api/end-user/get-links/", {
                method: "POST", // *GET, POST, PUT, DELETE, etc.
                mode: "cors", // no-cors, cors, *same-origin
                headers: {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*",
                },
                body: JSON.stringify({
                    "email": emailID.toLowerCase(),
                    "ext_id": data.extId,
                }), // body data type must match "Content-Type" headerbody data type must match "Content-Type" header
            })
                .then(async (response) => response.json())
                .then(async (res) => {
                    const resp = res.data ? res.data : res;
                    if (res.status == true) {
                        // console.log("RESPONSE FROM KYUBI", resp);
                        // console.log("FRIENDER LINK", resp.links[0].link)
                        $('#friender-link').attr("href", resp.links[0].link);
                        $('#friender-link').text(resp.links[0].title)

                        $('#click-link').attr("href", resp.links[1].link);
                        $('#click-link').text(resp.links[1].title)


                    }
                })
        }

    })
})




$(function () {
    $.getJSON("kyubiSettings.json", function (data) {
        let currentHTML = location.href.split("/")[3];
        // console.log("DATA FROM KYUBI", data);
        // console.log("CURRENT HTML", currentHTML);
        


        $(".cf_footer").append(
            `<p>` +
            (data.footer.poweredBy.label != null && data.footer.poweredBy.label.length > 0 &&
                data.footer.poweredBy.url != null && data.footer.poweredBy.url.length > 0 &&
                data.footer.partnership.label != null && data.footer.partnership.label.length > 0 &&
                data.footer.partnership.url != null && data.footer.partnership.url.length > 0 ?
                `Powered by <a href=${data.footer.poweredBy.url} target="_blank">${data.footer.poweredBy.label}</a> and the
            <a href=${data.footer.partnership.url} target="_blank" id="official_page">${data.footer.partnership.label}</a>
            </p>` :
                data.footer.poweredBy.label != null && data.footer.poweredBy.label.length > 0 &&
                    data.footer.poweredBy.url != null && data.footer.poweredBy.url.length > 0 ?
                    `Powered by <a href=${data.footer.poweredBy.url} target="_blank">${data.footer.poweredBy.label}</a>` :
                    "")  
            +
            ` 
            <ul>
            <li>
            `


            +
            (data.footer.officialGroup.willBeDisplayed == true ?
                ` <a href=${data.footer.officialGroup.url} target="_blank" >
                   <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" class="fb-ico">
            <path class="a"
              d="M15.75,18H2.25A2.248,2.248,0,0,1,0,15.75V2.25A2.248,2.248,0,0,1,2.25,0h13.5A2.248,2.248,0,0,1,18,2.25v13.5A2.248,2.248,0,0,1,15.75,18ZM5.349,7.117v2.5H7.507v6.415h2.581V9.616h2.153l.322-2.5H10.089v-1.6a2.168,2.168,0,0,1,.048-.5.905.905,0,0,1,.183-.384.836.836,0,0,1,.377-.249,1.917,1.917,0,0,1,.631-.088h1.324V2.067a17.618,17.618,0,0,0-1.929-.1,3.025,3.025,0,0,0-3.215,3.3V7.117Z" />
          </svg>
                   </a>` :
                "")
            + `&nbsp;&nbsp;&nbsp;` +
            (data.footer.chatSupport.willBeDisplayed == true ?
                `
                <a href=${data.footer.chatSupport.url} target="_blank" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" class="msg-ico">
            <g transform="translate(-1.998 -1.998)">
              <path class="a"
                d="M17.741,20H4.249A2.2,2.2,0,0,1,2,17.76V4.249A2.2,2.2,0,0,1,4.249,2h13.5A2.2,2.2,0,0,1,20,4.249v13.5A2.263,2.263,0,0,1,17.741,20ZM10.028,8.254,4.808,13.743l4.731-2.571,2.468,2.571,5.181-5.489L12.5,10.825Z" />
            </g>
          </svg>
               
                </a>
                
                
            ` :
                "") 
            


        );
       

       
    });
});