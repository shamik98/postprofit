const $ = jQuery = require('jquery');
const configStore = require("../public/kyubiSettings.json");
const url = require("./config.json");
$(document).ready(function() {
    //console.log(url.BASE_URL);
    $("#forgotPass").click(function(e) {
        e.preventDefault();
        // alert("on submit comming");
        var email = $("#email").val();
        var mailregex = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
        if(email.length==0){
            $(".cf_errMsg").html("Provide your email id please.");
        }
        else if (!mailregex.test(email)) {
            $(".cf_errMsg").html("Put valid email id please.");
        //     if (!$(".bgInput").hasClass("cf_errMsglogin")) {
        //         $(".bgInput").addClass("cf_errMsglogin")
        //     }
        //     return
        }
        // //console.log("Asdfasd asdxcas");
        else {
            //console.log("mail is valid");
            // if ($(".bgInput").hasClass("cf_errMsglogin")) {
            //     $(".bgInput").removeClass("cf_errMsglogin")
            //     //console.log("class removed");
            // }
            forgot(email);
        }
    });
});

const forgot = function(email) {
    fetch(configStore.forgotPassURL, {
        method: "POST", // *GET, POST, PUT, DELETE, etc.
        mode: "cors", // no-cors, cors, *same-origin
        headers: {
            "Content-Type": "application/json",
            "Accept": "application/json"
        },
        body: JSON.stringify({ email: email, extId: configStore.extId}) // body data type must match "Content-Type" header
    }).then(response => response.json()).then(res => {
        //console.log("response from server", res);
        // window.location.href = "../congratulation.html";
        if (res.status) {
            // //console.log("response from server", res)
            window.location.href = "../confirmation.html";
            // if ($("#emailid").hasClass("error")) {
            //     $("#emailid").removeClass("error")
            // }
        } else {
            $("#wrongmail").html(res.message);
            // if (!$("#emailid").hasClass("error")) {
            //     $("#emailid").addClass("error")
            // }
        }
        // //console.log("Response ", res);
    });
}