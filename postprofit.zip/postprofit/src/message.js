var $ = jQuery = require('jquery');
$(function() {
    var msgCreateArea = $('.messageSetCreate');
    var outputArea = $('.outputTxt');
    var inputCreateParent = $('.inputAreaCreate');
    var inputTextBox = $('.inputAreaCreate input');
    var addMsgBtn = $('.addThisMsg');
    var listedMsgEl = $('.listCreatedMsg');
    var listedMsgParent = listedMsgEl.find('ul');
    var createMoreMsgBtn = $('.createmore');
    var headerlabel = $('.headerLabel span');
    var btnDelListing = $('.btn-delete');
    var menuFilterTrigger = $('.setMenuType');
    var setMenuBtn = $('.setMenuParent').find('.setMenu:not(.setMenu-staticTxt)');
    var groupAddArea = $('.groupSet');
    var groupListedArea = '.listCreatedGroups';
    var groupListedList = $(groupListedArea).find('ul');
    var headerMsg = ['Click on the <strong>"keyword"</strong> to insert into your message', '"Double Click" on any message block to edit.'];

    var closePopupBtn = $('.closePopup');

    $(document).ready(function() {
        // disable enter key inside input box inside form
        $(".starter-template .form-group input").bind("keypress", function(e) {
            if (e.keyCode == 13) {
                return false;
            }
        });
        // disable enter key inside input box inside form --- END

        // auto height textarea
        $('.messageSetBlock textarea').on('input change keyup change DOMSubtreeModified', function(e) {
            if($(this).val() !== ''){
                $(e.target)[0].style.height = $(e.target)[0].scrollHeight+"px";
            }
            else {
                $(e.target)[0].style.height = "auto";
            }
        });
        // auto height textarea --- END


        // navbar toggle
        $('.navbar-toggler').click(function() {
            $('.menuSidebar').stop()
                .toggleClass('show');
            if($(this).attr("aria-expanded") === "true") {
                $(this).attr("aria-expanded","false");
            }
            else {
                $(this).attr("aria-expanded","true");
            }
        })

        // hide all preview images at first
        $('.popupOuter').find('.prevw-i').hide();
        // hide all preview images at first --- END

        // remove Group set listing
        $(document).on('click', ('.removeGroupListing'), function(e) {
            if($(this).parents('ul').find('li').length < 1){
                $(this).parents(msgCreateArea).find('.messageCreateGroups').show();
            }
            // $(this).parents('.listCreatedGroups').hide();
            $(this).parents('li').remove();
            e.preventDefault();
        })
        // remove Group set listing --- END
        
        // setMenu button functions
        setMenuBtn.on('click', function(e) {
            var targetClicked = $(e.target);
            var dataValue = targetClicked.attr('data-value');
            var dataID = targetClicked.attr('data-id');
            var thisGroupInsert = targetClicked.closest('.groupSet').find('.outputTxt');
            if (dataID) {
                var thisValue = '<span class="setItem segItem" contentEditable="false" data-id="' + dataID + '"> '+dataValue+' <button type="button" class="removeMsg"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><g class="a" transform="translate(-2 -2)"><path class="b" d="M10,2a8,8,0,1,0,8,8A8.024,8.024,0,0,0,10,2Zm3.92,10.8L12.8,13.92,10,11.12l-2.8,2.8L6.08,12.8,8.88,10,6.08,7.2,7.2,6.08,10,8.88l2.8-2.8L13.92,7.2,11.12,10Z"/></g></svg> </button></span>';
            } else {
                var thisValue = '<span class="setItem keyItem" contentEditable="false"> '+dataValue+' <button type="button" class="removeMsg"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><g class="a" transform="translate(-2 -2)"><path class="b" d="M10,2a8,8,0,1,0,8,8A8.024,8.024,0,0,0,10,2Zm3.92,10.8L12.8,13.92,10,11.12l-2.8,2.8L6.08,12.8,8.88,10,6.08,7.2,7.2,6.08,10,8.88l2.8-2.8L13.92,7.2,11.12,10Z"/></g></svg> </button></span>';
            }
            
            thisGroupInsert.children().last().remove();
            thisGroupInsert.append(thisValue);
            targetClicked.parent().hide();
            targetClicked.parents('.setOptions').removeClass('active-menu');
        })
        // setMenu button functions --- END

        // show group set add button function
        groupAddArea.find('.outputTxt').on('DOMSubtreeModified', function(e) {
            var childLength = $(e.target).children().length;

            if(childLength > 0) {
                $(this).closest('.groupSet').find('.addThisMsg').show(); 
                $(this).closest('.groupSet').find('.triggerInsert span').css('display', 'inline-block');
            }
            else if(childLength === 0) {
                $(this).closest('.groupSet').find('.addThisMsg').hide();
                $(this).closest('.groupSet').find('.triggerInsert span').hide();
            }
            else {
                $(this).closest('.groupSet').find('.addThisMsg').hide();
                $(this).closest('.groupSet').find('.triggerInsert span').hide();
            }
        })
        // show group set add button function --- END

        // get static message function
        $('.submitTxt').on('click', function() {
            var thisTxtBox = $(this).closest('.setMenu').find('textarea');
            var txtTotal = '<span class="setItem" contentEditable="false"> '+thisTxtBox.val()+' <button type="button" class="removeMsg"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><g class="a" transform="translate(-2 -2)"><path class="b" d="M10,2a8,8,0,1,0,8,8A8.024,8.024,0,0,0,10,2Zm3.92,10.8L12.8,13.92,10,11.12l-2.8,2.8L6.08,12.8,8.88,10,6.08,7.2,7.2,6.08,10,8.88l2.8-2.8L13.92,7.2,11.12,10Z"/></g></svg> </button></span>'
            if(thisTxtBox.val() !== '') {
                $(this).closest(inputCreateParent).find('.outputTxt').append(txtTotal);
                closeMenu();
            }
        })
        // get static message function --- END

        //filter menu into 3 parts to bring up the next menu
        menuFilterTrigger.on('click', function(e) {
            if($(e.target).is(':button')){
                var thisDataFilter = $(e.target).attr('data-value');   
                var thisValue = '<div class="setItem" contentEditable="false"> '+thisDataFilter+' <button type="button" class="removeMsg"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><g class="a" transform="translate(-2 -2)"><path class="b" d="M10,2a8,8,0,1,0,8,8A8.024,8.024,0,0,0,10,2Zm3.92,10.8L12.8,13.92,10,11.12l-2.8,2.8L6.08,12.8,8.88,10,6.08,7.2,7.2,6.08,10,8.88l2.8-2.8L13.92,7.2,11.12,10Z"/></g></svg> </button></div>'         
                
                switch(thisDataFilter) {
                    case 'Message Segment':
                        $('.setMenuType')
                            .hide();
                        $(e.target).parents(groupAddArea).find('.outputTxt').append(thisValue);
                        $(e.target).parents(groupAddArea).find('.outputTxt .setItem').last().addClass('in_edit');
                        $('.setMenu-messageSeg')
                            .show();
                        break;
                    case 'Static Text':
                        $('.setMenuType')
                            .hide();
                        $('.setMenu-staticTxt')
                            .show()
                            .find('textarea')
                            .val('')
                            .focus();
                        break;  
                    case 'Keywords':
                        $('.setMenuType')
                            .hide();
                        $(e.target).parents(groupAddArea).find('.outputTxt').append(thisValue);
                        $(e.target).parents(groupAddArea).find('.outputTxt .setItem').last().addClass('in_edit');
                        $('.setMenu-keywords')
                            .show();
                        break;      
                    default:
                        e.preventDefault();
                        break;                
                }
            }
        })
        //filter menu into 3 parts to bring up the next menu --- END

        // insert menu trigger function   
        function closeMenu() {
            var dropdownOpen = document.getElementsByClassName('active-menu');

            if(dropdownOpen.length > 0) { 
                dropdownOpen[0].classList.remove("active-menu"); 
            }
        }
        $('.triggerInsert').click(function(e) {
            e.stopPropagation();
            $('.setMenu').hide();
            if($(this).parent().hasClass('active-menu')){
                $(e.target).parent().removeClass('active-menu');
                $('.addThisMsg').show();
            } else {
                $(e.target).parent().addClass('active-menu');
                $('.setMenuType').show();
                $('.addThisMsg').hide();
            }
        })
        // insert menu trigger function --- END

        //Delete Groups/Message listing from main-list
        btnDelListing.on('click', function() {
            $(this).parents('.listItem').remove();
        });
        //Delete Groups/Message listing from main-list --- END

        //double click to edit
        //double click to edit --- END

        // create more message function
        createMoreMsgBtn.on('click', function(e) {
            var thisParent = $(e.target).parent();
            if(thisParent.hasClass('createMoreMsg')){
                $(e.target).parents(msgCreateArea).find('.messageCreateBlocks').show();
                $(e.target).parents(msgCreateArea).find('.inputAreaCreate textarea').val('');
            }
            else if(thisParent.hasClass('createMoreGroup')) {
                $(e.target).parents(msgCreateArea).find('.messageCreateGroups').show();
            }
        })
        // create more message function --- END

        // remove Message block
        $(document).on('click', '.removeMsg', function() {
            var thisparent = $(this).parent().attr('class').split(' ')[0];
            // ////console.log(thisparent);
            switch(thisparent) {
                case 'setItem': 
                    $(this).parent().remove();
                    break;
                case 'msgCreated':
                    var lengthBefore = $(this).parents('ul').find('li').length;
                    
                    if((lengthBefore - 1) == 0 || (lengthBefore - 1) == NaN) {
                        $(this).parents('.listCreatedMsg').find('.triggerMore').hide();
                        $(this).parents('.messageCreateP').find('.messageCreateBlocks').show();
                        $(this).parents(msgCreateArea).find(headerlabel).html(headerMsg[0]);
                    }
        
                    $(this).parents('li').remove();
                    break;
            }
            $('.setMenuParent .setMenu').hide();
            $('.setOptions').removeClass('active-menu');
            $('.in_edit').remove();
        });
        // remove Message block --- END

        $('.inputAreaCreate textarea').each(function() {
            $(this).on('change input keyup keydown', function(e) {
                if($(this).val() !== '') {
                    $(this).parent('.messageSetBlock').find('.addThisMsg').show();
                }
                else {
                    $(this).parent('.messageSetBlock').find('.addThisMsg').hide();
                }
            })
        })

        // add msg to list
        $('.addThisMsg').each(function() {
            $(this).click(function(e) {
                if($(this).parents('.form-group').hasClass('messageCreateP')){
                    var contentThis = $(e.target).parent().find('textarea').val();
                    var thisListCreateArea = $(e.target).parents('.messageCreateP').find(listedMsgParent);
                    
                    if(contentThis !== '') {
                        var closestCheckboxes = $(e.target).parents('.messageCreateBlocks').find('.dynamicInput input');
                        // var outputThis = $(e.target).parents('.messageCreateBlocks').find(outputArea);
                        // var inputThis = $(e.target).parents('.messageCreateBlocks').find(inputTextBox);

                        thisListCreateArea.append('<li><div class="msgCreated">'+contentThis+'<button type="button" class="removeMsg"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><g class="a" transform="translate(-2 -2)"><path class="b" d="M10,2a8,8,0,1,0,8,8A8.024,8.024,0,0,0,10,2Zm3.92,10.8L12.8,13.92,10,11.12l-2.8,2.8L6.08,12.8,8.88,10,6.08,7.2,7.2,6.08,10,8.88l2.8-2.8L13.92,7.2,11.12,10Z"/></g></svg></button></div></li>');

                        // $(e.target).parent().find(outputArea).empty();
                        $(e.target).parent().find('textarea').val('');
                        for(var i = 0; i < closestCheckboxes.length; i++) {
                            closestCheckboxes[i].checked = false;
                        };
                        // ((outputThis.children().length > 0 && outputThis.find('strong').length > 0) ? 
                        //     inputThis.parent().find('.addThisMsg').show() : inputThis.parent().find('.addThisMsg').hide());

                        $(e.target).parents(listedMsgEl).find('.triggerMore').show();   
                        $(e.target).parents(msgCreateArea).find('.messageCreateBlocks').hide();
                        $(e.target).parents(msgCreateArea).find(headerlabel).html('');
                    }
                }
                else if($(this).parents('.form-group').hasClass('messageSetCreate')) {
                    var thisListGroupListing = $(e.target).parents('.messageSetCreate').find(groupListedList);
                    var outputThis = $(e.target).parents('.messageCreateGroups').find('.outputTxt');
                    $('.in_edit').remove();
                    $('.setMenuParent .setMenu').hide();
                    $('.setOptions').removeClass('active-menu');

                    if(outputThis.children().length !== 0) {                        
                        $(e.target).parents('.messageSetCreate').find('.listCreatedGroups').show();
                        thisListGroupListing.append('<li><div class="groupI">'+outputThis.html()+'<button type="button" class="removeGroupListing"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><g class="a" transform="translate(-2 -2)"><path class="b" d="M10,2a8,8,0,1,0,8,8A8.024,8.024,0,0,0,10,2Zm3.92,10.8L12.8,13.92,10,11.12l-2.8,2.8L6.08,12.8,8.88,10,6.08,7.2,7.2,6.08,10,8.88l2.8-2.8L13.92,7.2,11.12,10Z"/></g></svg></button></div></li>');
                        $(e.target).parent().find('.outputTxt').empty();
                        
                        $(e.target).parents(listedMsgEl).find('.triggerMore').show();   
                        $(e.target).parents('.messageCreateGroups').hide();
                    }
                }
            })
        })
        // add msg to list --- END

        // show/hide add button on input add
        outputArea.each(function() {
            $(this).on('change', function() {
                (($(this).find('strong').length > 0 && outputThis.children().length > 0) ? $(this).parent().find('.addThisMsg').show() : $(this).parent().find('.addThisMsg').hide());
            })
        })
        // show/hide add button on input add --- END

        // open popup from view button function
        var slideIndex = 0;
        var loopSlideFunc;
        function showSlides(element) { 
            clearTimeout(loopSlideFunc);
            var i;             
            // get the array of divs' with classname image-sliderfade 
            
            var slides = element.parents('.create-segment').find('.prevw-i'); 
                        
            for (i = 0; i < slides.length; i++) { 
                // initially set the display to  
                // none for every image. 
                slides[i].style.display = "none";  
            }          
               
            // increase by 1, Global variable 
            slideIndex++;  
                        
            // check for boundary 
            if (slideIndex > slides.length){ 
                slideIndex = 1; 
            }     
            slides[slideIndex - 1].style.display = "block"; 
        
            loopSlideFunc = setTimeout(() => {
                showSlides(slides);
                ////console.log(slideIndex)
            }, 1000); 
        } 
        $('.view').on('click', function(e) {
            e.stopPropagation();
            var thispopup = $(this).parents('.create-segment').find('.popupOuter');
            var thisTarget = $(this);

            thispopup.fadeIn();
            
            // showSlides(thisTarget);
            return false;
        })
        // open popup from view button function --- END

        // close popup function
        $('.popupOuter').click(function(e) {
            if (e.target !== this) {
                return;
            }
            else {
                $('.popupOuter').fadeOut();
                clearTimeout(loopSlideFunc);
            }
        })
        closePopupBtn.click(function() {
            clearTimeout(loopSlideFunc);
            $(this).parents('.popupOuter').fadeOut();
        })
        // close popup function --- END

        // first/last name checkbox function
        function insertAtCaret(areaId, text) {
            var txtarea = document.getElementById(areaId);
            if (!txtarea) {
                return;
            }

            var scrollPos = txtarea.scrollTop;
            var strPos = 0;
            var br = ((txtarea.selectionStart || txtarea.selectionStart == '0') ?
                "ff" : (document.selection ? "ie" : false));
            if (br == "ie") {
                txtarea.focus();
                var range = document.selection.createRange();
                range.moveStart('character', -txtarea.value.length);
                strPos = range.text.length;
            } else if (br == "ff") {
                strPos = txtarea.selectionStart;
            }

            var front = (txtarea.value).substring(0, strPos);
            var back = (txtarea.value).substring(strPos, txtarea.value.length);
            txtarea.value = front + text + back;
            strPos = strPos + text.length;
            if (br == "ie") {
                txtarea.focus();
                var ieRange = document.selection.createRange();
                ieRange.moveStart('character', -txtarea.value.length);
                ieRange.moveStart('character', strPos);
                ieRange.moveEnd('character', 0);
                ieRange.select();
            } else if (br == "ff") {
                txtarea.selectionStart = strPos;
                txtarea.selectionEnd = strPos;
                txtarea.focus();
            }

            txtarea.scrollTop = scrollPos;
        }
        $('.dynamicInput button').on('click', function(e) {
            var checkedValue = e.target.value;
            var outputThis = $(e.target).parents('.messageCreateBlocks').find('textarea');
            var idTxt = outputThis.attr('id');

            outputThis.next('.addThisMsg').show();

            insertAtCaret(idTxt,checkedValue);
        })
        // first/last name checkbox function --- END

        inputCreateParent.find('input[type=text]').each(function() {
            var thisVal = $(this).val();
            var thisParent = $(this).parent('.messageSetBlock');
            
            $(this).on('keyup keydown keypress', function() {
                thisTemp = $(this).val();
                
                thisParent.find('.outputTxt').text(thisTemp);
            });
        })
        
        inputCreateParent.on('click', function() {
            $(this).find('input').trigger('focus');

            $(this).find('input').focus().val($(this).find('input').val());
        })
    })
})

// var fname = $("#spanidfname").text();
// var existingText = $(".outputTxt").text();
// var newText = existingText + " "+fname;
// $(".outputTxt").text(newText);
// $("messageTxtbox").val(newText);