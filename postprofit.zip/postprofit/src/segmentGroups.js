var $ = (jQuery = require("jquery"));
const config = require("./config");
var helper = require("./helper");
const configStore = require("../public/kyubiSettings.json");
const { segmentStorage, deleteSegmentStorage, segmentEditStorage } = require("./storage.js");
var urls = config.regexUrls;
var editIndex = null;
var slideLoopTimeout;
var slideIndx = 0;
var segments = {};
var messages = { fcmessages: { segments: [], groups: [] } };

$(document).ready(async function () {
  editIndex = window.localStorage.getItem("tempEditIndex");
  /* Fetching and showing saved email id */
  $(".loggedInAs").text(await helper.getLoggedInUser());
  /* Fetching the object for segment and groups if any */
  messages.fcmessages = await helper.retriveSegmentGroups();
  if (editIndex !== null) {
    window.localStorage.removeItem("tempEditIndex");
    $("#segmentID").val(editIndex);
    await populateSegmentForEdit(editIndex);
  }
  /* Populate segment list in the segments page */
  await populateSegmentLists(messages.fcmessages);
  /* Redirect user to default popup for the relevant page if clicks on home icon */
  $(".home").click(function () {
    getCheckCurrentUrl();
  });
  /* Saving or updating the Message Segment */
  $(".saveMsgSegment").click(function () {
    // //console.log(validateSegment());
    if (validateSegment()) {
      if ($("#segmentID").val()) { //.length
        updateSegment($("#segmentID").val());
      } else {
        saveSegment();
      }
    }
  });

  $("#createSegment").on('submit', (e) => {
    e.preventDefault()
  })

  await putContentsForDOM();
});

const validateSegment = function () {
  //console.log("Validation called");
  let isValid = false;
  const title = $(".segmentTitle").val();
  const segmentsBody = $("#textMsg").val();
  const alphaRegex = /^[A-Za-z0-9 ]+$/;
  // //console.log("Title match",title.match(alphaRegex));
  // //console.log("Regex test",alphaRegex.test(title));

  if (!title.length || !alphaRegex.test(title)) {
    //console.log("Title Error");
    $("#titleError")
      .fadeIn()
      .text("Please input the title with alpha numeric characters only")
      .delay(1000)
      .fadeOut();
  } else {
    isValid = true;
  }
  if (!$(".segmentCreated ul li").length) {
    $("#segmentError")
      .fadeIn()
      .text("Please add atleast one segment")
      .delay(1000)
      .fadeOut();
    return false;
  } else {
    isValid = true;
  }

  return isValid;
};
/**
 * Initializing the click for edit, view and delete button after initializing the list of segments
 */
const putContentsForDOM = async function () {
  // setTimeout(() => {
  // await $(".view").click(async function() {
  //     await viewSegment($(this).data('blocks'));
  //     await $(".popupOuter").css("display","block");
  //     await slideLightBoxItems($(".view"));
  // });

  await $(".editSegment").click(function () {
    editIndex = $(this).data("id");
    window.localStorage.setItem("tempEditIndex", editIndex);
    window.location.href = "segment-create.html";
  });

  await $(".delSegment").click(function () {
    // if (
    //   confirm(
    //     "If you delete this segment it will be unassigned from everywhere you assigned in a group. Are you sure?"
    //   )
    // ) {
      deleteSegment($(this).data("id"));
    // }
  });
  // },800);
};

/**
 * Get and check the current url and show the popup based on that.
 */
const getCheckCurrentUrl = function () {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    const redirectTo = urls.filter((el) => {
      return el.regex.test(tabs[0].url) == true;
    });
    window.location.href = "./" + redirectTo[0].popup;
  });
};
/**
 * Saving the message segment
 */
const saveSegment = async function () {
  let newItems =
    typeof messages.fcmessages.segments === "undefined"
      ? new Array()
      : messages.fcmessages.segments;
  var location = "segment-listing.html";
  if (newItems.length) {
    messages.fcmessages.segments = [...newItems, await userCreatedSegment()];
  } else {
    messages.fcmessages.segments = [await userCreatedSegment()];
  }
  chrome.storage.local.set(messages, function () {
    // //console.log("Saved from not there");
    window.location.href = location;
  });
};
/**
 * Generating the message segment object from user input
 * @param {String} segmentID Optional
 * @returns Object
 */
const userCreatedSegment = async function (segmentID = null) {
  let id = segmentID
    ? segmentID
    : Math.round(new Date().getTime() / 1000).toString();
  const title = $(".segmentTitle").val();
  const userSegment = $(".segmentCreated").find(".msgCreated");
  const segmentsArr = [];
  // //console.log(userSegment);
  for (var i = 0; i < userSegment.length; i++) {
    segmentsArr.push(userSegment[i].innerText);
  }
  let response = "";
  if(configStore.appBaseBackendUrl)
  {
    if (segmentID) {
      response = await segmentEditStorage(segmentID, title, segmentsArr, configStore);
    } else {
      response = await segmentStorage(title, segmentsArr, configStore);
      id = response.data._id;
    }
  }
  return { id: id, title: title, blocks: segmentsArr };
};

/**
 * Populate the created segments in a list
 * @param {Array} data The array of objects of the segments
 */
const populateSegmentLists = async function (data) {
  var injectHtml = "";
  await data.segments.forEach((el, index) => {
    // //console.log("Index",index, "Element",el);
    injectHtml +=
      `<li class="listItem">
            <p>` +
      el.title +
      `</p>
            <div class="optSegment"> ` +
      // <button type="button" class="view" data-blocks="`+el.blocks.join('|')+`">
      //     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="10.286" viewBox="0 0 16 10.286"><g transform="translate(-1467 -182)"><path d="M14.857,389.143a8.777,8.777,0,0,0-3.4-3.152A3.9,3.9,0,0,1,12,388a3.852,3.852,0,0,1-1.174,2.826A3.852,3.852,0,0,1,8,392a3.852,3.852,0,0,1-2.826-1.174A3.852,3.852,0,0,1,4,388a3.9,3.9,0,0,1,.545-2.009,8.777,8.777,0,0,0-3.4,3.152,9.216,9.216,0,0,0,2.978,2.915,7.479,7.479,0,0,0,7.759,0A9.216,9.216,0,0,0,14.857,389.143Zm-6.429-3.429A.427.427,0,0,0,8,385.286,2.728,2.728,0,0,0,5.286,388a.429.429,0,1,0,.857,0A1.86,1.86,0,0,1,8,386.143a.427.427,0,0,0,.429-.429ZM16,389.143a1.236,1.236,0,0,1-.179.616,9.472,9.472,0,0,1-3.362,3.29,8.647,8.647,0,0,1-8.92,0,9.534,9.534,0,0,1-3.362-3.286,1.152,1.152,0,0,1,0-1.232,9.534,9.534,0,0,1,3.362-3.286,8.634,8.634,0,0,1,8.92,0,9.534,9.534,0,0,1,3.362,3.286A1.236,1.236,0,0,1,16,389.143Z" transform="translate(1467 -202)" fill="#8e8b9c"/></g></svg>
      // </button>
      ` <button type="button" class="btn-well editSegment" data-position="` +
      index +
      `" data-id="` +
      el.id +
      `">
                    <svg xmlns="http://www.w3.org/2000/svg" width="13.391" height="13.391" viewBox="0 0 13.391 13.391"><defs><style>.a{fill:#a8a5b3;}</style></defs><g transform="translate(0.276 2)"><path class="a" d="M13.56,4.266a7.022,7.022,0,0,0-2.445-2.424L11.956,1a3.005,3.005,0,0,1,1.826.609,3.005,3.005,0,0,1,.609,1.826ZM6.478,11.347H4.043V8.913l.292-.292A5.1,5.1,0,0,1,6.77,11.055Zm6.379-6.379L7.473,10.352A7.067,7.067,0,0,0,6.409,9,7.031,7.031,0,0,0,5.028,7.928l5.395-5.394a5.09,5.09,0,0,1,2.435,2.435ZM2.826,2.826v9.739h9.739V8.3l1.826-1.849v6.719a1.217,1.217,0,0,1-1.217,1.217H2.217A1.217,1.217,0,0,1,1,13.174V2.217A1.218,1.218,0,0,1,2.217,1h6.7L7.092,2.826Z" transform="translate(-1.276 -3)"/></g></svg>
                    Edit
                </button>
                <button type="button" class="btn-delete delSegment" data-position="` +
      index +
      `" data-id="` +
      el.id +
      `">
                    <svg xmlns="http://www.w3.org/2000/svg" width="13.936" height="16.654" viewBox="0 0 13.936 16.654"><defs><style>.a{fill:#a8a5b3;}</style></defs><g transform="translate(-2)"><g transform="translate(2)"><path class="a" d="M14.409,8H4.793a.677.677,0,0,0-.7.766l1.115,9.128A1.366,1.366,0,0,0,6.6,19.079h5.923a1.366,1.366,0,0,0,1.394-1.185l1.115-9.128A.629.629,0,0,0,14.409,8Z" transform="translate(-2.633 -2.426)"/><path class="a" d="M14.542,1.394H11.058A1.4,1.4,0,0,0,9.665,0H8.271A1.4,1.4,0,0,0,6.878,1.394H3.394A1.4,1.4,0,0,0,2,2.787v.7a.658.658,0,0,0,.7.7H15.239a.658.658,0,0,0,.7-.7v-.7A1.4,1.4,0,0,0,14.542,1.394Z" transform="translate(-2)"/></g></g></svg>
                </button>
            </div>
        </li>`;
  });
  await $("#segmentList").html(injectHtml);
};

/**
 * Initiating the segment to view in a lightbox if user clicks on a segment from the list
 * @param {Object} blocks
 */
// const viewSegment = async function (blocks) {
//     const blocksArr = await blocks.split("|");
//     let innertHtml = '';
//     await blocksArr.forEach((el, index) => {
//         innertHtml += `<div class="prevw-i">
//             `+ el +`
//         </div>`;
//     });
//     await $(".previewList").html(innertHtml);
// };
/**
 * Delete Segment
 * @param {String} segmentID
 */
const deleteSegment = async function (segmentID) {
  var isInGroup = true;
  if(messages.fcmessages && messages.fcmessages.groups && messages.fcmessages.groups.length){
    var groupsPresent = messages.fcmessages.groups;
    groupsPresent.forEach((el,i)=>{
      if(el.blocksPos[0].includes(segmentID))
      {
        alert("This segment is used in a group. You cant delete it.");
        isInGroup = false;
      }
    })
  }
  // console.log(isInGroup);
  if(isInGroup){
    if (
      confirm(
        "If you delete this segment it will be unassigned from everywhere you assigned in a group. Are you sure?"
      )
    ) {
    
      var segmentList = messages.fcmessages.segments;
      // console.log("Delete segmentList :: ", segmentList);
      var filteredSegment =  segmentList.filter((el, i) => {
        return parseInt(el.id) !== parseInt(segmentID);
      });
      // console.log("Delete filteredSegment ::: ", filteredSegment);

      messages.fcmessages.segments = filteredSegment;
      chrome.storage.local.set(messages, async function () {
        if(configStore.appBaseBackendUrl)
          await deleteSegmentStorage(segmentID, configStore);
        await populateSegmentLists(messages.fcmessages);
        await putContentsForDOM();
      });
    }
  }
};

/**
 * This function is responsible for looping the segment view in lightbox
 * @param {Object} element HTML element object
 */
// const slideLightBoxItems = function (element) {
//     clearTimeout(slideLoopTimeout);
//     var i;
//     // get the array of divs' with classname image-sliderfade
//     var slides = element.parents('.create-segment').find('.prevw-i');
//     for (i = 0; i < slides.length; i++) {
//         // initially set the display to
//         // none for every image.
//         slides[i].style.display = "none";
//     }

//     // increase by 1, Global variable
//     slideIndx++;

//     // check for boundary
//     if (slideIndx > slides.length){
//         slideIndx = 1;
//     }
//     slides[slideIndx - 1].style.display = "block";

//     slideLoopTimeout = setTimeout(() => {
//         slideLightBoxItems(slides);
//         //console.log(slideIndx)
//     }, 1000);
// };

/**
 * Update segment function
 * @param {Integer} segmentID The segment id that to be updated
 */
const updateSegment = async function (segmentID) {
  // //console.log("Update Segment Triggered", segmentID);
  const oldSegments = messages.fcmessages.segments;
  const updatedSegment = await userCreatedSegment(segmentID);
  const oldSegmentIndex = await oldSegments.findIndex((x) => x.id == segmentID);
  oldSegments[oldSegmentIndex] = updatedSegment;
  chrome.storage.local.set(messages, function () {
    // //console.log("Saved from empty");
    window.location.href = "segment-listing.html";
  });
};

/**
 * Populate the segment blocks that user clicked from the list to update the segment
 * @param {Integer} id ID of the segment that need to be updated
 */
const populateSegmentForEdit = async function (id) {
  // //console.log("Edit ID", id);
  let html = "";
  const getSegment = async function () {
    var segment = await messages.fcmessages.segments;
    var filteredSegment = await segment.filter((el, i) => {
      return el.id == id;
    });
    return await filteredSegment[0];
  };

  const segments = await getSegment();
  // //console.log(segments);
  await segments.blocks.forEach((el) => {
    html +=
      `<li>
            <div class="msgCreated">` +
      el +
      `
                <button type="button" class="removeMsg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><defs><style>.b{fill:#fff;}</style></defs><g class="a" transform="translate(-2 -2)"><path class="b" d="M10,2a8,8,0,1,0,8,8A8.024,8.024,0,0,0,10,2Zm3.92,10.8L12.8,13.92,10,11.12l-2.8,2.8L6.08,12.8,8.88,10,6.08,7.2,7.2,6.08,10,8.88l2.8-2.8L13.92,7.2,11.12,10Z"></path></g></svg>
                </button>
            </div>
        </li>`;
  });
  await $(".segmentCreated ul").html(html);
  await $(".segmentTitle").val(segments.title);
};
