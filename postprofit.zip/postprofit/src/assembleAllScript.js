try {
  // console.log(">>>>>>> I am here in success block at line no 2 >>>>>>>>");
  importScripts("./background.js ", "../worker.js");
} catch (e) {
  // console.log(">>>>>>> I am here in error block at line no 5 >>>>>>", e);
}
